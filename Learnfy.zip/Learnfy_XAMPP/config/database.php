<?php
declare(strict_types=1);

$host = '127.0.0.1';
$dbname = 'learnfy';
$username = 'root';
$password = ''; // Default XAMPP MySQL password. Change this if yours is different.

try {
    $pdo = new PDO(
        "mysql:host={$host};dbname={$dbname};charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    exit('Database connection failed. Check that Apache and MySQL are running and that config/database.php matches your MySQL settings. Details: ' . htmlspecialchars($e->getMessage()));
}
