# Learnfy — XAMPP edition

Learnfy is a lightweight learning platform for web-development students. It keeps the original blue Learnfy identity and adds a PHP + MySQL backend so authorised teachers can publish written lessons, documents and video lessons.

## Features

- Student-facing home page and learning-material library.
- Subject filters and individual lesson pages.
- Teacher login with hashed passwords and session protection.
- One-time first-teacher setup; public teacher registration is not available.
- Teacher dashboard to publish and delete their own materials.
- Lesson text, YouTube/Vimeo video embeds, and downloadable attachments.
- Prepared SQL statements, CSRF tokens, upload MIME checks and upload size limits.
- Responsive layout with no paid API or external framework dependency.

## Requirements

- Windows with XAMPP (Apache + MySQL/MariaDB).
- PHP 8.0+ recommended; PHP extensions `pdo_mysql` and `fileinfo` enabled.
- A modern browser.

## Install and run

1. Copy the entire `Learnfy_XAMPP` folder into `C:\xampp\htdocs\`.
2. Open the XAMPP Control Panel and start **Apache** and **MySQL**.
3. Open `http://localhost/phpmyadmin`.
4. Select **Import**, choose `Learnfy_XAMPP/database.sql`, and click **Import**.
   - The SQL file creates the `learnfy` database and required tables.
5. Check `config/database.php`. The default XAMPP settings are user `root` and an empty password. Change them if your MySQL account uses a password.
6. Open `http://localhost/Learnfy_XAMPP/`.
7. Open `http://localhost/Learnfy_XAMPP/teacher/setup.php` and create the first teacher account.
   - Use a strong password of at least 10 characters.
   - Setup locks automatically after the first teacher is created.
8. Sign in at `http://localhost/Learnfy_XAMPP/teacher/login.php`.
9. From the teacher dashboard choose **Add material** to publish notes, documents or video lessons.
10. Students can open `http://localhost/Learnfy_XAMPP/materials.php` to view published resources.

## Adding lessons and videos

- **Written lesson:** enter a title, subject, summary and lesson notes.
- **Document:** choose the document type and attach PDF, DOC, DOCX, PPT or PPTX.
- **Video:** paste a YouTube or Vimeo URL. You may alternatively upload an MP4.
- Attachments are limited to 50 MB in the application. If your PHP upload limit is lower, update `upload_max_filesize` and `post_max_size` in `php.ini`, then restart Apache.
- For large videos, prefer a YouTube/Vimeo link rather than uploading the video to XAMPP.

## Important notes

- GitHub Pages is a static hosting service and **cannot run PHP or MySQL**. Use this XAMPP edition through `http://localhost/Learnfy_XAMPP/` for the teacher backend. The existing GitHub Pages version remains separate and static.
- This is a classroom/demo deployment intended for localhost. Do not expose it publicly without HTTPS, stronger server configuration, backups, rate limiting and a production hosting plan.
- The initial teacher setup page is automatically disabled once one teacher account exists. If you need another teacher, add that teacher through a controlled database/admin process; do not re-enable public registration.
- If a video host changes its embed policy, the original video link may still be opened from the lesson page.

## Project structure

```text
Learnfy_XAMPP/
├── assets/css/style.css
├── config/database.php
├── includes/              # shared functions and layout
├── teacher/               # setup, login, dashboard and publishing
├── uploads/materials/     # teacher attachments
├── database.sql
├── index.php
├── materials.php
├── lesson.php
├── feedback.php
├── quiz.php
└── about.php
```
