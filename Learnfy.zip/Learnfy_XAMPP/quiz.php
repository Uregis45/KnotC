<?php
require_once __DIR__ . '/includes/functions.php';
$pageTitle='HTML practice quiz';
require __DIR__ . '/includes/header.php';
?>
<section class="form-card"><span class="eyebrow" style="color:#3970c7">Practice time</span><h1>HTML knowledge check</h1><p class="muted">Choose an answer for each question, then check your score.</p>
<form id="quizForm">
<div class="quiz-question"><strong>1. Which tag creates a description list?</strong><?php foreach(['ul'=>'&lt;ul&gt;','ol'=>'&lt;ol&gt;','dl'=>'&lt;dl&gt;','li'=>'&lt;li&gt;'] as $v=>$label): ?><label><input type="radio" name="q1" value="<?= $v ?>"> <?= $label ?></label><?php endforeach; ?></div>
<div class="quiz-question"><strong>2. Which HTML tag creates a hyperlink?</strong><?php foreach(['link'=>'&lt;link&gt;','a'=>'&lt;a&gt;','href'=>'&lt;href&gt;','url'=>'&lt;url&gt;'] as $v=>$label): ?><label><input type="radio" name="q2" value="<?= $v ?>"> <?= $label ?></label><?php endforeach; ?></div>
<div class="quiz-question"><strong>3. Which tag is used for the largest heading?</strong><?php foreach(['h6'=>'&lt;h6&gt;','head'=>'&lt;head&gt;','h1'=>'&lt;h1&gt;','title'=>'&lt;title&gt;'] as $v=>$label): ?><label><input type="radio" name="q3" value="<?= $v ?>"> <?= $label ?></label><?php endforeach; ?></div>
<button type="button" onclick="gradeQuiz()">Check my answers</button><p id="quizResult" class="score" aria-live="polite"></p>
</form></section>
<script>
function gradeQuiz(){const answers={q1:'dl',q2:'a',q3:'h1'};let score=0;for(const [q,a] of Object.entries(answers)){const picked=document.querySelector('input[name="'+q+'"]:checked');if(picked&&picked.value===a)score++;}document.getElementById('quizResult').textContent='You scored '+score+' out of 3 '+(score===3?'— excellent work!':'— keep practising!');}
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>
