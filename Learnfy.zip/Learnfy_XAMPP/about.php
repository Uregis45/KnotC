<?php
require_once __DIR__ . '/includes/functions.php';
$pageTitle='About Learnfy';
require __DIR__ . '/includes/header.php';
?>
<section class="form-card"><span class="eyebrow" style="color:#3970c7">About us</span><h1>Learning should be clear and accessible.</h1><p>Learnfy is a simple learning platform designed to help students build digital and web-development skills step by step.</p><h2>Our approach</h2><ul><li>Short, understandable learning materials.</li><li>Practical examples and self-check quizzes.</li><li>Teacher-shared notes, documents and video lessons.</li><li>A clean experience that works on phones and computers.</li></ul><p class="muted">Learnfy is a student learning project. Materials are managed by authorised teachers.</p></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
