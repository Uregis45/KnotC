<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/config/database.php';
$pageTitle='Feedback';
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    $name=trim($_POST['name'] ?? '');
    $email=trim($_POST['email'] ?? '');
    $rating=filter_input(INPUT_POST,'rating',FILTER_VALIDATE_INT);
    $message=trim($_POST['message'] ?? '');
    if ($name==='' || !filter_var($email,FILTER_VALIDATE_EMAIL) || !$rating || $rating<1 || $rating>5 || $message==='') $error='Please complete every field with valid information.';
    else {
        $stmt=$pdo->prepare('INSERT INTO feedback(student_name,email,rating,message) VALUES(?,?,?,?)');
        $stmt->execute([$name,$email,$rating,$message]);
        set_flash('success','Thank you. Your feedback has been submitted.');
        redirect('feedback.php');
    }
}
require __DIR__ . '/includes/header.php';
?>
<section class="form-card"><span class="eyebrow" style="color:#3970c7">Help us improve</span><h1>We value your feedback</h1><p class="muted">Tell us what is working well and what we can improve.</p>
<?php if($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><div class="field"><label for="name">Your name</label><input id="name" name="name" maxlength="100" required value="<?= e($_POST['name'] ?? '') ?>"></div><div class="field"><label for="email">Email address</label><input id="email" name="email" type="email" required value="<?= e($_POST['email'] ?? '') ?>"></div><div class="field"><label for="rating">How would you rate Learnfy?</label><select id="rating" name="rating"><option value="5">Excellent</option><option value="4">Good</option><option value="3">Average</option><option value="2">Fair</option><option value="1">Poor</option></select></div><div class="field"><label for="message">Comments or suggestions</label><textarea id="message" name="message" required></textarea></div><button>Submit feedback</button></form></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
