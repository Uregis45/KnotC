<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../config/database.php';
require_teacher();
$stmt=$pdo->prepare("SELECT id,title,subject,material_type,created_at FROM materials WHERE teacher_id=? ORDER BY created_at DESC");
$stmt->execute([current_teacher()['id']]); $items=$stmt->fetchAll();
$pageTitle='Teacher dashboard';
require __DIR__ . '/../includes/header.php';
?>
<div class="section-head"><div><span class="eyebrow" style="color:#3970c7">Teacher workspace</span><h2>Hello, <?= e(current_teacher()['name']) ?></h2><p class="muted">Manage the lessons and resources you have shared with students.</p></div><div class="actions"><a class="button" href="add-material.php">+ Add material</a><a class="button-secondary" href="logout.php">Sign out</a></div></div>
<div class="grid"><article class="card"><span class="tag">Your library</span><h2><?= count($items) ?></h2><p>Materials you have published.</p></article><article class="card"><span class="tag">Publishing</span><h3>Notes & documents</h3><p>Share lesson explanations and downloadable files.</p></article><article class="card"><span class="tag">Video lessons</span><h3>Teach visually</h3><p>Add a YouTube or Vimeo link for students.</p></article></div>
<div class="section-head"><div><h2>Your published materials</h2></div></div>
<?php if(!$items): ?><div class="empty-state"><h3>You have not published anything yet</h3><p class="muted">Create your first lesson or video resource.</p><a class="button" href="add-material.php">Add your first material</a></div>
<?php else: ?><div class="panel table-wrap"><table class="data-table"><thead><tr><th>Title</th><th>Subject</th><th>Type</th><th>Published</th><th>Action</th></tr></thead><tbody><?php foreach($items as $item): ?><tr><td><?= e($item['title']) ?></td><td><?= e($item['subject']) ?></td><td><?= e(ucfirst($item['material_type'])) ?></td><td><?= e(date('M j, Y',strtotime($item['created_at']))) ?></td><td><div class="actions"><a href="../lesson.php?id=<?= (int)$item['id'] ?>">View</a><form method="post" action="delete-material.php" onsubmit="return confirm('Delete this material?')"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= (int)$item['id'] ?>"><button class="danger small">Delete</button></form></div></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
