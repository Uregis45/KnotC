<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../config/database.php';
require_teacher();
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    $title=trim($_POST['title'] ?? '');
    $subject=trim($_POST['subject'] ?? '');
    $summary=trim($_POST['summary'] ?? '');
    $body=trim($_POST['body'] ?? '');
    $type=$_POST['material_type'] ?? 'lesson';
    $video=trim($_POST['video_url'] ?? '');
    $allowedTypes=['lesson','document','video'];
    $filePath=null;
    if ($title==='' || $subject==='' || !in_array($type,$allowedTypes,true)) $error='Please complete the title, subject and material type.';
    if (!$error && $video!=='') {
        $parts=parse_url($video);
        if (!$parts || !in_array(strtolower($parts['scheme'] ?? ''),['http','https'],true)) $error='Enter a valid video URL beginning with https://.';
    }
    if (!$error && isset($_FILES['resource']) && $_FILES['resource']['error'] !== UPLOAD_ERR_NO_FILE) {
        $file=$_FILES['resource'];
        if ($file['error']!==UPLOAD_ERR_OK) $error='The file upload failed. Check the file size and try again.';
        elseif ($file['size']>50*1024*1024) $error='The maximum attachment size is 50 MB.';
        else {
            $finfo=new finfo(FILEINFO_MIME_TYPE); $mime=$finfo->file($file['tmp_name']);
            $allowed=[
                'application/pdf'=>'pdf',
                'application/msword'=>'doc',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document'=>'docx',
                'application/vnd.ms-powerpoint'=>'ppt',
                'application/vnd.openxmlformats-officedocument.presentationml.presentation'=>'pptx',
                'video/mp4'=>'mp4',
                'image/jpeg'=>'jpg','image/png'=>'png'
            ];
            if (!isset($allowed[$mime])) $error='Allowed files: PDF, DOC, DOCX, PPT, PPTX, MP4, JPG and PNG.';
            else {
                $dir=__DIR__.'/../uploads/materials';
                if (!is_dir($dir)) mkdir($dir,0755,true);
                $name=bin2hex(random_bytes(16)).'.'.$allowed[$mime];
                if (move_uploaded_file($file['tmp_name'],$dir.'/'.$name)) $filePath='uploads/materials/'.$name;
                else $error='Could not save the uploaded file.';
            }
        }
    }
    if (!$error) {
        $stmt=$pdo->prepare("INSERT INTO materials(teacher_id,title,subject,summary,body,material_type,video_url,file_path) VALUES(?,?,?,?,?,?,?,?)");
        $stmt->execute([current_teacher()['id'],$title,$subject,$summary,$body,$type,$video ?: null,$filePath]);
        set_flash('success','Your learning material has been published.');
        redirect('dashboard.php');
    }
}
$pageTitle='Add learning material';
require __DIR__ . '/../includes/header.php';
?>
<section class="form-card"><span class="eyebrow" style="color:#3970c7">Publish content</span><h1>Add a learning material</h1><p class="muted">Write a lesson, attach a document or share a video lesson. Students will see published materials on the Learning materials page.</p>
<?php if($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
<div class="field"><label for="title">Lesson title *</label><input id="title" name="title" maxlength="180" required value="<?= e($_POST['title'] ?? '') ?>"></div>
<div class="form-grid"><div class="field"><label for="subject">Subject *</label><select id="subject" name="subject" required><option value="">Choose subject</option><?php foreach(['Computer Basics','Typing Skills','HTML','CSS','JavaScript','Web Development','Other'] as $s): ?><option <?= (($_POST['subject'] ?? '')===$s)?'selected':'' ?>><?= e($s) ?></option><?php endforeach; ?></select></div><div class="field"><label for="material_type">Material type *</label><select id="material_type" name="material_type"><option value="lesson">Written lesson</option><option value="document">Document / resource</option><option value="video">Video lesson</option></select></div></div>
<div class="field"><label for="summary">Short description</label><input id="summary" name="summary" maxlength="300" value="<?= e($_POST['summary'] ?? '') ?>" placeholder="What will students learn?"></div>
<div class="field"><label for="body">Lesson notes / explanation</label><textarea id="body" name="body" placeholder="Write the lesson content here..."><?= e($_POST['body'] ?? '') ?></textarea><p class="help">Plain text is supported. Keep explanations clear and organised.</p></div>
<div class="field"><label for="video_url">Video URL (YouTube or Vimeo)</label><input id="video_url" name="video_url" type="url" placeholder="https://www.youtube.com/watch?v=... " value="<?= e($_POST['video_url'] ?? '') ?>"><p class="help">You can also attach an MP4 video below (maximum 50 MB).</p></div>
<div class="field"><label for="resource">Attach a file (optional)</label><input id="resource" name="resource" type="file" accept=".pdf,.doc,.docx,.ppt,.pptx,.mp4,.jpg,.jpeg,.png"><p class="help">PDF, Word, PowerPoint, MP4, JPG or PNG. Maximum 50 MB.</p></div>
<button>Publish material</button> <a class="button-secondary" href="dashboard.php">Cancel</a></form></section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
