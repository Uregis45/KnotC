<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../config/database.php';
$count = (int)$pdo->query("SELECT COUNT(*) FROM teachers")->fetchColumn();
if ($count > 0) { set_flash('info','Teacher setup has already been completed. Please sign in.'); redirect('login.php'); }
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    $name=trim($_POST['name'] ?? '');
    $email=strtolower(trim($_POST['email'] ?? ''));
    $password=$_POST['password'] ?? '';
    if ($name==='' || !filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($password)<10) {
        $error='Enter your name, a valid email and a password with at least 10 characters.';
    } else {
        $stmt=$pdo->prepare("INSERT INTO teachers(name,email,password_hash) VALUES(?,?,?)");
        try { $stmt->execute([$name,$email,password_hash($password,PASSWORD_DEFAULT)]); set_flash('success','Teacher account created. You can now sign in.'); redirect('login.php'); }
        catch(PDOException $e) { $error='That email address may already be registered.'; }
    }
}
$pageTitle='Initial teacher setup';
require __DIR__ . '/../includes/header.php';
?>
<section class="form-card"><span class="eyebrow" style="color:#3970c7">One-time setup</span><h1>Create the first teacher account</h1><p class="muted">This page is available only while no teacher account exists. After the first account is created, setup locks automatically.</p>
<?php if($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><div class="field"><label for="name">Teacher name</label><input id="name" name="name" required maxlength="100"></div><div class="field"><label for="email">Email</label><input id="email" name="email" type="email" required></div><div class="field"><label for="password">Password</label><input id="password" name="password" type="password" minlength="10" required><p class="help">Use at least 10 characters. There is no public teacher registration.</p></div><button>Create teacher account</button></form></section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
