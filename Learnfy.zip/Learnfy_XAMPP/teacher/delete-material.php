<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../config/database.php';
require_teacher();
if ($_SERVER['REQUEST_METHOD']!=='POST') redirect('dashboard.php');
verify_csrf();
$id=filter_input(INPUT_POST,'id',FILTER_VALIDATE_INT);
$stmt=$pdo->prepare("SELECT file_path FROM materials WHERE id=? AND teacher_id=?");
$stmt->execute([$id ?: 0,current_teacher()['id']]); $row=$stmt->fetch();
if ($row) {
    $del=$pdo->prepare("DELETE FROM materials WHERE id=? AND teacher_id=?");
    $del->execute([$id,current_teacher()['id']]);
    if ($row['file_path']) { $path=realpath(__DIR__.'/../'.$row['file_path']); $base=realpath(__DIR__.'/../uploads/materials'); if($path && $base && str_starts_with($path,$base.DIRECTORY_SEPARATOR) && is_file($path)) unlink($path); }
    set_flash('success','Material deleted.');
} else set_flash('error','Material not found or you do not have permission to delete it.');
redirect('dashboard.php');
