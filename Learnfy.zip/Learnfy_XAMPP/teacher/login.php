<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../config/database.php';
if (current_teacher()) redirect('dashboard.php');
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    $email=strtolower(trim($_POST['email'] ?? ''));
    $password=$_POST['password'] ?? '';
    $stmt=$pdo->prepare("SELECT id,name,email,password_hash FROM teachers WHERE email=?");
    $stmt->execute([$email]); $teacher=$stmt->fetch();
    if ($teacher && password_verify($password,$teacher['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['teacher']=['id'=>(int)$teacher['id'],'name'=>$teacher['name'],'email'=>$teacher['email']];
        redirect('dashboard.php');
    }
    $error='Email or password is incorrect.';
}
$pageTitle='Teacher login';
require __DIR__ . '/../includes/header.php';
?>
<section class="form-card"><span class="eyebrow" style="color:#3970c7">Teacher workspace</span><h1>Welcome back</h1><p class="muted">Sign in to publish learning materials and video lessons.</p>
<?php if($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><div class="field"><label>Email address</label><input name="email" type="email" required autocomplete="username"></div><div class="field"><label>Password</label><input name="password" type="password" required autocomplete="current-password"></div><button>Sign in</button></form>
<p class="help" style="margin-top:18px">First time using Learnfy on this computer? <a href="setup.php">Create the initial teacher account</a>.</p></section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
