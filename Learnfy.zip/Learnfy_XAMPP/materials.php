<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/config/database.php';
$pageTitle = 'Learning materials';
$subject = trim($_GET['subject'] ?? '');
if ($subject !== '') {
    $stmt = $pdo->prepare("SELECT id,title,subject,summary,material_type,created_at FROM materials WHERE subject = ? ORDER BY created_at DESC");
    $stmt->execute([$subject]);
    $materials = $stmt->fetchAll();
} else {
    $materials = $pdo->query("SELECT id,title,subject,summary,material_type,created_at FROM materials ORDER BY created_at DESC")->fetchAll();
}
$subjects = $pdo->query("SELECT DISTINCT subject FROM materials ORDER BY subject")->fetchAll(PDO::FETCH_COLUMN);
require __DIR__ . '/includes/header.php';
?>
<section class="section-head"><div><span class="eyebrow" style="color:#3970c7">Learnfy library</span><h2>Learning materials</h2><p class="muted">Lessons, downloadable resources and video tutorials shared by teachers.</p></div></section>
<div class="actions" style="margin-bottom:20px"><a class="button-secondary" href="materials.php">All materials</a><?php foreach($subjects as $s): ?><a class="button-secondary" href="materials.php?subject=<?= urlencode($s) ?>"><?= e($s) ?></a><?php endforeach; ?></div>
<section class="material-list">
<?php if (!$materials): ?><div class="empty-state"><h3>No materials found yet</h3><p class="muted">When a teacher publishes a lesson, it will appear here.</p></div>
<?php else: foreach($materials as $m): ?>
<article class="material-card"><div><span class="tag"><?= e($m['subject']) ?></span> <span class="tag"><?= e(ucfirst($m['material_type'])) ?></span><h3><?= e($m['title']) ?></h3><p><?= e($m['summary']) ?></p><span class="meta">Published <?= e(date('M j, Y', strtotime($m['created_at']))) ?></span></div><a class="button-secondary" href="lesson.php?id=<?= (int)$m['id'] ?>">View material →</a></article>
<?php endforeach; endif; ?>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
