<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/config/database.php';
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$stmt = $pdo->prepare("SELECT m.*, t.name AS teacher_name FROM materials m JOIN teachers t ON t.id=m.teacher_id WHERE m.id=?");
$stmt->execute([$id ?: 0]);
$lesson = $stmt->fetch();
if (!$lesson) { http_response_code(404); $pageTitle='Lesson not found'; require __DIR__.'/includes/header.php'; echo '<div class="empty-state"><h2>Lesson not found</h2><a class="button-secondary" href="materials.php">Back to materials</a></div>'; require __DIR__.'/includes/footer.php'; exit; }
$pageTitle = $lesson['title'];
require __DIR__ . '/includes/header.php';
$embed = $lesson['video_url'] ? safe_video_embed($lesson['video_url']) : null;
?>
<article class="panel" style="margin:32px 0"><span class="tag"><?= e($lesson['subject']) ?></span><span class="tag"><?= e(ucfirst($lesson['material_type'])) ?></span><h1 style="color:#163a85"><?= e($lesson['title']) ?></h1><p class="muted"><?= e($lesson['summary']) ?></p><p class="small muted">Shared by <?= e($lesson['teacher_name']) ?> · <?= e(date('M j, Y', strtotime($lesson['created_at']))) ?></p>
<?php if ($embed): ?><div style="margin:22px 0"><iframe class="video-frame" src="<?= e($embed) ?>" title="<?= e($lesson['title']) ?>" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen loading="lazy"></iframe></div>
<?php elseif ($lesson['video_url'] && preg_match('/\.mp4(\?.*)?$/i', $lesson['video_url'])): ?><video class="video-frame" controls src="<?= e($lesson['video_url']) ?>"></video><?php endif; ?>
<?php if ($lesson['body']): ?><h2>Lesson notes</h2><div class="lesson-body"><?= e($lesson['body']) ?></div><?php endif; ?>
<?php if ($lesson['file_path']): ?><p style="margin-top:20px"><a class="button" href="<?= e($lesson['file_path']) ?>" download>Download attached resource ↓</a></p><?php endif; ?>
<?php if ($lesson['video_url'] && !$embed && !preg_match('/\.mp4(\?.*)?$/i', $lesson['video_url'])): ?><p><a href="<?= e($lesson['video_url']) ?>" target="_blank" rel="noopener noreferrer">Open video link in a new tab</a></p><?php endif; ?>
</article><a class="button-secondary" href="materials.php">← Back to all materials</a>
<?php require __DIR__ . '/includes/footer.php'; ?>
