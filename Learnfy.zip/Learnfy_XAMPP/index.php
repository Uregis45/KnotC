<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/config/database.php';
$pageTitle = 'Learn Web Development';
$latest = $pdo->query("SELECT id,title,subject,summary,created_at FROM materials ORDER BY created_at DESC LIMIT 3")->fetchAll();
require __DIR__ . '/includes/header.php';
?>
<section class="hero">
  <span class="eyebrow">Your learning space</span>
  <h1>Build skills. Create things. Keep growing.</h1>
  <p>Learn web development step by step with clear lessons, useful study materials and practical quizzes. Teachers can share new lessons and video resources in one place.</p>
  <a class="button" href="materials.php">Explore learning materials →</a>
</section>
<div class="section-head"><div><span class="eyebrow" style="color:#3970c7">Start here</span><h2>Explore what you can learn</h2></div></div>
<section class="grid">
  <article class="card"><div class="icon-tile">⌨</div><h3>Computer & typing skills</h3><p>Keyboard parts, shortcuts, posture and accurate typing techniques.</p></article>
  <article class="card"><div class="icon-tile">⌘</div><h3>HTML foundations</h3><p>Understand webpage structure, tags, lists, tables, forms and semantic HTML.</p></article>
  <article class="card"><div class="icon-tile">🎨</div><h3>CSS & design</h3><p>Learn how styles, colours, layouts and responsive design shape a website.</p></article>
  <article class="card"><div class="icon-tile">JS</div><h3>JavaScript basics</h3><p>Explore variables, conditions, functions and interactive webpages.</p></article>
  <article class="card"><div class="icon-tile">▶</div><h3>Video lessons</h3><p>Watch teacher-shared lesson videos directly from the learning materials page.</p></article>
  <article class="card"><div class="icon-tile">✓</div><h3>Test your knowledge</h3><p>Practise with short quizzes and check your understanding.</p></article>
</section>
<div class="section-head"><div><h2>Recently added materials</h2><p class="muted">New lessons shared by Learnfy teachers.</p></div><a class="button-secondary" href="materials.php">View all</a></div>
<section class="material-list">
<?php if (!$latest): ?>
  <div class="empty-state"><h3>Your learning library starts here</h3><p class="muted">Teacher-added lessons and videos will appear here.</p><a class="button-secondary" href="teacher/setup.php">Set up teacher access</a></div>
<?php else: foreach ($latest as $item): ?>
  <article class="material-card"><div><span class="tag"><?= e($item['subject']) ?></span><h3><?= e($item['title']) ?></h3><p><?= e($item['summary']) ?></p><span class="meta">Added <?= e(date('M j, Y', strtotime($item['created_at']))) ?></span></div><a class="button-secondary" href="lesson.php?id=<?= (int)$item['id'] ?>">Open lesson →</a></article>
<?php endforeach; endif; ?>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
