</main>
<footer class="site-footer">
  <div><strong>Learnfy</strong><p>Simple learning. Real progress.</p></div>
  <p>© <?= date('Y') ?> Learnfy. Built for learners and teachers.</p>
</footer>
</body>
</html>
