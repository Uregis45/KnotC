<?php
$pageTitle = $pageTitle ?? 'Learnfy';
$teacher = current_teacher();
$base = (strpos($_SERVER['SCRIPT_NAME'] ?? '', '/teacher/') !== false) ? '../' : '';
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Learn web development step by step with Learnfy.">
  <title><?= e($pageTitle) ?> | Learnfy</title>
  <link rel="stylesheet" href="<?= $base ?>assets/css/style.css">
</head>
<body>
<header class="site-header">
  <a class="brand" href="<?= $base ?>index.php"><span class="brand-mark">L</span><span>Learnfy<small>Learn. Practise. Grow.</small></span></a>
  <button class="nav-toggle" type="button" aria-label="Toggle navigation" onclick="document.querySelector('.nav-links').classList.toggle('open')">☰</button>
  <nav class="nav-links">
    <a href="<?= $base ?>index.php">Home</a>
    <a href="<?= $base ?>materials.php">Learning materials</a>
    <a href="<?= $base ?>quiz.php">Quiz</a>
    <a href="<?= $base ?>about.php">About</a>
    <?php if ($teacher): ?>
      <a href="<?= $base ?>teacher/dashboard.php">Teacher area</a>
    <?php else: ?>
      <a href="<?= $base ?>teacher/login.php">Teacher login</a>
    <?php endif; ?>
  </nav>
</header>
<main class="page-shell">
<?php if ($flash = get_flash()): ?>
  <div class="alert <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
<?php endif; ?>
