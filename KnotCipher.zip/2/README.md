# KnotCipher (XAMPP/PHP + MySQL)

This version replaces the previous Firebase Realtime Database connection with a PHP/MySQL backend for local XAMPP use. It adds account login, database-backed room membership and messages, room-wide shared themes, presence/typing indicators, ghost-message expiry, and room-owner key rotation.

## Run on XAMPP

Use PHP 8.1+ with PDO MySQL and mbstring enabled (standard in current XAMPP releases).

1. Copy this project folder into `C:\xampp\htdocs\Cipher` (Windows) or XAMPP's `htdocs` directory.
2. Start **Apache** and **MySQL** in the XAMPP Control Panel.
3. Open phpMyAdmin, select **Import**, and import `schema.sql`. This creates the `knotcipher` database and tables.
4. If your local MySQL credentials differ from XAMPP defaults, create `config.local.php` beside `db.php` using:

   ```php
   <?php
   define('DB_HOST', '127.0.0.1');
   define('DB_NAME', 'knotcipher');
   define('DB_USER', 'root');
   define('DB_PASS', '');
   ```

5. Browse to `http://localhost/Cipher/` and create an account.

The default database settings assume a private local XAMPP installation (`root` with an empty password). Do **not** expose this setup to the internet. Before deployment, use HTTPS, a dedicated database user with a strong password, email verification, rate limiting, secure session settings, backups, and a security review.

## Behavior and security notes

- Accounts identify users by their registered display name and email; this does not prove a government or legal identity. Email is not shown in the room UI.
- Message plaintext is encrypted in the browser with Web Crypto AES-GCM before it reaches PHP/MySQL. The server stores ciphertext, but a room member who knows the shared Knot Key can read messages.
- The room creator can rotate its Knot Key. The browser decrypts each stored message with the current key, encrypts them with the replacement key and fresh salt, and submits the ciphertexts in one server transaction. Other members must obtain the new key from a trusted channel. A stale or incorrect key cancels rotation.
- Rotation makes the *current database copies* no longer decryptable with the old key. It cannot erase plaintext already viewed, copied, screenshotted, or otherwise saved, nor ciphertext someone copied before rotation.
- Ghost messages are deleted from the database after their selected expiry time when the room is polled. “Self-destruct” is not protection against screenshots or copies.
- Room names are identifiers, not access codes. Account login and room membership limit database access; the Knot Key provides message confidentiality. Share room names and keys carefully.
- The previous repository version used Firebase Realtime Database (not browser localStorage). This XAMPP version starts with a new MySQL database; it does not import Firebase messages automatically.

## Files

- `schema.sql` — MySQL schema.
- `db.php` — PDO and session setup.
- `login.php`, `register.php`, `logout.php` — account flows.
- `api.php` — authenticated, CSRF-checked JSON API.
- `index.php`, `script.js`, `style.css` — chat app and themes.
