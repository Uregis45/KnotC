<?php
declare(strict_types=1);
require_once __DIR__ . '/auth_helpers.php';
require_login_page();
header('Cache-Control: no-store, private');
?><!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="csrf-token" content="<?= escape_html(csrf_token()) ?>">
  <title>KnotCipher — private rooms</title>
  <link rel="stylesheet" href="style.css">
</head>
<body data-theme="ocean">
<main class="chat-container" id="app" data-user-id="<?= (int)$_SESSION['user_id'] ?>" data-user-name="<?= escape_html((string)$_SESSION['display_name']) ?>">
  <header class="header">
    <h1>🔐 KnotCipher Chat</h1>
    <p>Tie your secrets in knots. Only the right key unties them.</p>
    <div class="header-meta">
      <small>Signed in as <strong id="currentUser"><?= escape_html((string)$_SESSION['display_name']) ?></strong></small>
      <span id="onlineCount">0 online</span>
    </div>
    <small>Room: <span id="currentRoom">not joined</span></small>
    <form action="logout.php" method="post" class="logout-form"><input type="hidden" name="csrf_token" value="<?= escape_html(csrf_token()) ?>"><button type="submit" class="logout-button">Sign out</button></form>
  </header>

  <section class="key-section" aria-label="Room encryption key">
    <div class="input-wrapper"><input type="password" id="knotKeyInput" placeholder="Enter this room's Knot Key" autocomplete="off" spellcheck="false"><button type="button" id="toggleKeyVisibility" title="Show or hide key" aria-label="Show or hide key">👁️</button></div>
    <button type="button" id="setKeyBtn">🔑 Set Knot Key</button>
    <div id="keyStatus" class="status" style="background:#ff9800">⚠️ No Knot Key set</div>
    <div class="rotate-controls"><input type="password" id="newKnotKeyInput" placeholder="New Knot Key (room owner)" autocomplete="new-password"><button type="button" id="rotateKeyBtn" disabled>♻️ Rotate room key</button></div>
    <small class="key-help">Room owners can rotate the key. Rotation re-encrypts stored messages; it cannot erase copies already read or saved.</small>
  </section>

  <section class="ghost-section" aria-label="Message mode">
    <div class="mode-toggle"><span>📝 Mode:</span><button type="button" id="classicModeBtn" class="mode-btn active">Classic</button><button type="button" id="ghostModeBtn" class="mode-btn">👻 Ghost</button></div>
    <div id="ghostTimerContainer" style="display:none"><label for="ghostTimerSelect">⏱️ Self-destruct after:</label><select id="ghostTimerSelect"><option value="5">5 seconds</option><option value="15">15 seconds</option><option value="30" selected>30 seconds</option><option value="60">1 minute</option><option value="300">5 minutes</option></select></div>
  </section>

  <section class="room-section" aria-label="Room settings">
    <input type="text" id="roomInput" placeholder="Room name (e.g. Alice & Bob)" value="lobby" maxlength="48" autocomplete="off" spellcheck="false">
    <button type="button" id="joinRoomBtn">🚪 Join / Create Room</button>
    <label class="theme-control" for="themeSelect">🎨 Shared theme</label>
    <select id="themeSelect" aria-label="Shared room theme"><option value="ocean">Ocean</option><option value="forest">Forest</option><option value="sunset">Sunset</option><option value="violet">Violet</option><option value="slate">Slate</option></select>
    <div id="roomStatus" class="status" style="background:#2196f3">📡 Joining lobby…</div>
  </section>

  <div id="typingIndicator" aria-live="polite"></div>
  <section class="messages-area" id="messagesContainer" aria-label="Messages"><div class="empty-placeholder">💬 Join a room and set its Knot Key to start chatting.</div></section>
  <form class="input-area" id="messageForm"><input type="text" id="messageInput" maxlength="4000" placeholder="Type your secret message… 🔒" autocomplete="off" spellcheck="false" aria-label="Message"><button type="submit">📤 Send</button></form>
  <footer class="info">🔒 Messages are encrypted in your browser before storage. Everyone in a room needs its Knot Key.<br>👻 Ghost messages are deleted by the server after their timer expires. Room themes are shared with everyone.</footer>
</main>
<script src="script.js" defer></script>
</body>
</html>
