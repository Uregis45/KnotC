<?php
declare(strict_types=1);
require_once __DIR__ . '/auth_helpers.php';
if (!empty($_SESSION['user_id'])) { header('Location: index.php'); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!check_form_csrf()) {
        $error = 'Your session expired. Refresh and try again.';
    } else {
        $displayName = trim((string)($_POST['display_name'] ?? ''));
        $email = strtolower(trim((string)($_POST['email'] ?? '')));
        $password = (string)($_POST['password'] ?? '');
        if (mb_strlen($displayName) < 2 || mb_strlen($displayName) > 80) {
            $error = 'Name must be between 2 and 80 characters.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) {
            $error = 'Enter a valid email address.';
        } elseif (strlen($password) < 12) {
            $error = 'Use a password with at least 12 characters.';
        } else {
            try {
                $stmt = db()->prepare('INSERT INTO users (display_name, email, password_hash) VALUES (?, ?, ?)');
                $stmt->execute([$displayName, $email, password_hash($password, PASSWORD_DEFAULT)]);
                $_SESSION['user_id'] = (int)db()->lastInsertId();
                $_SESSION['display_name'] = $displayName;
                redirect_after_auth();
            } catch (PDOException $e) {
                if ($e->getCode() === '23000') $error = 'An account already exists for that email.';
                else { error_log($e->getMessage()); $error = 'Account creation failed. Check the database setup.'; }
            }
        }
    }
}
?><!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Create account · KnotCipher</title><link rel="stylesheet" href="style.css"></head>
<body class="auth-body"><main class="auth-card"><div class="auth-mark">🔐</div><h1>Create your account</h1><p class="auth-subtitle">Use an account name and email to identify yourself in rooms.</p>
<?php if ($error): ?><p class="auth-error" role="alert"><?= escape_html($error) ?></p><?php endif; ?>
<form method="post" action="register.php" class="auth-form"><input type="hidden" name="csrf_token" value="<?= escape_html(csrf_token()) ?>"><label>Display name<input name="display_name" maxlength="80" autocomplete="name" required></label><label>Email<input type="email" name="email" maxlength="190" autocomplete="email" required></label><label>Password<input type="password" name="password" minlength="12" autocomplete="new-password" required><small>At least 12 characters.</small></label><button type="submit">Create account</button></form><p class="auth-switch">Already registered? <a href="login.php">Sign in</a></p><p class="auth-note">Local accounts are not identity-verified. Add email verification before public deployment.</p></main></body></html>
