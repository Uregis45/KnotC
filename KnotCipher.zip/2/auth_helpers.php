<?php
declare(strict_types=1);
require_once __DIR__ . '/db.php';

function require_login_page(): void
{
    if (empty($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
}

function check_form_csrf(): bool
{
    $submitted = (string)($_POST['csrf_token'] ?? '');
    return $submitted !== '' && hash_equals((string)($_SESSION['csrf_token'] ?? ''), $submitted);
}

function redirect_after_auth(): void
{
    session_regenerate_id(true);
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    header('Location: index.php');
    exit;
}
