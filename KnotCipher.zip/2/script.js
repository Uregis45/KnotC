'use strict';

const app = document.getElementById('app');
const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
const currentUser = { id: Number(app?.dataset.userId || 0), name: app?.dataset.userName || 'User' };
const themes = ['ocean', 'forest', 'sunset', 'violet', 'slate'];
let room = null;
let cryptoKey = null;
let activePassphrase = '';
let keyIsSet = false;
let currentMode = 'classic';
let ghostTimer = 30;
let messageData = new Map();
let lastMessageId = 0;
let pollTimer = null;
let heartbeatTimer = null;
let polling = false;
let typingTimer = null;
let typingActive = false;

function showToast(message, duration = 3000) {
  let toast = document.getElementById('toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toast';
    toast.className = 'toast';
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.classList.add('show');
  window.setTimeout(() => toast.classList.remove('show'), duration);
}

async function api(action, { method = 'GET', params = {}, body = null } = {}) {
  const url = new URL('api.php', window.location.href);
  url.searchParams.set('action', action);
  for (const [key, value] of Object.entries(params)) url.searchParams.set(key, String(value));
  const options = { method, headers: { 'Accept': 'application/json' }, credentials: 'same-origin' };
  if (method === 'POST') {
    options.headers['Content-Type'] = 'application/json';
    options.headers['X-CSRF-Token'] = csrfToken;
    options.body = JSON.stringify(body || {});
  }
  const response = await fetch(url, options);
  const result = await response.json().catch(() => ({}));
  if (response.status === 401) { window.location.href = 'login.php'; throw new Error('Please sign in again.'); }
  if (!response.ok) throw new Error(result.error || `Request failed (${response.status}).`);
  return result;
}

function fromBase64(value) {
  const binary = atob(value);
  return Uint8Array.from(binary, char => char.charCodeAt(0));
}
function toBase64(bytes) {
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary);
}
async function deriveKey(passphrase, saltBase64) {
  const material = await crypto.subtle.importKey('raw', new TextEncoder().encode(passphrase), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt: fromBase64(saltBase64), iterations: 250000, hash: 'SHA-256' },
    material,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}
async function encryptMessage(text, key) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const cipher = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, new TextEncoder().encode(text));
  const packed = new Uint8Array(iv.length + cipher.byteLength);
  packed.set(iv);
  packed.set(new Uint8Array(cipher), iv.length);
  return toBase64(packed);
}
async function decryptMessage(encoded, key) {
  try {
    const packed = fromBase64(encoded);
    const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: packed.slice(0, 12) }, key, packed.slice(12));
    return new TextDecoder().decode(plain);
  } catch {
    return null;
  }
}

function setKeyStatus(text, color) {
  const status = document.getElementById('keyStatus');
  status.textContent = text;
  status.style.background = color;
}
function resetKey(message = '⚠️ No Knot Key set') {
  cryptoKey = null;
  activePassphrase = '';
  keyIsSet = false;
  document.getElementById('knotKeyInput').value = '';
  setKeyStatus(message, '#ff9800');
  renderAllMessages();
}
async function setKnotKey() {
  if (!room) return showToast('Join a room first.');
  const passphrase = document.getElementById('knotKeyInput').value;
  if (passphrase.length < 8) return showToast('Use a Knot Key with at least 8 characters.');
  setKeyStatus('⏳ Deriving key…', '#607d8b');
  try {
    cryptoKey = await deriveKey(passphrase, room.key_salt);
    activePassphrase = passphrase;
    keyIsSet = true;
    setKeyStatus('✅ Knot Key set for this room', '#4caf50');
    await renderAllMessages();
  } catch (error) {
    resetKey('❌ Could not derive key');
    showToast(error.message || 'Key setup failed.');
  }
}

function applyTheme(theme) {
  const chosen = themes.includes(theme) ? theme : 'ocean';
  document.body.dataset.theme = chosen;
  document.getElementById('themeSelect').value = chosen;
}
function setRoomStatus(text, color = '#4caf50') {
  const status = document.getElementById('roomStatus');
  status.textContent = text;
  status.style.background = color;
}
async function joinRoom() {
  const button = document.getElementById('joinRoomBtn');
  const name = document.getElementById('roomInput').value.trim();
  if (!name) return showToast('Enter a room name.');
  button.disabled = true;
  setRoomStatus('⏳ Joining room…', '#607d8b');
  try {
    const result = await api('join_room', { method: 'POST', body: { name } });
    room = result.room;
    messageData.clear();
    lastMessageId = 0;
    resetKey();
    document.getElementById('currentRoom').textContent = room.name;
    document.getElementById('rotateKeyBtn').disabled = !room.is_owner;
    document.getElementById('newKnotKeyInput').disabled = !room.is_owner;
    applyTheme(room.theme);
    setRoomStatus(`✅ Room: ${room.name}`);
    await pollRoom(true);
    await heartbeat();
    if (pollTimer) clearInterval(pollTimer);
    if (heartbeatTimer) clearInterval(heartbeatTimer);
    pollTimer = setInterval(() => pollRoom(false), 1800);
    heartbeatTimer = setInterval(heartbeat, 12000);
  } catch (error) {
    setRoomStatus('⚠️ Could not join room', '#d9534f');
    showToast(error.message);
  } finally {
    button.disabled = false;
  }
}

async function pollRoom(fullRefresh = false) {
  if (!room || polling) return;
  polling = true;
  try {
    const result = await api('poll', { params: { room_id: room.id, after: fullRefresh ? 0 : lastMessageId } });
    const oldVersion = room.key_version;
    room = result.room;
    const keyChanged = Boolean(oldVersion && room.key_version !== oldVersion);
    if (keyChanged) {
      resetKey('🔑 Room key changed — enter the new key');
      showToast('Room Knot Key changed. Enter the replacement key to read messages.');
      fullRefresh = true;
    }
    applyTheme(room.theme);
    document.getElementById('onlineCount').textContent = `${result.online} online`;
    const typing = result.typing || [];
    document.getElementById('typingIndicator').textContent = typing.length ? `${typing.join(', ')} ${typing.length === 1 ? 'is' : 'are'} typing…` : '';

    if (fullRefresh) messageData.clear();
    for (const id of (result.deleted_ids || [])) {
      messageData.delete(Number(id));
      document.querySelector(`.message[data-id="${Number(id)}"]`)?.remove();
    }
    for (const message of (result.messages || [])) {
      messageData.set(Number(message.id), message);
      lastMessageId = Math.max(lastMessageId, Number(message.id));
    }
    if (fullRefresh) await renderAllMessages();
    else {
      for (const message of (result.messages || [])) await renderMessage(message);
      if ((result.deleted_ids || []).length) await renderAllMessages();
    }
  } catch (error) {
    if (error.message) setRoomStatus('⚠️ Reconnecting…', '#d9534f');
  } finally {
    polling = false;
  }
}

async function heartbeat() {
  if (!room) return;
  try { await api('heartbeat', { method: 'POST', body: { room_id: room.id } }); } catch { /* next heartbeat retries */ }
}
async function updateTyping(isTyping) {
  if (!room) return;
  try { await api('typing', { method: 'POST', body: { room_id: room.id, typing: isTyping } }); } catch { /* best-effort presence */ }
}
function handleTyping() {
  const value = document.getElementById('messageInput').value.trim();
  if (value && !typingActive) {
    typingActive = true;
    updateTyping(true);
  }
  clearTimeout(typingTimer);
  typingTimer = setTimeout(() => {
    if (typingActive) updateTyping(false);
    typingActive = false;
  }, 1800);
}

function setMode(mode) {
  currentMode = mode;
  document.getElementById('classicModeBtn').classList.toggle('active', mode === 'classic');
  document.getElementById('ghostModeBtn').classList.toggle('active', mode === 'ghost');
  document.getElementById('ghostTimerContainer').style.display = mode === 'ghost' ? 'flex' : 'none';
  showToast(mode === 'ghost' ? '👻 Ghost messages expire for everyone.' : '📝 Classic messages stay until deleted.');
}
async function sendMessage(event) {
  event?.preventDefault();
  const input = document.getElementById('messageInput');
  const text = input.value.trim();
  if (!text) return;
  if (!room) return showToast('Join a room first.');
  if (!keyIsSet || !cryptoKey) return showToast('Set this room’s Knot Key first.');
  try {
    const encrypted = await encryptMessage(text, cryptoKey);
    const result = await api('send', { method: 'POST', body: { room_id: room.id, key_version: room.key_version, encrypted, mode: currentMode, ghost_timer: ghostTimer } });
    input.value = '';
    if (typingActive) updateTyping(false);
    typingActive = false;
    if (result.message) {
      messageData.set(Number(result.message.id), result.message);
      lastMessageId = Math.max(lastMessageId, Number(result.message.id));
      await renderMessage(result.message);
    }
  } catch (error) {
    showToast(error.message || 'Message could not be sent.');
  }
}

function formatTime(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? '' : date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
async function renderMessage(message) {
  const id = Number(message.id);
  const container = document.getElementById('messagesContainer');
  container.querySelector('.empty-placeholder')?.remove();
  const old = container.querySelector(`.message[data-id="${id}"]`);
  if (old) return;
  const own = Number(message.sender_id) === currentUser.id;
  const item = document.createElement('article');
  item.className = `message ${own ? 'sent' : 'received'}${message.mode === 'ghost' ? ' ghost-message' : ''}`;
  item.dataset.id = String(id);
  const meta = document.createElement('div');
  meta.className = 'msg-meta';
  if (!own) {
    const sender = document.createElement('span');
    sender.className = 'sender-name';
    sender.textContent = message.sender || 'Member';
    meta.append(sender);
  }
  if (message.mode === 'ghost') {
    const badge = document.createElement('span');
    badge.className = 'ghost-badge';
    badge.textContent = `👻 ${ghostSecondsRemaining(message.expires_at)}s`;
    meta.append(badge);
  }
  const bubble = document.createElement('div');
  bubble.className = 'message-bubble';
  const text = document.createElement('div');
  text.className = 'bubble-text';
  if (keyIsSet && cryptoKey) {
    const clear = await decryptMessage(message.encrypted, cryptoKey);
    text.textContent = clear === null ? '🔒 This message does not match the current key.' : clear;
    if (clear === null) text.classList.add('locked-msg');
  } else {
    text.textContent = '🔒 Set this room’s Knot Key to read.';
    text.classList.add('locked-msg');
  }
  const footer = document.createElement('div');
  footer.className = 'msg-footer';
  const time = document.createElement('span');
  time.className = 'msg-time';
  time.textContent = formatTime(message.timestamp);
  footer.append(time);
  if (own) {
    const tick = document.createElement('span');
    tick.className = 'msg-tick';
    tick.textContent = '✓';
    footer.append(tick);
  }
  bubble.append(text, footer);
  const encrypted = document.createElement('div');
  encrypted.className = 'message-encrypted';
  encrypted.textContent = `🔒 ${String(message.encrypted).slice(0, 24)}…`;
  item.append(meta, bubble, encrypted);
  container.append(item);
  container.scrollTop = container.scrollHeight;
}
function ghostSecondsRemaining(expiresAt) {
  if (!expiresAt) return 0;
  return Math.max(0, Math.ceil((new Date(expiresAt).getTime() - Date.now()) / 1000));
}
async function renderAllMessages() {
  const container = document.getElementById('messagesContainer');
  container.replaceChildren();
  const messages = [...messageData.values()].sort((a, b) => Number(a.id) - Number(b.id));
  if (!messages.length) {
    const empty = document.createElement('div');
    empty.className = 'empty-placeholder';
    empty.textContent = '💬 No messages yet. Send the first one when you’re ready.';
    container.append(empty);
    return;
  }
  for (const message of messages) await renderMessage(message);
  container.scrollTop = container.scrollHeight;
}

async function changeTheme() {
  if (!room) return;
  const theme = document.getElementById('themeSelect').value;
  try {
    await api('theme', { method: 'POST', body: { room_id: room.id, theme } });
    applyTheme(theme);
    showToast('Room theme updated for everyone.');
  } catch (error) {
    showToast(error.message || 'Could not change room theme.');
  }
}

async function rotateRoomKey() {
  const nextPassphrase = document.getElementById('newKnotKeyInput').value;
  if (!room || !room.is_owner) return showToast('Only the room owner can rotate this key.');
  if (!keyIsSet || !cryptoKey) return showToast('Enter the current Knot Key before rotating.');
  if (nextPassphrase.length < 8) return showToast('New Knot Key must be at least 8 characters.');
  if (nextPassphrase === activePassphrase) return showToast('Choose a different Knot Key.');
  if (!window.confirm('Rotate the room key and re-encrypt every stored message? Other members will need the new key.')) return;
  if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
  while (polling) await new Promise(resolve => setTimeout(resolve, 50));
  try {
    await pollRoom(true);
    if (!keyIsSet || !cryptoKey) throw new Error('The room key changed elsewhere. Re-enter the current key.');
    const oldKey = cryptoKey;
    const newSaltBytes = crypto.getRandomValues(new Uint8Array(16));
    const newSalt = toBase64(newSaltBytes);
    const newCryptoKey = await deriveKey(nextPassphrase, newSalt);
    const updates = [];
    for (const message of [...messageData.values()].sort((a, b) => Number(a.id) - Number(b.id))) {
      const clear = await decryptMessage(message.encrypted, oldKey);
      if (clear === null) throw new Error(`Could not decrypt message ${message.id}. Rotation cancelled; verify the current key.`);
      updates.push({ id: Number(message.id), encrypted: await encryptMessage(clear, newCryptoKey) });
    }
    const result = await api('rotate_key', { method: 'POST', body: { room_id: room.id, expected_version: room.key_version, new_salt: newSalt, updates } });
    room.key_version = Number(result.key_version);
    room.key_salt = result.key_salt;
    cryptoKey = newCryptoKey;
    activePassphrase = nextPassphrase;
    document.getElementById('knotKeyInput').value = nextPassphrase;
    document.getElementById('newKnotKeyInput').value = '';
    setKeyStatus('✅ Room key rotated', '#4caf50');
    await pollRoom(true);
    showToast('Key rotated. Share the new key with room members through a trusted channel.');
  } catch (error) {
    showToast(error.message || 'Key rotation failed. No key change was committed.');
  } finally {
    if (room && !pollTimer) pollTimer = setInterval(() => pollRoom(false), 1800);
  }
}

window.addEventListener('DOMContentLoaded', () => {
  document.getElementById('joinRoomBtn').addEventListener('click', joinRoom);
  document.getElementById('setKeyBtn').addEventListener('click', setKnotKey);
  document.getElementById('messageForm').addEventListener('submit', sendMessage);
  document.getElementById('messageInput').addEventListener('input', handleTyping);
  document.getElementById('roomInput').addEventListener('keydown', event => { if (event.key === 'Enter') joinRoom(); });
  document.getElementById('knotKeyInput').addEventListener('keydown', event => { if (event.key === 'Enter') setKnotKey(); });
  document.getElementById('classicModeBtn').addEventListener('click', () => setMode('classic'));
  document.getElementById('ghostModeBtn').addEventListener('click', () => setMode('ghost'));
  document.getElementById('ghostTimerSelect').addEventListener('change', event => { ghostTimer = Number(event.target.value); });
  document.getElementById('themeSelect').addEventListener('change', changeTheme);
  document.getElementById('rotateKeyBtn').addEventListener('click', rotateRoomKey);
  document.getElementById('toggleKeyVisibility').addEventListener('click', () => {
    const input = document.getElementById('knotKeyInput');
    const show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    document.getElementById('toggleKeyVisibility').textContent = show ? '🙈' : '👁️';
  });
  joinRoom();
});
