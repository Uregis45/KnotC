<?php
declare(strict_types=1);
require_once __DIR__ . '/db.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');

function json_response(array $payload, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}
function api_input(): array
{
    $raw = file_get_contents('php://input');
    $data = json_decode($raw ?: '{}', true);
    return is_array($data) ? $data : [];
}
function api_require_user(): int
{
    if (empty($_SESSION['user_id'])) json_response(['error' => 'Sign in required.'], 401);
    return (int)$_SESSION['user_id'];
}
function api_require_csrf(): void
{
    $token = (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if ($token === '' || !hash_equals((string)($_SESSION['csrf_token'] ?? ''), $token)) {
        json_response(['error' => 'Invalid session token. Refresh the page and try again.'], 419);
    }
}
function int_param(mixed $value): int
{
    $id = filter_var($value, FILTER_VALIDATE_INT);
    return $id === false ? 0 : (int)$id;
}
function require_room_member(PDO $pdo, int $roomId, int $userId): array
{
    if ($roomId < 1) json_response(['error' => 'Invalid room.'], 422);
    $stmt = $pdo->prepare('SELECT r.id, r.name, r.owner_user_id, r.theme, r.key_version, r.key_salt FROM rooms r JOIN room_members m ON m.room_id = r.id WHERE r.id = ? AND m.user_id = ? LIMIT 1');
    $stmt->execute([$roomId, $userId]);
    $room = $stmt->fetch();
    if (!$room) json_response(['error' => 'Room not found or access denied.'], 403);
    $room['is_owner'] = (int)$room['owner_user_id'] === $userId;
    $room['id'] = (int)$room['id'];
    $room['key_version'] = (int)$room['key_version'];
    return $room;
}
function clean_room_name(string $name): string
{
    $name = trim(preg_replace('/\s+/u', ' ', $name) ?? '');
    if (mb_strlen($name) < 2 || mb_strlen($name) > 48 || !preg_match('/^[\p{L}\p{N} _-]+$/u', $name)) {
        json_response(['error' => 'Room names must be 2–48 letters, numbers, spaces, underscores, or hyphens.'], 422);
    }
    return $name;
}
function purge_expired(PDO $pdo, int $roomId): array
{
    $stmt = $pdo->prepare("SELECT id FROM messages WHERE room_id = ? AND mode = 'ghost' AND expires_at IS NOT NULL AND expires_at <= UTC_TIMESTAMP()");
    $stmt->execute([$roomId]);
    $ids = array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
    if ($ids) {
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $delete = $pdo->prepare("DELETE FROM messages WHERE room_id = ? AND id IN ($placeholders)");
        $delete->execute(array_merge([$roomId], $ids));
    }
    return $ids;
}
function read_messages(PDO $pdo, int $roomId, int $afterId = 0): array
{
    if ($afterId > 0) {
        $sql = "SELECT m.id, m.sender_id, u.display_name AS sender, m.ciphertext AS encrypted, m.mode, m.expires_at, DATE_FORMAT(m.created_at, '%Y-%m-%dT%H:%i:%sZ') AS timestamp FROM messages m JOIN users u ON u.id = m.sender_id WHERE m.room_id = ? AND m.id > ? ORDER BY m.id ASC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$roomId, $afterId]);
    } else {
        $sql = "SELECT m.id, m.sender_id, u.display_name AS sender, m.ciphertext AS encrypted, m.mode, m.expires_at, DATE_FORMAT(m.created_at, '%Y-%m-%dT%H:%i:%sZ') AS timestamp FROM messages m JOIN users u ON u.id = m.sender_id WHERE m.room_id = ? ORDER BY m.id ASC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$roomId]);
    }
    $messages = $stmt->fetchAll();
    foreach ($messages as &$message) {
        $message['id'] = (int)$message['id'];
        $message['sender_id'] = (int)$message['sender_id'];
        if (!empty($message['expires_at'])) {
            $message['expires_at'] = str_replace(' ', 'T', $message['expires_at']) . 'Z';
        }
    }
    unset($message);
    return $messages;
}

$userId = api_require_user();
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$action = (string)($_GET['action'] ?? '');
if ($method === 'POST') api_require_csrf();
$body = $method === 'POST' ? api_input() : [];

try {
    $pdo = db();
    if ($method === 'POST' && $action === 'join_room') {
        $data = $body;
        $roomName = clean_room_name((string)($data['name'] ?? ''));
        $salt = base64_encode(random_bytes(16));
        $stmt = $pdo->prepare("INSERT INTO rooms (name, owner_user_id, theme, key_version, key_salt) VALUES (?, ?, 'ocean', 1, ?) ON DUPLICATE KEY UPDATE id = LAST_INSERT_ID(id)");
        $stmt->execute([$roomName, $userId, $salt]);
        $roomId = (int)$pdo->lastInsertId();
        $member = $pdo->prepare('INSERT IGNORE INTO room_members (room_id, user_id) VALUES (?, ?)');
        $member->execute([$roomId, $userId]);
        $room = require_room_member($pdo, $roomId, $userId);
        json_response(['room' => $room]);
    }

    $roomId = int_param($_GET['room_id'] ?? $body['room_id'] ?? 0);
    if ($action === 'poll' && $method === 'GET') {
        $room = require_room_member($pdo, $roomId, $userId);
        $deleted = purge_expired($pdo, $roomId);
        $afterId = int_param($_GET['after'] ?? 0);
        $messages = read_messages($pdo, $roomId, $afterId);
        $active = $pdo->prepare('SELECT COUNT(*) FROM room_presence WHERE room_id = ? AND last_seen >= UTC_TIMESTAMP() - INTERVAL 30 SECOND');
        $active->execute([$roomId]);
        $typing = $pdo->prepare('SELECT u.display_name FROM room_presence p JOIN users u ON u.id = p.user_id WHERE p.room_id = ? AND p.user_id <> ? AND p.is_typing = 1 AND p.last_seen >= UTC_TIMESTAMP() - INTERVAL 8 SECOND ORDER BY u.display_name');
        $typing->execute([$roomId, $userId]);
        json_response([
            'room' => $room,
            'messages' => $messages,
            'deleted_ids' => $deleted,
            'online' => (int)$active->fetchColumn(),
            'typing' => $typing->fetchAll(PDO::FETCH_COLUMN),
        ]);
    }

    if ($action === 'heartbeat' && $method === 'POST') {
        $data = $body;
        $roomId = int_param($data['room_id'] ?? 0);
        require_room_member($pdo, $roomId, $userId);
        $stmt = $pdo->prepare('INSERT INTO room_presence (room_id, user_id, last_seen, is_typing) VALUES (?, ?, UTC_TIMESTAMP(), 0) ON DUPLICATE KEY UPDATE last_seen = UTC_TIMESTAMP()');
        $stmt->execute([$roomId, $userId]);
        json_response(['ok' => true]);
    }

    if ($action === 'typing' && $method === 'POST') {
        $data = $body;
        $roomId = int_param($data['room_id'] ?? 0);
        require_room_member($pdo, $roomId, $userId);
        $typing = !empty($data['typing']) ? 1 : 0;
        $stmt = $pdo->prepare('INSERT INTO room_presence (room_id, user_id, last_seen, is_typing) VALUES (?, ?, UTC_TIMESTAMP(), ?) ON DUPLICATE KEY UPDATE last_seen = UTC_TIMESTAMP(), is_typing = VALUES(is_typing)');
        $stmt->execute([$roomId, $userId, $typing]);
        json_response(['ok' => true]);
    }

    if ($action === 'theme' && $method === 'POST') {
        $data = $body;
        $roomId = int_param($data['room_id'] ?? 0);
        require_room_member($pdo, $roomId, $userId);
        $theme = (string)($data['theme'] ?? '');
        $allowed = ['ocean', 'forest', 'sunset', 'violet', 'slate'];
        if (!in_array($theme, $allowed, true)) json_response(['error' => 'Choose a supported room theme.'], 422);
        $stmt = $pdo->prepare('UPDATE rooms SET theme = ? WHERE id = ?');
        $stmt->execute([$theme, $roomId]);
        json_response(['theme' => $theme]);
    }

    if ($action === 'send' && $method === 'POST') {
        $data = $body;
        $roomId = int_param($data['room_id'] ?? 0);
        require_room_member($pdo, $roomId, $userId);
        $encrypted = (string)($data['encrypted'] ?? '');
        $decoded = base64_decode($encrypted, true);
        if ($decoded === false || strlen($decoded) < 28 || strlen($decoded) > 16000) {
            json_response(['error' => 'Message payload is invalid or too large.'], 422);
        }
        $mode = (string)($data['mode'] ?? 'classic');
        if (!in_array($mode, ['classic', 'ghost'], true)) json_response(['error' => 'Invalid message mode.'], 422);
        $expiresAt = null;
        if ($mode === 'ghost') {
            $seconds = int_param($data['ghost_timer'] ?? 30);
            if (!in_array($seconds, [5, 15, 30, 60, 300], true)) json_response(['error' => 'Invalid self-destruct time.'], 422);
            $expiresAt = gmdate('Y-m-d H:i:s', time() + $seconds);
        }
        $expectedVersion = int_param($data['key_version'] ?? 0);
        $pdo->beginTransaction();
        try {
            // Serialize writes with key rotation so a stale-key message cannot slip
            // into the room while all previous ciphertexts are being re-encrypted.
            $lock = $pdo->prepare('SELECT key_version FROM rooms WHERE id = ? FOR UPDATE');
            $lock->execute([$roomId]);
            if ((int)$lock->fetchColumn() !== $expectedVersion) {
                $pdo->rollBack();
                json_response(['error' => 'The room key changed. Enter the new key before sending.'], 409);
            }
            $stmt = $pdo->prepare('INSERT INTO messages (room_id, sender_id, ciphertext, mode, expires_at) VALUES (?, ?, ?, ?, ?)');
            $stmt->execute([$roomId, $userId, $encrypted, $mode, $expiresAt]);
            $messageId = (int)$pdo->lastInsertId();
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            throw $e;
        }
        $messageStmt = $pdo->prepare("SELECT m.id, m.sender_id, u.display_name AS sender, m.ciphertext AS encrypted, m.mode, m.expires_at, DATE_FORMAT(m.created_at, '%Y-%m-%dT%H:%i:%sZ') AS timestamp FROM messages m JOIN users u ON u.id = m.sender_id WHERE m.room_id = ? AND m.id = ? LIMIT 1");
        $messageStmt->execute([$roomId, $messageId]);
        $message = $messageStmt->fetch();
        if ($message) {
            $message['id'] = (int)$message['id'];
            $message['sender_id'] = (int)$message['sender_id'];
            if (!empty($message['expires_at'])) $message['expires_at'] = str_replace(' ', 'T', $message['expires_at']) . 'Z';
        }
        json_response(['message' => $message], 201);
    }

    if ($action === 'rotate_key' && $method === 'POST') {
        $data = $body;
        $roomId = int_param($data['room_id'] ?? 0);
        $room = require_room_member($pdo, $roomId, $userId);
        if (!$room['is_owner']) json_response(['error' => 'Only the room creator can rotate its Knot Key.'], 403);
        $expectedVersion = int_param($data['expected_version'] ?? 0);
        if ($expectedVersion !== $room['key_version']) json_response(['error' => 'The room key changed in another session. Refresh and retry.'], 409);
        $newSalt = (string)($data['new_salt'] ?? '');
        $saltBytes = base64_decode($newSalt, true);
        if ($saltBytes === false || strlen($saltBytes) !== 16) json_response(['error' => 'Invalid new key salt.'], 422);
        $updates = $data['updates'] ?? null;
        if (!is_array($updates)) json_response(['error' => 'Invalid message re-encryption payload.'], 422);

        $pdo->beginTransaction();
        try {
            $lock = $pdo->prepare('SELECT key_version, owner_user_id FROM rooms WHERE id = ? FOR UPDATE');
            $lock->execute([$roomId]);
            $lockedRoom = $lock->fetch();
            if (!$lockedRoom || (int)$lockedRoom['owner_user_id'] !== $userId || (int)$lockedRoom['key_version'] !== $expectedVersion) {
                $pdo->rollBack();
                json_response(['error' => 'The room key changed or permissions changed. Reload and retry.'], 409);
            }
            $allIdsStmt = $pdo->prepare('SELECT id FROM messages WHERE room_id = ? ORDER BY id');
            $allIdsStmt->execute([$roomId]);
            $allIds = array_map('intval', $allIdsStmt->fetchAll(PDO::FETCH_COLUMN));
            $receivedIds = [];
            foreach ($updates as $item) {
                if (!is_array($item)) { $pdo->rollBack(); json_response(['error' => 'Invalid message update.'], 422); }
                $id = int_param($item['id'] ?? 0);
                $cipher = (string)($item['encrypted'] ?? '');
                $raw = base64_decode($cipher, true);
                if ($id < 1 || $raw === false || strlen($raw) < 28 || strlen($raw) > 16000) {
                    $pdo->rollBack(); json_response(['error' => 'Invalid encrypted message in rotation.'], 422);
                }
                $receivedIds[] = $id;
            }
            sort($receivedIds);
            if (count($receivedIds) !== count(array_unique($receivedIds)) || $receivedIds !== $allIds) {
                $pdo->rollBack();
                json_response(['error' => 'Rotation stopped because the loaded message set is incomplete. Reload the room and retry.'], 409);
            }
            $updateStmt = $pdo->prepare('UPDATE messages SET ciphertext = ? WHERE id = ? AND room_id = ?');
            foreach ($updates as $item) $updateStmt->execute([(string)$item['encrypted'], (int)$item['id'], $roomId]);
            $roomUpdate = $pdo->prepare('UPDATE rooms SET key_salt = ?, key_version = key_version + 1 WHERE id = ? AND key_version = ?');
            $roomUpdate->execute([$newSalt, $roomId, $expectedVersion]);
            if ($roomUpdate->rowCount() !== 1) {
                $pdo->rollBack(); json_response(['error' => 'Could not commit key rotation. Retry after reloading.'], 409);
            }
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            throw $e;
        }
        json_response(['key_version' => $expectedVersion + 1, 'key_salt' => $newSalt]);
    }

    json_response(['error' => 'Unknown API action.'], 404);
} catch (PDOException $e) {
    error_log($e->getMessage());
    json_response(['error' => 'Database request failed. Check XAMPP and schema.sql.'], 500);
} catch (Throwable $e) {
    error_log($e->getMessage());
    json_response(['error' => 'Server error. Check the PHP error log.'], 500);
}
