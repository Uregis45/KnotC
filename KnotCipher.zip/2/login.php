<?php
declare(strict_types=1);
require_once __DIR__ . '/auth_helpers.php';
if (!empty($_SESSION['user_id'])) { header('Location: index.php'); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!check_form_csrf()) {
        $error = 'Your session expired. Refresh and try again.';
    } else {
        $email = strtolower(trim((string)($_POST['email'] ?? '')));
        $password = (string)($_POST['password'] ?? '');
        $stmt = db()->prepare('SELECT id, display_name, password_hash FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if (!$user || !password_verify($password, $user['password_hash'])) {
            $error = 'Email or password is incorrect.';
        } else {
            $_SESSION['user_id'] = (int)$user['id'];
            $_SESSION['display_name'] = $user['display_name'];
            redirect_after_auth();
        }
    }
}
?><!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Sign in · KnotCipher</title><link rel="stylesheet" href="style.css"></head>
<body class="auth-body"><main class="auth-card"><div class="auth-mark">🔐</div><h1>Welcome back</h1><p class="auth-subtitle">Sign in to continue to KnotCipher.</p>
<?php if ($error): ?><p class="auth-error" role="alert"><?= escape_html($error) ?></p><?php endif; ?>
<form method="post" action="login.php" class="auth-form"><input type="hidden" name="csrf_token" value="<?= escape_html(csrf_token()) ?>"><label>Email<input type="email" name="email" maxlength="190" autocomplete="email" required></label><label>Password<input type="password" name="password" autocomplete="current-password" required></label><button type="submit">Sign in</button></form><p class="auth-switch">New to KnotCipher? <a href="register.php">Create an account</a></p></main></body></html>
