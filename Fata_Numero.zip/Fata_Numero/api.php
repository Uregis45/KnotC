<?php
declare(strict_types=1);
require_once __DIR__ . '/db.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');

const MAX_ACTIVE_TICKETS = 3;
const ISO = "%Y-%m-%dT%H:%i:%sZ";

function fail(string $code, int $status = 422): never { json_out(['error' => $code], $status); }

function need_user(): array
{
    $u = current_user();
    if (!$u) fail('auth', 401);
    return $u;
}
function need_admin(): array
{
    $u = need_user();
    if ($u['role'] !== 'admin') fail('forbidden', 403);
    return $u;
}
function client_ip(): string { return (string)($_SERVER['REMOTE_ADDR'] ?? 'unknown'); }

// ---- brute-force throttling -------------------------------------------------
function attempts(PDO $pdo, string $kind, string $id, int $minutes): int
{
    $s = $pdo->prepare('SELECT COUNT(*) FROM auth_attempts WHERE kind = ? AND identifier = ? AND created_at > UTC_TIMESTAMP() - INTERVAL ? MINUTE');
    $s->execute([$kind, $id, $minutes]);
    return (int)$s->fetchColumn();
}
function log_attempt(PDO $pdo, string $kind, string $id): void
{
    $pdo->prepare('INSERT INTO auth_attempts (kind, identifier) VALUES (?, ?)')->execute([$kind, $id]);
    if (random_int(1, 50) === 1) $pdo->exec('DELETE FROM auth_attempts WHERE created_at < UTC_TIMESTAMP() - INTERVAL 1 DAY');
}

// ---- auth -------------------------------------------------------------------
function do_register(PDO $pdo, array $d): never
{
    $ip = client_ip();
    if (attempts($pdo, 'register', $ip, 60) >= 10) fail('too_many', 429);
    $name = trim((string)($d['name'] ?? ''));
    $email = strtolower(trim((string)($d['email'] ?? '')));
    $phone = preg_replace('/[\s-]+/', '', (string)($d['phone'] ?? ''));
    $pw = (string)($d['password'] ?? '');
    if (mb_strlen($name) < 2 || mb_strlen($name) > 80) fail('bad_name');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) fail('bad_email');
    if (!preg_match('/^(\+?250|0)?7[2389]\d{7}$/', $phone)) fail('bad_phone');
    if (strlen($pw) < 10) fail('bad_password');
    log_attempt($pdo, 'register', $ip);

    $pdo->beginTransaction();
    try {
        // The very first account on a fresh install becomes the administrator.
        $first = (int)$pdo->query('SELECT COUNT(*) FROM users FOR UPDATE')->fetchColumn() === 0;
        $stmt = $pdo->prepare('INSERT INTO users (name, email, phone, password_hash, role) VALUES (?, ?, ?, ?, ?)');
        $stmt->execute([$name, $email, $phone, password_hash($pw, PASSWORD_DEFAULT), $first ? 'admin' : 'user']);
        $id = (int)$pdo->lastInsertId();
        $pdo->commit();
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        if ($e->getCode() === '23000') fail('email_taken', 409);
        throw $e;
    }
    session_regenerate_id(true);
    $_SESSION['user_id'] = $id;
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
    json_out(['ok' => true]);
}

function do_login(PDO $pdo, array $d): never
{
    $email = strtolower(trim((string)($d['email'] ?? '')));
    $pw = (string)($d['password'] ?? '');
    $ip = client_ip();
    if (attempts($pdo, 'login', $email, 15) >= 5 || attempts($pdo, 'login_ip', $ip, 15) >= 30) fail('too_many', 429);

    $stmt = $pdo->prepare('SELECT id, password_hash FROM users WHERE email = ?');
    $stmt->execute([$email]);
    $u = $stmt->fetch();
    // Always run a hash check so response time doesn't reveal whether the email exists.
    $hash = $u['password_hash'] ?? '$2y$10$XNQ1WtmIRgbWT1EbgLMV..tU.kJVb3DU.cDZ4YcTYUxVfbY5vmeBi';
    if (!password_verify($pw, $hash) || !$u) {
        log_attempt($pdo, 'login', $email);
        log_attempt($pdo, 'login_ip', $ip);
        fail('bad_login', 401);
    }
    $pdo->prepare("DELETE FROM auth_attempts WHERE kind = 'login' AND identifier = ?")->execute([$email]);
    if (password_needs_rehash($hash, PASSWORD_DEFAULT)) {
        $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([password_hash($pw, PASSWORD_DEFAULT), $u['id']]);
    }
    session_regenerate_id(true);
    $_SESSION['user_id'] = (int)$u['id'];
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
    json_out(['ok' => true]);
}

function do_logout(): never
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
    json_out(['ok' => true]);
}

// ---- state (everything the UI needs in one poll) -----------------------------
function ticket_number(string $prefix, int $seq): string { return $prefix . '-' . str_pad((string)$seq, 3, '0', STR_PAD_LEFT); }

function build_state(PDO $pdo, ?array $user): array
{
    $out = ['user' => $user, 'csrf' => csrf_token()];
    if (!$user) return $out;
    $isAdmin = $user['role'] === 'admin';
    $day = today();

    $services = $pdo->query("SELECT id, prefix, name, org, category, icon, locations, avg_wait_min, is_active FROM services " . ($isAdmin ? '' : 'WHERE is_active = 1 ') . "ORDER BY FIELD(category,'bank','coop','health','gov','other'), id")->fetchAll();

    $waiting = []; // service_id => [seq, seq, ...]
    $q = $pdo->prepare("SELECT service_id, seq FROM tickets WHERE ticket_date = ? AND status = 'waiting' ORDER BY seq");
    $q->execute([$day]);
    foreach ($q->fetchAll() as $r) $waiting[(int)$r['service_id']][] = (int)$r['seq'];

    $serving = []; // service_id => ticket number
    $nowServing = [];
    $q = $pdo->prepare("SELECT t.service_id, t.seq, s.prefix, s.name, s.icon FROM tickets t JOIN services s ON s.id = t.service_id WHERE t.ticket_date = ? AND t.status = 'serving' ORDER BY t.called_at DESC");
    $q->execute([$day]);
    foreach ($q->fetchAll() as $r) {
        $num = ticket_number($r['prefix'], (int)$r['seq']);
        $serving[(int)$r['service_id']] = $serving[(int)$r['service_id']] ?? $num;
        $nowServing[] = ['number' => $num, 'service_name' => $r['name'], 'icon' => $r['icon']];
    }

    // Learn real service time from today's finished tickets (need 3+ samples), else use the configured value.
    $actual = [];
    $q = $pdo->prepare("SELECT service_id, AVG(TIMESTAMPDIFF(SECOND, called_at, completed_at)) AS sec, COUNT(*) AS n FROM tickets WHERE ticket_date = ? AND status = 'done' AND called_at IS NOT NULL AND completed_at IS NOT NULL GROUP BY service_id");
    $q->execute([$day]);
    foreach ($q->fetchAll() as $r) if ((int)$r['n'] >= 3) $actual[(int)$r['service_id']] = max(1, (int)ceil(((float)$r['sec']) / 60));

    $avg = [];
    foreach ($services as &$s) {
        $sid = (int)$s['id'];
        $s['id'] = $sid;
        $s['is_active'] = (int)$s['is_active'] === 1;
        $s['avg_wait_min'] = (int)$s['avg_wait_min'];
        $avg[$sid] = $actual[$sid] ?? $s['avg_wait_min'];
        $s['per_person_min'] = $avg[$sid];
        $s['waiting'] = count($waiting[$sid] ?? []);
        $s['serving'] = $serving[$sid] ?? null;
    }
    unset($s);

    $q = $pdo->prepare("SELECT t.id, t.service_id, t.seq, t.status, DATE_FORMAT(t.created_at,'" . ISO . "') AS created_at, DATE_FORMAT(t.called_at,'" . ISO . "') AS called_at, s.prefix, s.name AS service_name, s.icon FROM tickets t JOIN services s ON s.id = t.service_id WHERE t.user_id = ? AND t.ticket_date = ? ORDER BY t.id DESC");
    $q->execute([$user['id'], $day]);
    $mine = [];
    foreach ($q->fetchAll() as $t) {
        $sid = (int)$t['service_id'];
        $ahead = 0;
        if ($t['status'] === 'waiting') foreach ($waiting[$sid] ?? [] as $w) if ($w < (int)$t['seq']) $ahead++;
        $mine[] = [
            'id' => (int)$t['id'], 'service_id' => $sid, 'service_name' => $t['service_name'], 'icon' => $t['icon'],
            'number' => ticket_number($t['prefix'], (int)$t['seq']), 'status' => $t['status'],
            'ahead' => $ahead, 'est_wait' => $t['status'] === 'waiting' ? $ahead * ($avg[$sid] ?? 10) : 0,
            'created_at' => $t['created_at'], 'called_at' => $t['called_at'],
        ];
    }

    $out += ['services' => $services, 'tickets' => $mine, 'now_serving' => $nowServing];

    if ($isAdmin) {
        $q = $pdo->prepare("SELECT t.id, t.seq, t.status, DATE_FORMAT(t.created_at,'" . ISO . "') AS created_at, s.prefix, s.name AS service_name, s.icon, u.name AS user_name, u.phone FROM tickets t JOIN services s ON s.id = t.service_id JOIN users u ON u.id = t.user_id WHERE t.ticket_date = ? ORDER BY t.id DESC LIMIT 200");
        $q->execute([$day]);
        $all = array_map(fn($t) => [
            'id' => (int)$t['id'], 'number' => ticket_number($t['prefix'], (int)$t['seq']), 'status' => $t['status'],
            'service_name' => $t['service_name'], 'icon' => $t['icon'], 'user_name' => $t['user_name'], 'phone' => $t['phone'], 'created_at' => $t['created_at'],
        ], $q->fetchAll());
        $st = $pdo->prepare("SELECT COUNT(*) AS total, COALESCE(SUM(status='waiting'),0) AS waiting, COALESCE(SUM(status='serving'),0) AS serving, COALESCE(SUM(status='done'),0) AS done, COALESCE(SUM(status IN ('cancelled','no_show')),0) AS dropped, AVG(CASE WHEN called_at IS NOT NULL THEN TIMESTAMPDIFF(SECOND, created_at, called_at) END) AS avg_wait_sec FROM tickets WHERE ticket_date = ?");
        $st->execute([$day]);
        $r = $st->fetch();
        $out['admin'] = [
            'tickets' => $all,
            'stats' => [
                'total' => (int)$r['total'], 'waiting' => (int)$r['waiting'], 'serving' => (int)$r['serving'],
                'done' => (int)$r['done'], 'dropped' => (int)$r['dropped'],
                'avg_wait_min' => $r['avg_wait_sec'] === null ? null : (int)round(((float)$r['avg_wait_sec']) / 60),
            ],
        ];
    }
    return $out;
}

// ---- tickets ----------------------------------------------------------------
function do_take_ticket(PDO $pdo, array $user, array $d): never
{
    $sid = (int)($d['service_id'] ?? 0);
    $day = today();
    $pdo->beginTransaction();
    try {
        // Locking the service row serialises everyone taking a number for it, so numbers never collide.
        $s = $pdo->prepare('SELECT id, prefix, name, is_active FROM services WHERE id = ? FOR UPDATE');
        $s->execute([$sid]);
        $svc = $s->fetch();
        if (!$svc || !(int)$svc['is_active']) { $pdo->rollBack(); fail('no_service', 404); }

        $c = $pdo->prepare("SELECT COUNT(*) FROM tickets WHERE user_id = ? AND ticket_date = ? AND status IN ('waiting','serving')");
        $c->execute([$user['id'], $day]);
        if ((int)$c->fetchColumn() >= MAX_ACTIVE_TICKETS) { $pdo->rollBack(); fail('too_many_tickets', 409); }
        $c = $pdo->prepare("SELECT COUNT(*) FROM tickets WHERE user_id = ? AND service_id = ? AND ticket_date = ? AND status IN ('waiting','serving')");
        $c->execute([$user['id'], $sid, $day]);
        if ((int)$c->fetchColumn() > 0) { $pdo->rollBack(); fail('already_in_queue', 409); }

        $n = $pdo->prepare('SELECT COALESCE(MAX(seq), 0) + 1 FROM tickets WHERE service_id = ? AND ticket_date = ?');
        $n->execute([$sid, $day]);
        $seq = (int)$n->fetchColumn();
        $pdo->prepare('INSERT INTO tickets (service_id, user_id, ticket_date, seq) VALUES (?, ?, ?, ?)')->execute([$sid, $user['id'], $day, $seq]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
    json_out(['number' => ticket_number($svc['prefix'], $seq), 'service_name' => $svc['name']], 201);
}

function do_cancel(PDO $pdo, array $user, array $d): never
{
    $s = $pdo->prepare("UPDATE tickets SET status = 'cancelled', completed_at = UTC_TIMESTAMP() WHERE id = ? AND user_id = ? AND status = 'waiting'");
    $s->execute([(int)($d['ticket_id'] ?? 0), $user['id']]);
    if ($s->rowCount() !== 1) fail('cannot_cancel', 409);
    json_out(['ok' => true]);
}

function do_call_next(PDO $pdo, array $d): never
{
    $sid = (int)($d['service_id'] ?? 0);
    $day = today();
    $pdo->beginTransaction();
    try {
        $s = $pdo->prepare('SELECT id, prefix FROM services WHERE id = ? FOR UPDATE');
        $s->execute([$sid]);
        $svc = $s->fetch();
        if (!$svc) { $pdo->rollBack(); fail('no_service', 404); }
        // Calling the next person finishes whoever was at the counter.
        $pdo->prepare("UPDATE tickets SET status = 'done', completed_at = UTC_TIMESTAMP() WHERE service_id = ? AND ticket_date = ? AND status = 'serving'")->execute([$sid, $day]);
        $n = $pdo->prepare("SELECT id, seq FROM tickets WHERE service_id = ? AND ticket_date = ? AND status = 'waiting' ORDER BY seq LIMIT 1");
        $n->execute([$sid, $day]);
        $next = $n->fetch();
        if (!$next) { $pdo->commit(); json_out(['called' => null]); }
        $pdo->prepare("UPDATE tickets SET status = 'serving', called_at = UTC_TIMESTAMP() WHERE id = ?")->execute([$next['id']]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
    json_out(['called' => ticket_number($svc['prefix'], (int)$next['seq'])]);
}

function do_finish(PDO $pdo, array $d, string $status): never
{
    $s = $pdo->prepare("UPDATE tickets SET status = ?, completed_at = UTC_TIMESTAMP() WHERE id = ? AND status = 'serving'");
    $s->execute([$status, (int)($d['ticket_id'] ?? 0)]);
    if ($s->rowCount() !== 1) fail('cannot_update', 409);
    json_out(['ok' => true]);
}

// ---- services (admin) ---------------------------------------------------------
function make_prefix(PDO $pdo, string $name): string
{
    $letters = strtoupper(preg_replace('/[^A-Za-z]/', '', iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $name) ?: $name));
    $base = substr(str_pad($letters, 2, 'X'), 0, 2);
    $chk = $pdo->prepare('SELECT 1 FROM services WHERE prefix = ?');
    $candidates = [$base];
    if (strlen($letters) >= 3) $candidates[] = substr($letters, 0, 3);
    for ($i = 1; $i <= 99; $i++) $candidates[] = $base . $i;
    foreach ($candidates as $p) {
        $chk->execute([$p]);
        if (!$chk->fetchColumn()) return $p;
    }
    fail('prefix_failed', 500);
}

function do_add_service(PDO $pdo, array $d): never
{
    $name = trim((string)($d['name'] ?? ''));
    $org = trim((string)($d['org'] ?? ''));
    $cat = (string)($d['category'] ?? 'other');
    $loc = trim((string)($d['locations'] ?? '')) ?: 'Rwanda';
    $wait = (int)($d['avg_wait_min'] ?? 15);
    $icon = trim((string)($d['icon'] ?? '🏢'));
    if (mb_strlen($name) < 2 || mb_strlen($name) > 80 || mb_strlen($org) < 2 || mb_strlen($org) > 120) fail('bad_service');
    if (!in_array($cat, ['bank', 'coop', 'health', 'gov', 'other'], true)) fail('bad_service');
    if (mb_strlen($loc) > 190 || mb_strlen($icon) > 8) fail('bad_service');
    $wait = max(1, min(120, $wait));
    for ($try = 0; $try < 3; $try++) {
        try {
            $pdo->prepare('INSERT INTO services (prefix, name, org, category, icon, locations, avg_wait_min) VALUES (?, ?, ?, ?, ?, ?, ?)')
                ->execute([make_prefix($pdo, $name), $name, $org, $cat, $icon, $loc, $wait]);
            json_out(['ok' => true], 201);
        } catch (PDOException $e) {
            if ($e->getCode() !== '23000') throw $e; // prefix raced with another admin: retry
        }
    }
    fail('prefix_failed', 500);
}

function do_toggle_service(PDO $pdo, array $d): never
{
    $pdo->prepare('UPDATE services SET is_active = IF(is_active = 1, 0, 1) WHERE id = ?')->execute([(int)($d['service_id'] ?? 0)]);
    json_out(['ok' => true]);
}

// ---- router -------------------------------------------------------------------
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$action = (string)($_GET['action'] ?? '');
try {
    $pdo = db();
    if ($method === 'GET' && $action === 'state') json_out(build_state($pdo, current_user()));
    if ($method !== 'POST') fail('not_found', 404);
    require_csrf();
    $d = body();
    switch ($action) {
        case 'register': do_register($pdo, $d);
        case 'login': do_login($pdo, $d);
        case 'logout': do_logout();
        case 'take_ticket': do_take_ticket($pdo, need_user(), $d);
        case 'cancel_ticket': do_cancel($pdo, need_user(), $d);
        case 'call_next': need_admin(); do_call_next($pdo, $d);
        case 'complete': need_admin(); do_finish($pdo, $d, 'done');
        case 'no_show': need_admin(); do_finish($pdo, $d, 'no_show');
        case 'add_service': need_admin(); do_add_service($pdo, $d);
        case 'toggle_service': need_admin(); do_toggle_service($pdo, $d);
    }
    fail('not_found', 404);
} catch (PDOException $e) {
    error_log($e->getMessage());
    json_out(['error' => 'db'], 500);
} catch (Throwable $e) {
    error_log($e->getMessage());
    json_out(['error' => 'server'], 500);
}
