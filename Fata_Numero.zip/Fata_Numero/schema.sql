SET NAMES utf8mb4;
CREATE DATABASE IF NOT EXISTS fata_numero CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE fata_numero;

CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  phone VARCHAR(20) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('user','admin') NOT NULL DEFAULT 'user',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS services (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  prefix VARCHAR(4) NOT NULL UNIQUE,
  name VARCHAR(80) NOT NULL,
  org VARCHAR(120) NOT NULL,
  category ENUM('bank','coop','health','gov','other') NOT NULL DEFAULT 'other',
  icon VARCHAR(16) NOT NULL DEFAULT '🏢',
  locations VARCHAR(190) NOT NULL DEFAULT 'Rwanda',
  avg_wait_min SMALLINT UNSIGNED NOT NULL DEFAULT 15,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS tickets (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  service_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  ticket_date DATE NOT NULL,
  seq INT UNSIGNED NOT NULL,
  status ENUM('waiting','serving','done','cancelled','no_show') NOT NULL DEFAULT 'waiting',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  called_at TIMESTAMP NULL DEFAULT NULL,
  completed_at TIMESTAMP NULL DEFAULT NULL,
  UNIQUE KEY uq_ticket_seq (service_id, ticket_date, seq),
  KEY idx_ticket_user (user_id, ticket_date),
  KEY idx_ticket_queue (service_id, ticket_date, status),
  CONSTRAINT fk_tickets_service FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE,
  CONSTRAINT fk_tickets_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS auth_attempts (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  kind VARCHAR(16) NOT NULL,
  identifier VARCHAR(190) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_attempts (kind, identifier, created_at)
) ENGINE=InnoDB;

-- Starter catalogue (safe to re-run: existing prefixes are skipped)
INSERT IGNORE INTO services (prefix, name, org, category, icon, locations, avg_wait_min) VALUES
  ('BK', 'Bank of Kigali', 'Bank of Kigali (BK)', 'bank', '🏦', 'Kigali, Huye, Musanze, Rubavu, Muhanga, Rwamagana', 8),
  ('EQ', 'Equity Bank Rwanda', 'Equity Bank Rwanda Ltd', 'bank', '🏦', 'Kigali, Musanze, Huye, Rubavu', 10),
  ('IM', 'I&M Bank Rwanda', 'I&M Bank Rwanda', 'bank', '🏦', 'Kigali, Muhanga, Huye', 9),
  ('KC', 'KCB Rwanda', 'KCB Bank Rwanda', 'bank', '🏦', 'Kigali, Musanze, Rubavu, Huye', 7),
  ('CG', 'Cogebanque', 'Compagnie Générale de Banque', 'bank', '🏦', 'Kigali, Muhanga, Musanze', 12),
  ('GT', 'GT Bank Rwanda', 'Guaranty Trust Bank Rwanda', 'bank', '🏦', 'Kigali', 9),
  ('NC', 'Ncba Rwanda', 'NCBA Bank Rwanda', 'bank', '🏦', 'Kigali', 8),
  ('EB', 'Ecobank Rwanda', 'Ecobank Rwanda', 'bank', '🏦', 'Kigali, Huye, Musanze', 11),
  ('BP', 'BPR Atlas Mara', 'BPR Atlas Mara Bank', 'bank', '🏦', 'Kigali, Nyanza, Huye, Rwamagana, Musanze', 10),
  ('UB', 'Urwego Bank', 'Urwego Opportunity Bank', 'bank', '🏦', 'Kigali, Musanze, Huye, Rwamagana', 13),
  ('UM', 'Umurimo SACCO', 'Umurimo Savings & Credit SACCO', 'coop', '🌿', 'Kigali — Nyarugenge', 20),
  ('VF', 'Vision SACCO', 'Vision Finance Company SACCO', 'coop', '🌿', 'Kigali, Musanze, Huye, Muhanga', 18),
  ('AC', 'ACLEDA Rwanda', 'ACLEDA Rwanda MFI', 'coop', '🌿', 'Kigali, Muhanga', 15),
  ('CJ', 'CLECAM Ejoheza', 'CLECAM Ejoheza SACCO', 'coop', '🌿', 'Kigali — Kicukiro', 22),
  ('ZC', 'Zigama CSS', 'Zigama Credit & Savings Society', 'coop', '🌿', 'Kigali, Huye, Ruhango', 16),
  ('IK', 'Inkunga SACCO', 'Inkunga Cooperative SACCO', 'coop', '🌿', 'Musanze, Rulindo', 25),
  ('UW', 'Umwalimu SACCO', 'Umwalimu Savings & Credit Coop', 'coop', '🌿', 'Kigali — Gasabo, Kicukiro, Nyarugenge', 19),
  ('CP', 'COPEDU', 'COPEDU PLC SACCO', 'coop', '🌿', 'Kigali, Muhanga, Nyanza', 17),
  ('GF', 'Goshen Finance', 'Goshen Finance SACCO', 'coop', '🌿', 'Kigali — Nyarugenge', 21),
  ('UK', 'SACCO Urukundo', 'Urukundo Community SACCO', 'coop', '🌿', 'Huye, Nyamagabe', 28),
  ('CH', 'CHUK', 'Centre Hospitalier Univ. de Kigali', 'health', '🏥', 'Kigali — Nyarugenge', 35),
  ('KF', 'King Faisal Hospital', 'King Faisal Hospital Rwanda', 'health', '🏥', 'Kigali — Kacyiru', 30),
  ('HB', 'CHUB', 'CHU de Butare', 'health', '🏥', 'Huye', 32),
  ('MK', 'Masaka Hospital', 'Masaka District Hospital', 'health', '🏥', 'Kigali — Kicukiro', 28),
  ('KB', 'Kibagabaga Hospital', 'Kibagabaga District Hospital', 'health', '🏥', 'Kigali — Gasabo', 26),
  ('RR', 'RRA — Ikodi', 'Rwanda Revenue Authority', 'gov', '🏛️', 'Kigali, Huye, Musanze, Rubavu, Muhanga', 22),
  ('RS', 'RSSB', 'Rwanda Social Security Board', 'gov', '🏛️', 'Kigali — Kacyiru', 18),
  ('RD', 'RDB', 'Rwanda Development Board', 'gov', '🏛️', 'Kigali — Kimihurura', 15),
  ('ND', 'NIDA', 'Nat. Identification Agency', 'gov', '🏛️', 'Kigali, Huye, Musanze, all Districts', 20),
  ('IR', 'Irembo Services', 'Irembo Gov. Portal', 'gov', '🏛️', 'All Districts', 12);
