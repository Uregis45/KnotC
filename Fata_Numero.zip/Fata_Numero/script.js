'use strict';
// ═══════════════════════════════════════════
// i18n — English (default) + Kinyarwanda
// ═══════════════════════════════════════════
const I18N = {
  en: {
    cat_all: '🇷🇼 All', cat_bank: '🏦 Banks', cat_coop: '🌿 SACCOs', cat_health: '🏥 Health', cat_gov: '🏛️ Government', cat_other: '🏢 Other',
    lbl_bank: 'Bank', lbl_coop: 'SACCO', lbl_health: 'Health', lbl_gov: 'Government', lbl_other: 'Other',
    made_in: '🇷🇼 Made in Rwanda', tagline: 'Rwanda Queue System',
    nav_dashboard: '⚙ Dashboard', nav_services: '➕ Services', nav_queue: '📋 My Queue', nav_home: 'Home', signout: 'Sign out',
    login_h: 'Cut the line. Save your time.', login_p: 'Take a queue number from your phone, then follow your place in line live — at banks, SACCOs, hospitals and government offices across Rwanda.',
    stat_services: 'Rwandan services', stat_banks: 'Banks', stat_saccos: 'SACCOs', stat_live: 'Live updates',
    welcome_back: 'Welcome back 👋', login_sub: 'Sign in to take your number.', email: 'Email', password: 'Password', sign_in: 'Sign in →',
    no_account: 'No account yet?', create_here: 'Create one', have_account: 'Already registered?', sign_in_here: 'Sign in',
    signup_h: 'Create an account. Take a number. Skip the wait.', signup_p: 'Sign up in seconds and start using FATA NUMERO at banks, SACCOs, hospitals and government offices.',
    signup_title: 'Create account 🚀', signup_sub: 'It takes less than a minute.', full_name: 'Full name', phone: 'Phone', pw_hint: 'At least 10 characters', create_btn: 'Create account →',
    please_wait: '⏳ Please wait…',
    welcome: 'Welcome, {n}! 🇷🇼', hero_p: 'Choose a service below — banks, SACCOs, hospitals and government offices across Rwanda.',
    now_serving: 'Now serving', choose_service: 'Choose a service', n_services: '({n} services)', take_number: '🎫 Take a number',
    in_queue_banner: 'You are in the queue', ahead_n: '{n} ahead of you', view_queue: 'View queue →',
    per_person: '~{n} min per person', waiting_n: '{n} waiting',
    got_number: '✅ You have a number!', your_number: 'Your number', ahead: 'Ahead', est_min: '~Minutes', time: 'Time', back: 'Back',
    queue_title: 'Live Queue', my_tickets: 'My tickets', no_ticket: 'You have no number right now', no_ticket_p: 'Go back and take a number for the service you need.',
    your_turn: '🔔 IT\'S YOUR TURN!', go_counter: 'Please go to the counter', position: 'Place', in_front: 'Ahead', est: '~Min',
    cancel: 'Cancel ticket', cancel_confirm: 'Cancel this ticket and leave the queue?', cancelled: 'Ticket cancelled.',
    status_waiting: 'Waiting', status_serving: 'Serving', status_done: 'Done', status_cancelled: 'Cancelled', status_no_show: 'No-show',
    now_label: 'Now', where_now: 'Where things stand', free: 'Free', active: 'Active', ticker_serving: '🔔 Now serving: {n}', ticker_idle: '✅ No one is being served — take your number!',
    admin_title: 'Admin Dashboard 🇷🇼', admin_sub: "Manage today's queues", refresh: '↻ Refresh',
    s_total: 'Total today', s_total_s: 'Tickets taken', s_waiting: 'Waiting', s_waiting_s: 'In queue', s_serving: 'Serving', s_serving_s: 'At counters', s_done: 'Completed', s_done_s: 'Served', s_dropped: 'Dropped', s_dropped_s: 'Cancelled / no-show', s_avg: 'Avg. wait', s_avg_s: 'Minutes to be called',
    svc_ops: 'Services — call next', tix_today: "Today's tickets", th_service: 'Service', th_now: 'Serving', th_waiting: 'Waiting', th_min: 'Min/person', th_action: 'Action', th_number: 'Number', th_name: 'Name', th_phone: 'Phone', th_time: 'Time', th_status: 'Status',
    call_next: 'Call next →', complete: '✓ Complete', no_show: 'No-show', disable: 'Disable', enable: 'Enable', disabled_tag: 'disabled',
    none_today: 'Nothing yet today.', queue_empty_svc: 'Nobody waiting for {n}.', called: '🔔 Called {n}',
    add_title: 'Add a service 🇷🇼', add_sub: 'Add a bank, SACCO, clinic or any office to FATA NUMERO', add_card: '➕ New service', f_name: 'Short name *', f_name_ph: 'e.g. Inzira SACCO', f_org: 'Full organisation name *', f_org_ph: 'e.g. Inzira Community Savings SACCO',
    f_type: 'Type *', f_loc: 'Location', f_loc_ph: 'Kigali, Huye…', f_wait: 'Minutes per person', f_icon: 'Icon', add_btn: '✅ Add service', added: '✅ {n} added!', all_services: '📋 All services',
    footer: 'Queue management for Rwanda', footer_sub: 'Banks · SACCOs · Health · Government · and more',
    lang_switch: 'Kinyarwanda',
    n_ahead_toast: 'You are next in line for {n}!', turn_toast: '🔔 {n} — it\'s your turn! Go to the counter.',
    ticket_taken: 'Number {n} taken! 🎫',
    err_auth: 'Please sign in again.', err_csrf: 'Session expired. Refresh the page.', err_forbidden: 'Not allowed.',
    err_bad_login: 'Email or password is incorrect.', err_too_many: 'Too many attempts. Try again in a few minutes.',
    err_bad_name: 'Enter your full name (2–80 characters).', err_bad_email: 'Enter a valid email address.', err_bad_phone: 'Enter a valid Rwandan phone number (e.g. 0788 123 456).', err_bad_password: 'Use a password of at least 10 characters.', err_email_taken: 'An account with that email already exists.',
    err_no_service: 'That service is not available.', err_already_in_queue: 'You already have a number for this service.', err_too_many_tickets: 'You can hold at most 3 active tickets.',
    err_cannot_cancel: 'This ticket can no longer be cancelled.', err_cannot_update: 'That ticket is not being served.', err_bad_service: 'Please check the service details.',
    err_db: 'Database error. Check that MySQL is running and schema.sql is imported.', err_server: 'Server error. Please try again.', err_network: 'Cannot reach the server.', err_generic: 'Something went wrong.',
    fill_all: '⚠ Please fill in every field.',
  },
  rw: {
    cat_all: '🇷🇼 Byose', cat_bank: '🏦 Banki', cat_coop: '🌿 Ibimina', cat_health: '🏥 Ubuzima', cat_gov: '🏛️ Leta', cat_other: '🏢 Ikindi',
    lbl_bank: 'Banki', lbl_coop: 'Ikimina', lbl_health: 'Ubuzima', lbl_gov: 'Leta', lbl_other: 'Ikindi',
    made_in: '🇷🇼 Made in Rwanda', tagline: 'Sisitemu y\'imirongo y\'u Rwanda',
    nav_dashboard: '⚙ Dashboard', nav_services: '➕ Serivisi', nav_queue: '📋 Murongo', nav_home: 'Ahabanza', signout: 'Sohoka',
    login_h: 'Gabanya umurongo. Ubike igihe.', login_p: 'Fata numero kuri telefoni, ukurikirane umwanya wawe mu murongo — muri banki, ibimina, ibitaro n\'ibiro bya leta mu Rwanda hose.',
    stat_services: 'Serivisi z\'u Rwanda', stat_banks: 'Banki', stat_saccos: 'Ibimina', stat_live: 'Amakuru ako kanya',
    welcome_back: 'Murakaza neza 👋', login_sub: 'Injira kugira ngo ufate numero.', email: 'Imeli', password: 'Ijambo banga', sign_in: 'Injira →',
    no_account: 'Nta konti ufite?', create_here: 'Iyandikishe', have_account: 'Usanzwe ufite konti?', sign_in_here: 'Injira',
    signup_h: 'Fungura konti. Fata numero. Wirinde gutegereza.', signup_p: 'Iyandikishe mu masegonda make utangire gukoresha FATA NUMERO.',
    signup_title: 'Iyandikishe 🚀', signup_sub: 'Bifata munsi y\'umunota.', full_name: 'Amazina yose', phone: 'Telefoni', pw_hint: 'Byibuze inyuguti 10', create_btn: 'Iyandikishe →',
    please_wait: '⏳ Tegereza…',
    welcome: 'Murakaza neza, {n}! 🇷🇼', hero_p: 'Hitamo serivisi hasi — banki, ibimina, ibitaro n\'ibiro bya leta byo mu Rwanda.',
    now_serving: 'Ubu barimo gukorera', choose_service: 'Hitamo serivisi', n_services: '({n} serivisi)', take_number: '🎫 Fata numero',
    in_queue_banner: 'Uri mu murongo', ahead_n: 'Abantu {n} bakuri imbere', view_queue: 'Reba murongo →',
    per_person: '~{n} min kuri buri muntu', waiting_n: '{n} bategereje',
    got_number: '✅ Numero yawe ifashwe!', your_number: 'Numero yawe', ahead: 'Imbere', est_min: '~Iminota', time: 'Saa', back: 'Subira inyuma',
    queue_title: 'Murongo uri kugenda', my_tickets: 'Numero zanjye', no_ticket: 'Nta numero ufite ubu', no_ticket_p: 'Subira inyuma maze ufate numero ya serivisi ushaka.',
    your_turn: '🔔 URASHYIRWA IMBERE!', go_counter: 'Genda kuri guichet', position: 'Umwanya', in_front: 'Imbere', est: '~Min',
    cancel: 'Reka numero', cancel_confirm: 'Reka iyi numero usohoke mu murongo?', cancelled: 'Numero yavuyemo.',
    status_waiting: 'Gutegereza', status_serving: 'Gukorerwa', status_done: 'Byarangiye', status_cancelled: 'Yavuyemo', status_no_show: 'Ntiyaje',
    now_label: 'Ubu', where_now: 'Uko bimeze ubu', free: 'Nta wukorerwa', active: 'Irakora', ticker_serving: '🔔 Ubu gukorerwa: {n}', ticker_idle: '✅ Nta wukorerwa — fata numero yawe!',
    admin_title: 'Admin Dashboard 🇷🇼', admin_sub: 'Cunga imirongo y\'uyu munsi', refresh: '↻ Vugurura',
    s_total: 'Yose uyu munsi', s_total_s: 'Numero zafashwe', s_waiting: 'Bategereje', s_waiting_s: 'Mu murongo', s_serving: 'Gukorerwa', s_serving_s: 'Kuri guichet', s_done: 'Byarangiye', s_done_s: 'Bakorewe', s_dropped: 'Basohotse', s_dropped_s: 'Yavuyemo / ntiyaje', s_avg: 'Igihe cyo gutegereza', s_avg_s: 'Iminota kugeza ahamagawe',
    svc_ops: 'Serivisi — hamagara ukurikira', tix_today: 'Numero z\'uyu munsi', th_service: 'Serivisi', th_now: 'Ubu', th_waiting: 'Bategereje', th_min: 'Min/muntu', th_action: 'Igikorwa', th_number: 'Numero', th_name: 'Izina', th_phone: 'Telefoni', th_time: 'Saa', th_status: 'Imimerere',
    call_next: 'Hamagara →', complete: '✓ Rangiza', no_show: 'Ntiyaje', disable: 'Hagarika', enable: 'Fungura', disabled_tag: 'ihagaritswe',
    none_today: 'Nta kintu uyu munsi.', queue_empty_svc: 'Nta muntu utegereje {n}.', called: '🔔 Hamagawe {n}',
    add_title: 'Ongera serivisi 🇷🇼', add_sub: 'Ongera banki, ikimina, ivuriro cyangwa ibiro muri FATA NUMERO', add_card: '➕ Serivisi nshya', f_name: 'Izina rigufi *', f_name_ph: 'Urugero: SACCO Inzira', f_org: 'Izina ryuzuye *', f_org_ph: 'Urugero: Inzira Community Savings SACCO',
    f_type: 'Ubwoko *', f_loc: 'Aho iherereye', f_loc_ph: 'Kigali, Huye…', f_wait: 'Iminota kuri buri muntu', f_icon: 'Ikimenyetso', add_btn: '✅ Ongera serivisi', added: '✅ {n} yongewemo!', all_services: '📋 Serivisi zose',
    footer: 'Gucunga imirongo mu Rwanda', footer_sub: 'Banki · Ibimina · Ubuzima · Leta · n\'ibindi',
    lang_switch: 'English',
    n_ahead_toast: 'Uri hafi guhamagarwa kuri {n}!', turn_toast: '🔔 {n} — ni wowe! Genda kuri guichet.',
    ticket_taken: 'Numero {n} ifashwe! 🎫',
    err_auth: 'Ongera winjire.', err_bad_login: 'Imeli cyangwa ijambo banga siyo.', err_too_many: 'Wagerageje kenshi. Ongera ugerageze nyuma y\'iminota mike.',
    err_email_taken: 'Imeli isanzwe irimo konti.', err_bad_password: 'Ijambo banga rigomba kuba byibuze inyuguti 10.',
    err_already_in_queue: 'Usanzwe ufite numero kuri iyi serivisi.', err_too_many_tickets: 'Ushobora kugira numero 3 gusa zikora.',
    fill_all: '⚠ Uzuza ahantu hose.',
  },
};
let lang = 'en';
try { lang = localStorage.getItem('fn_lang') === 'rw' ? 'rw' : 'en'; } catch {}
function t(key, vars) {
  let s = (I18N[lang] && I18N[lang][key]) ?? I18N.en[key] ?? key;
  if (vars) for (const [k, v] of Object.entries(vars)) s = s.split('{' + k + '}').join(v);
  return s;
}
function toggleLang() {
  lang = lang === 'en' ? 'rw' : 'en';
  try { localStorage.setItem('fn_lang', lang); } catch {}
  document.documentElement.lang = lang;
  render();
}

// ═══════════════════════════════════════════
// Helpers
// ═══════════════════════════════════════════
const $ = id => document.getElementById(id);
// Everything that came from the server or a user goes through esc() before it touches innerHTML.
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const initials = n => String(n).split(/\s+/).filter(Boolean).map(x => x[0]).join('').toUpperCase().slice(0, 2);
const fmtTime = iso => iso ? new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—';
const CAT_KEYS = ['all', 'bank', 'coop', 'health', 'gov', 'other'];

const S = { user: null, csrf: '', services: [], tickets: [], nowServing: [], admin: null };
let page = 'login', curCat = 'all', selSvc = null, pollTimer = null, polling = false;
let lastStatus = new Map(), notifiedNext = new Set();

function toast(msg, type = 'd', dur = 3500) {
  const el = document.createElement('div');
  el.className = 'toast ' + (type === 's' ? 's' : type === 'e' ? 'e' : type === 'w' ? 'w' : '');
  const icons = { s: '✓', e: '✕', w: '⚠', d: 'ℹ' };
  el.innerHTML = `<span>${icons[type] || icons.d}</span><span>${esc(msg)}</span>`;
  $('tw').appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transform = 'translateX(60px)'; el.style.transition = 'all .3s'; setTimeout(() => el.remove(), 300); }, dur);
}
function showModal(html) {
  closeModal();
  const ov = document.createElement('div');
  ov.className = 'modal-ov'; ov.id = 'modal-ov';
  ov.innerHTML = `<div class="modal">${html}</div>`;
  ov.addEventListener('click', e => { if (e.target === ov) closeModal(); });
  document.body.appendChild(ov);
}
function closeModal() { $('modal-ov')?.remove(); }

async function api(action, body) {
  let res;
  try {
    res = await fetch('api.php?action=' + encodeURIComponent(action), body === undefined
      ? { credentials: 'same-origin', headers: { Accept: 'application/json' } }
      : { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': S.csrf }, body: JSON.stringify(body) });
  } catch { throw new ApiError('network'); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    if (res.status === 401 && S.user) { S.user = null; stopPolling(); go('login'); }
    throw new ApiError(data.error || 'generic');
  }
  return data;
}
class ApiError extends Error { constructor(code) { super(code); this.code = code; } }
const errText = e => e instanceof ApiError ? t('err_' + e.code) !== 'err_' + e.code ? t('err_' + e.code) : t('err_generic') : t('err_generic');

function applyState(d) {
  const prev = S.user?.id;
  S.csrf = d.csrf; S.user = d.user;
  S.services = d.services || []; S.tickets = d.tickets || []; S.nowServing = d.now_serving || []; S.admin = d.admin || null;
  if (prev && !d.user) stopPolling();
}
async function loadState() { applyState(await api('state')); }

function go(p) {
  page = p;
  if (p !== 'home') selSvc = null;
  render();
}

// ═══════════════════════════════════════════
// Live updates
// ═══════════════════════════════════════════
function startPolling() { stopPolling(); pollTimer = setInterval(poll, 4000); }
function stopPolling() { if (pollTimer) clearInterval(pollTimer); pollTimer = null; }
async function poll() {
  if (polling || document.hidden || !S.user || $('modal-ov')) return;
  if (!['home', 'queue', 'admin'].includes(page)) return;
  polling = true;
  try {
    await loadState();
    notifyChanges();
    render(true);
  } catch {} finally { polling = false; }
}
function notifyChanges() {
  for (const tk of S.tickets) {
    const before = lastStatus.get(tk.id);
    if (before === 'waiting' && tk.status === 'serving') {
      toast(t('turn_toast', { n: tk.number }), 's', 8000);
      flashTitle(tk.number);
      try { navigator.vibrate?.([200, 100, 200]); } catch {}
    } else if (tk.status === 'waiting' && tk.ahead === 0 && !notifiedNext.has(tk.id)) {
      notifiedNext.add(tk.id);
      if (before !== undefined) toast(t('n_ahead_toast', { n: tk.service_name }), 'w', 6000);
    }
    lastStatus.set(tk.id, tk.status);
  }
}
let flashTimer = null;
function flashTitle(num) {
  clearInterval(flashTimer);
  const base = 'FATA NUMERO — Rwanda Queue System';
  let on = false, n = 0;
  flashTimer = setInterval(() => { document.title = on ? base : '🔔 ' + num; on = !on; if (++n > 20) { clearInterval(flashTimer); document.title = base; } }, 800);
}
function seedStatuses() { lastStatus = new Map(S.tickets.map(x => [x.id, x.status])); notifiedNext = new Set(S.tickets.filter(x => x.status === 'waiting' && x.ahead === 0).map(x => x.id)); }

// ═══════════════════════════════════════════
// Shared UI
// ═══════════════════════════════════════════
const langBtn = () => `<button class="btn-sm" onclick="toggleLang()">🌐 ${esc(t('lang_switch'))}</button>`;
function topbar() {
  const u = S.user, admin = u.role === 'admin';
  return `<div class="topbar"><div class="topbar-in">
    <div class="logo" onclick="go('${admin ? 'admin' : 'home'}')"><div class="logo-mark">🎫</div>
      <div class="logo-text"><div class="logo-name">FATA NUMERO</div><div class="logo-tag">${esc(t('tagline'))}</div></div></div>
    <div class="topbar-right">
      <div class="made-rw">${esc(t('made_in'))}</div>
      ${admin ? `<button class="btn-sm admin" onclick="go('admin')">${esc(t('nav_dashboard'))}</button><button class="btn-sm" onclick="go('services')">${esc(t('nav_services'))}</button>` : ''}
      <button class="btn-sm" onclick="go('home')">${esc(t('nav_home'))}</button>
      <button class="btn-sm" onclick="go('queue')">${esc(t('nav_queue'))}</button>
      ${langBtn()}
      <div class="user-chip" onclick="logout()" title="${esc(t('signout'))}"><div class="av">${esc(initials(u.name))}</div><span>${esc(u.name.split(' ')[0])}</span><span style="color:var(--ink3);font-size:11px">↗</span></div>
    </div></div></div>`;
}
const footer = () => `<div class="footer"><div class="mirw" style="display:inline-flex;margin-bottom:10px">${esc(t('made_in'))}</div>
  <div><strong>FATA NUMERO</strong> — ${esc(t('footer'))}</div><div style="margin-top:6px;font-size:12px">${esc(t('footer_sub'))}</div></div>`;
const catLabel = c => t('lbl_' + c);
const statusLabel = s => t('status_' + s);
const statusBadge = s => ({ waiting: 'badge-blue', serving: 'badge-gold', done: 'badge-green', cancelled: 'badge-gray', no_show: 'badge-red' }[s] || 'badge-gray');
const stripes = () => `<div class="al-rw"><div class="rw-block" style="background:var(--rw-blue)"></div><div class="rw-block" style="background:var(--rw-yellow)"></div><div class="rw-block" style="background:var(--rw-green)"></div></div>`;

// ═══════════════════════════════════════════
// Auth pages
// ═══════════════════════════════════════════
function pageLogin() {
  return `<div class="auth-wrap" style="padding-top:5px"><div class="auth-left">${stripes()}
    <div class="al-logo"><div class="al-logo-icon">🎫</div><div class="al-logo-text"><div class="name">FATA NUMERO</div><div class="tag">${esc(t('tagline'))}</div></div></div>
    <div class="al-content"><h1>${esc(t('login_h'))}</h1><p>${esc(t('login_p'))}</p></div>
    <div class="al-stats">
      <div class="al-stat"><div class="al-stat-n">30+</div><div class="al-stat-l">${esc(t('stat_services'))}</div></div>
      <div class="al-stat"><div class="al-stat-n">10</div><div class="al-stat-l">${esc(t('stat_banks'))}</div></div>
      <div class="al-stat"><div class="al-stat-n">10</div><div class="al-stat-l">${esc(t('stat_saccos'))}</div></div>
      <div class="al-stat"><div class="al-stat-n">⚡</div><div class="al-stat-l">${esc(t('stat_live'))}</div></div></div></div>
    <div class="auth-right"><div class="auth-box">
      <div style="text-align:right;margin-bottom:8px">${langBtn()}</div>
      <h2>${esc(t('welcome_back'))}</h2><p class="sub">${esc(t('login_sub'))}</p>
      <div class="fg"><label class="fl" for="l-em">${esc(t('email'))}</label><input class="fi" type="email" id="l-em" autocomplete="email" placeholder="you@example.com"/></div>
      <div class="fg"><label class="fl" for="l-pw">${esc(t('password'))}</label><input class="fi" type="password" id="l-pw" autocomplete="current-password" placeholder="••••••••••"/><div class="err-msg" id="l-err"></div></div>
      <button class="btn btn-primary btn-full btn-lg" id="l-btn" onclick="doLogin()">${esc(t('sign_in'))}</button>
      <div class="auth-switch">${esc(t('no_account'))} <a onclick="go('signup')">${esc(t('create_here'))}</a></div>
    </div></div></div>`;
}
function showErr(id, msg) { const e = $(id); e.textContent = '⚠ ' + msg; e.style.display = 'block'; }
async function doLogin() {
  const email = $('l-em').value.trim(), password = $('l-pw').value;
  $('l-err').style.display = 'none';
  if (!email || !password) return showErr('l-err', t('fill_all').replace('⚠ ', ''));
  const btn = $('l-btn'); btn.disabled = true; btn.textContent = t('please_wait');
  try {
    await api('login', { email, password });
    await enter();
  } catch (e) {
    showErr('l-err', errText(e));
    btn.disabled = false; btn.textContent = t('sign_in');
    try { await loadState(); } catch {}   // a fresh CSRF token follows every login attempt
  }
}
function pageSignup() {
  return `<div class="auth-wrap" style="padding-top:5px"><div class="auth-left">${stripes()}
    <div class="al-logo"><div class="al-logo-icon">🎫</div><div class="al-logo-text"><div class="name">FATA NUMERO</div><div class="tag">${esc(t('made_in'))}</div></div></div>
    <div class="al-content"><h1>${esc(t('signup_h'))}</h1><p>${esc(t('signup_p'))}</p></div></div>
    <div class="auth-right"><div class="auth-box">
      <div style="text-align:right;margin-bottom:8px">${langBtn()}</div>
      <h2>${esc(t('signup_title'))}</h2><p class="sub">${esc(t('signup_sub'))}</p>
      <div class="fg"><label class="fl" for="su-n">${esc(t('full_name'))}</label><input class="fi" id="su-n" autocomplete="name" placeholder="Kalisa Mugisha"/></div>
      <div class="fg"><label class="fl" for="su-e">${esc(t('email'))}</label><input class="fi" type="email" id="su-e" autocomplete="email" placeholder="you@example.com"/></div>
      <div class="fg"><label class="fl" for="su-t">${esc(t('phone'))}</label><input class="fi" type="tel" id="su-t" autocomplete="tel" placeholder="07XX XXX XXX"/></div>
      <div class="fg"><label class="fl" for="su-p">${esc(t('password'))}</label><input class="fi" type="password" id="su-p" autocomplete="new-password" placeholder="${esc(t('pw_hint'))}"/><div class="err-msg" id="su-err"></div></div>
      <button class="btn btn-primary btn-full btn-lg" id="su-btn" onclick="doSignup()">${esc(t('create_btn'))}</button>
      <div class="auth-switch">${esc(t('have_account'))} <a onclick="go('login')">${esc(t('sign_in_here'))}</a></div>
    </div></div></div>`;
}
async function doSignup() {
  const body = { name: $('su-n').value.trim(), email: $('su-e').value.trim(), phone: $('su-t').value.trim(), password: $('su-p').value };
  $('su-err').style.display = 'none';
  if (!body.name || !body.email || !body.phone || !body.password) return showErr('su-err', t('fill_all').replace('⚠ ', ''));
  const btn = $('su-btn'); btn.disabled = true; btn.textContent = t('please_wait');
  try { await api('register', body); await enter(); }
  catch (e) { showErr('su-err', errText(e)); btn.disabled = false; btn.textContent = t('create_btn'); try { await loadState(); } catch {} }
}
async function enter() {
  await loadState();
  seedStatuses();
  toast(t('welcome', { n: S.user.name }), 's');
  go(S.user.role === 'admin' ? 'admin' : 'home');
  startPolling();
}
async function logout() {
  try { await api('logout', {}); } catch {}
  stopPolling();
  S.user = null; selSvc = null;
  try { await loadState(); } catch {}
  go('login');
}

// ═══════════════════════════════════════════
// Home
// ═══════════════════════════════════════════
function pageHome() {
  const active = S.tickets.find(x => x.status === 'waiting' || x.status === 'serving');
  const svcs = S.services.filter(s => s.is_active && (curCat === 'all' || s.category === curCat));
  const ns = S.nowServing.slice(0, 2).map(x => `<div style="font-family:var(--mono);font-size:30px;letter-spacing:3px;color:#fff">${esc(x.number)}</div><div style="font-size:11px;opacity:.55;margin-bottom:4px">${esc(x.service_name)}</div>`).join('')
    || `<div style="font-family:var(--mono);font-size:30px;color:rgba(255,255,255,.4);letter-spacing:3px">—</div>`;
  const cards = svcs.map((s, i) => `<div class="svc-card${selSvc === s.id ? ' sel' : ''}" id="sc-${s.id}" onclick="pickSvc(${s.id})" style="animation-delay:${Math.min(i * 35, 400)}ms">
      <div class="svc-q">${s.waiting}</div><span class="svc-badge ${esc(s.category)}">${esc(catLabel(s.category))}</span>
      <div class="svc-inner"><span class="svc-icon">${esc(s.icon)}</span><div class="svc-name">${esc(s.name)}</div><div class="svc-org">${esc(s.org)}</div>
      <div class="svc-wait">🕐 ${esc(t('per_person', { n: s.per_person_min }))} · <span style="font-size:11px;color:var(--ink3)">${esc((s.locations || '').split(',')[0])}</span></div></div></div>`).join('');
  const banner = active ? `<div class="active-banner"><div class="ab-icon">${esc(active.icon)}</div><div style="flex:1">
      <div style="font-size:12px;color:var(--green);font-weight:600;margin-bottom:2px">${esc(t('in_queue_banner'))}</div>
      <div style="font-family:var(--mono);font-size:24px;font-weight:500;color:var(--green-m);letter-spacing:2px">${esc(active.number)}</div>
      <div style="font-size:13px;color:var(--ink3)">${esc(active.service_name)} · ${esc(t('ahead_n', { n: active.ahead }))}</div></div>
      <button class="btn btn-outline" onclick="go('queue')">${esc(t('view_queue'))}</button></div>` : '';
  const pills = CAT_KEYS.map(c => `<div class="cat-pill${curCat === c ? ' active' : ''}" onclick="setCat('${c}')">${esc(t('cat_' + c))}</div>`).join('');
  return `${topbar()}<div class="page"><div class="hero"><div class="hero-rw"></div><div class="hero-in">
      <div class="hero-text"><h1>${esc(t('welcome', { n: S.user.name.split(' ')[0] }))}</h1><p>${esc(t('hero_p'))}</p></div>
      <div class="ns-panel"><div class="ns-label">${esc(t('now_serving'))}</div>${ns}</div></div></div>
    <div class="main">${banner}<div class="cat-pills">${pills}</div>
      <div class="section-title"><span>${esc(t('choose_service'))}</span><span style="font-size:13px;color:var(--ink3);font-weight:400">${esc(t('n_services', { n: svcs.length }))}</span></div>
      <div class="svc-grid">${cards}</div>
      <div style="display:flex;gap:12px;max-width:600px"><button class="btn btn-primary btn-lg" id="btn-fata" onclick="takeNumber()" ${selSvc ? '' : 'disabled'} style="flex:1">${esc(t('take_number'))}</button>
      <button class="btn btn-ghost" onclick="go('queue')" style="padding:16px 20px">📋</button></div></div></div>${footer()}`;
}
function setCat(c) { curCat = c; selSvc = null; render(); }
function pickSvc(id) {
  selSvc = id;
  document.querySelectorAll('.svc-card').forEach(el => el.classList.remove('sel'));
  $('sc-' + id)?.classList.add('sel');
  const b = $('btn-fata'); if (b) b.disabled = false;
}
async function takeNumber() {
  if (!selSvc) return;
  const btn = $('btn-fata'); btn.disabled = true;
  try {
    const r = await api('take_ticket', { service_id: selSvc });
    await loadState(); seedStatuses();
    const tk = S.tickets.find(x => x.number === r.number);
    selSvc = null;
    showModal(`<div class="modal-rw"></div><div class="modal-header"><h3>${esc(t('got_number'))}</h3><div style="font-size:13px;opacity:.7;margin-top:4px">${esc(r.service_name)}</div></div>
      <div class="modal-body"><div class="ticket-big"><div class="t-label">${esc(t('your_number'))} · ${esc(new Date().toLocaleDateString())}</div><div class="t-num">${esc(r.number)}</div><div class="t-tag">${esc(tk?.icon || '')} ${esc(r.service_name)}</div></div>
      <div class="ticket-stats"><div class="ts-item"><div class="tsl">${esc(t('ahead'))}</div><div class="tsv">${tk ? tk.ahead : '—'}</div></div>
      <div class="ts-item"><div class="tsl">${esc(t('est_min'))}</div><div class="tsv">${tk ? tk.est_wait : '—'}</div></div>
      <div class="ts-item"><div class="tsl">${esc(t('time'))}</div><div class="tsv" style="font-size:15px">${esc(fmtTime(tk?.created_at))}</div></div></div>
      <button class="btn btn-primary btn-full" style="margin-bottom:10px" onclick="closeModal();go('queue')">${esc(t('view_queue'))}</button>
      <button class="btn btn-ghost btn-full" onclick="closeModal();render()">${esc(t('back'))}</button></div>`);
    toast(t('ticket_taken', { n: r.number }), 's');
  } catch (e) { toast(errText(e), 'e'); btn.disabled = false; }
  render(true);
}

// ═══════════════════════════════════════════
// Queue
// ═══════════════════════════════════════════
function pageQueue() {
  const mine = S.tickets.filter(x => x.status === 'waiting' || x.status === 'serving');
  const history = S.tickets.filter(x => x.status !== 'waiting' && x.status !== 'serving');
  const cards = mine.map(a => {
    const serving = a.status === 'serving';
    return `<div class="q-panel"><div class="ticket-card" style="${serving ? 'background:linear-gradient(135deg,var(--gold),#A87C0A);' : ''}">
      <div class="tc-label">${esc(serving ? t('your_turn') : t('your_number'))}</div><div class="tc-num">${esc(a.number)}</div><div class="tc-svc">${esc(a.icon)} ${esc(a.service_name)}</div>
      ${serving ? `<div style="margin-top:10px;font-weight:600">${esc(t('go_counter'))}</div>` : `<div class="tc-meta">
        <div class="tc-meta-i"><div class="ml">${esc(t('position'))}</div><div class="mv">#${a.ahead + 1}</div></div>
        <div class="tc-meta-i"><div class="ml">${esc(t('in_front'))}</div><div class="mv">${a.ahead}</div></div>
        <div class="tc-meta-i"><div class="ml">${esc(t('est'))}</div><div class="mv">${a.est_wait}</div></div></div>`}</div>
      <div class="q-status"><button class="btn btn-ghost" style="width:100%" onclick="cancelTicket(${a.id})" ${serving ? 'disabled' : ''}>${esc(t('cancel'))}</button></div></div>`;
  }).join('') || `<div style="text-align:center;padding:48px 24px;background:var(--white);border-radius:var(--rx);border:1px solid var(--border);margin-bottom:24px">
      <div style="font-size:52px;margin-bottom:12px">🎫</div><div style="font-family:var(--fm);font-size:20px;font-weight:700;margin-bottom:8px">${esc(t('no_ticket'))}</div>
      <p style="color:var(--ink3);font-size:14px;margin-bottom:20px">${esc(t('no_ticket_p'))}</p><button class="btn btn-primary" onclick="go('home')">← ${esc(t('take_number'))}</button></div>`;
  const board = S.services.filter(s => s.is_active && (s.waiting || s.serving)).concat(S.services.filter(s => s.is_active && !s.waiting && !s.serving)).slice(0, 12).map(s => `
    <div style="background:var(--white);border-radius:var(--rl);border:1px solid var(--border);padding:16px;box-shadow:var(--shadow)">
      <div style="display:flex;align-items:center;justify-content:space-between"><div style="display:flex;align-items:center;gap:10px"><span style="font-size:20px">${esc(s.icon)}</span>
        <div><div style="font-family:var(--fm);font-weight:700;font-size:13px">${esc(s.name)}</div><div style="font-size:11px;color:var(--ink3)">${esc(t('waiting_n', { n: s.waiting }))}</div></div></div>
        <span class="badge ${s.serving ? 'badge-gold' : 'badge-gray'}">${esc(s.serving ? t('active') : t('free'))}</span></div>
      ${s.serving ? `<div style="background:var(--gold-l);border-radius:8px;padding:8px 12px;margin-top:10px;font-size:12px;color:var(--gold);font-weight:600">${esc(t('now_label'))}: ${esc(s.serving)}</div>` : ''}</div>`).join('');
  const hist = history.length ? `<div class="section-title">${esc(t('status_done'))}</div><div class="tbl-wrap" style="margin-bottom:24px"><table><tbody>${history.map(h => `<tr><td class="tn">${esc(h.number)}</td><td>${esc(h.service_name)}</td><td><span class="badge ${statusBadge(h.status)}">${esc(statusLabel(h.status))}</span></td></tr>`).join('')}</tbody></table></div>` : '';
  const tick = S.nowServing.length ? t('ticker_serving', { n: S.nowServing.map(x => x.number).join(', ') }) : t('ticker_idle');
  return `${topbar()}<div class="page"><div class="main">
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;flex-wrap:wrap"><button class="btn btn-ghost" onclick="go('home')" style="padding:8px 14px;font-size:13px">← ${esc(t('back'))}</button>
      <h2 style="font-family:var(--fm);font-size:22px;font-weight:700">${esc(t('queue_title'))}</h2>
      <div class="ticker" style="margin:0;flex:1"><div class="t-dot"></div><div class="ticker-txt">${esc(tick)}</div></div></div>
    <div class="section-title">${esc(t('my_tickets'))}</div>${cards}${hist}
    <div class="section-title">${esc(t('where_now'))}</div><div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px;margin-bottom:24px">${board}</div>
  </div></div>${footer()}`;
}
async function cancelTicket(id) {
  if (!confirm(t('cancel_confirm'))) return;
  try { await api('cancel_ticket', { ticket_id: id }); toast(t('cancelled'), 's'); await loadState(); seedStatuses(); render(true); }
  catch (e) { toast(errText(e), 'e'); }
}

// ═══════════════════════════════════════════
// Admin
// ═══════════════════════════════════════════
function pageAdmin() {
  const st = S.admin.stats;
  const rows = S.services.filter(s => s.is_active).map(s => `<tr><td><span style="font-size:16px">${esc(s.icon)}</span></td>
    <td><div style="font-weight:600;font-size:13px">${esc(s.name)}</div><div style="font-size:11px;color:var(--ink3)">${esc(s.org)}</div></td>
    <td>${s.serving ? `<span class="badge badge-gold">${esc(s.serving)}</span>` : '<span class="badge badge-gray">—</span>'}</td>
    <td><strong>${s.waiting}</strong></td><td>~${s.per_person_min}</td>
    <td><button class="btn btn-primary" style="padding:7px 14px;font-size:12px" onclick="callNext(${s.id},this)">${esc(t('call_next'))}</button></td></tr>`).join('');
  const trows = S.admin.tickets.slice(0, 60).map(x => `<tr><td class="tn">${esc(x.number)}</td><td>${esc(x.user_name)}</td><td style="font-size:12px;font-family:var(--mono)">${esc(x.phone)}</td>
    <td><span style="font-size:14px">${esc(x.icon)}</span> <span style="font-size:13px">${esc(x.service_name)}</span></td>
    <td style="color:var(--ink3);font-size:12px;font-family:var(--mono)">${esc(fmtTime(x.created_at))}</td>
    <td><span class="badge ${statusBadge(x.status)}">${esc(statusLabel(x.status))}</span></td>
    <td>${x.status === 'serving' ? `<button class="btn btn-ghost" style="padding:5px 12px;font-size:12px" onclick="finish(${x.id},'complete')">${esc(t('complete'))}</button> <button class="btn btn-ghost" style="padding:5px 12px;font-size:12px" onclick="finish(${x.id},'no_show')">${esc(t('no_show'))}</button>` : ''}</td></tr>`).join('');
  const stat = (k, v, cls = '') => `<div class="stat-card"><div class="sl">${esc(t('s_' + k))}</div><div class="sv" ${cls ? `style="color:var(--${cls})"` : ''}>${v}</div><div class="ss">${esc(t('s_' + k + '_s'))}</div></div>`;
  const empty = n => `<tr><td colspan="${n}" style="text-align:center;padding:24px;color:var(--ink3)">${esc(t('none_today'))}</td></tr>`;
  return `${topbar()}<div class="page"><div class="main">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px"><div><h2 style="font-family:var(--fm);font-size:26px;font-weight:700">${esc(t('admin_title'))}</h2><p style="font-size:13px;color:var(--ink3)">${esc(t('admin_sub'))}</p></div>
      <div style="display:flex;gap:8px"><button class="btn btn-ghost" onclick="go('services')" style="font-size:13px">${esc(t('nav_services'))}</button><button class="btn btn-primary" onclick="refreshNow()" style="font-size:13px">${esc(t('refresh'))}</button></div></div>
    <div class="stat-grid">${stat('total', st.total)}${stat('waiting', st.waiting, 'blue')}${stat('serving', st.serving, 'gold')}${stat('done', st.done, 'green')}${stat('dropped', st.dropped, 'red')}${stat('avg', st.avg_wait_min ?? '—')}</div>
    <div class="section-title" style="margin-bottom:14px">${esc(t('svc_ops'))}</div>
    <div class="tbl-wrap" style="margin-bottom:28px"><table><thead><tr><th></th><th>${esc(t('th_service'))}</th><th>${esc(t('th_now'))}</th><th>${esc(t('th_waiting'))}</th><th>${esc(t('th_min'))}</th><th>${esc(t('th_action'))}</th></tr></thead><tbody>${rows}</tbody></table></div>
    <div class="section-title" style="margin-bottom:14px">${esc(t('tix_today'))}</div>
    <div class="tbl-wrap"><table><thead><tr><th>${esc(t('th_number'))}</th><th>${esc(t('th_name'))}</th><th>${esc(t('th_phone'))}</th><th>${esc(t('th_service'))}</th><th>${esc(t('th_time'))}</th><th>${esc(t('th_status'))}</th><th>${esc(t('th_action'))}</th></tr></thead><tbody>${trows || empty(7)}</tbody></table></div>
  </div></div>${footer()}`;
}
async function refreshNow() { try { await loadState(); render(true); } catch (e) { toast(errText(e), 'e'); } }
async function callNext(id, btn) {
  btn.disabled = true;
  try {
    const r = await api('call_next', { service_id: id });
    if (r.called) toast(t('called', { n: r.called }), 's'); else toast(t('queue_empty_svc', { n: S.services.find(s => s.id === id)?.name || '' }), 'w');
  } catch (e) { toast(errText(e), 'e'); }
  await refreshNow();
}
async function finish(id, action) {
  try { await api(action, { ticket_id: id }); } catch (e) { toast(errText(e), 'e'); }
  await refreshNow();
}

// ═══════════════════════════════════════════
// Admin: manage services
// ═══════════════════════════════════════════
const ICONS = ['🏦', '🌿', '🏥', '🏛️', '🏢', '💰', '🤝'];
function pageServices() {
  const rows = S.services.map(s => `<tr><td><span style="font-size:16px">${esc(s.icon)}</span></td>
    <td><div style="font-weight:600;font-size:13px">${esc(s.name)}${s.is_active ? '' : ` <span class="badge badge-gray">${esc(t('disabled_tag'))}</span>`}</div><div style="font-size:11px;color:var(--ink3)">${esc(s.org)}</div></td>
    <td><span class="badge badge-gray">${esc(catLabel(s.category))}</span></td><td style="font-family:var(--mono);font-size:13px">${esc(s.prefix)}</td><td>~${s.avg_wait_min}</td>
    <td><button class="btn btn-ghost" style="padding:5px 12px;font-size:12px" onclick="toggleSvc(${s.id})">${esc(s.is_active ? t('disable') : t('enable'))}</button></td></tr>`).join('');
  return `${topbar()}<div class="page"><div class="main">
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:24px"><button class="btn btn-ghost" onclick="go('admin')" style="padding:8px 14px;font-size:13px">← ${esc(t('back'))}</button>
      <div><h2 style="font-family:var(--fm);font-size:24px;font-weight:700">${esc(t('add_title'))}</h2><p style="font-size:13px;color:var(--ink3)">${esc(t('add_sub'))}</p></div></div>
    <div class="reg-grid"><div class="reg-card"><h3>${esc(t('add_card'))}</h3>
      <div class="fg"><label class="fl" for="rg-name">${esc(t('f_name'))}</label><input class="fi" id="rg-name" maxlength="80" placeholder="${esc(t('f_name_ph'))}"/></div>
      <div class="fg"><label class="fl" for="rg-org">${esc(t('f_org'))}</label><input class="fi" id="rg-org" maxlength="120" placeholder="${esc(t('f_org_ph'))}"/></div>
      <div class="fg"><label class="fl" for="rg-cat">${esc(t('f_type'))}</label><select class="fi fi-sel" id="rg-cat">${['coop', 'bank', 'health', 'gov', 'other'].map(c => `<option value="${c}">${esc(t('cat_' + c))}</option>`).join('')}</select></div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px"><div class="fg"><label class="fl" for="rg-loc">${esc(t('f_loc'))}</label><input class="fi" id="rg-loc" maxlength="190" placeholder="${esc(t('f_loc_ph'))}"/></div>
        <div class="fg"><label class="fl" for="rg-wait">${esc(t('f_wait'))}</label><input class="fi" type="number" id="rg-wait" min="1" max="120" value="15"/></div></div>
      <div class="fg"><label class="fl" for="rg-icon">${esc(t('f_icon'))}</label><select class="fi fi-sel" id="rg-icon">${ICONS.map(i => `<option>${i}</option>`).join('')}</select></div>
      <div class="err-msg" id="rg-err"></div><button class="btn btn-primary btn-full btn-lg" id="rg-btn" onclick="addService()" style="margin-top:8px">${esc(t('add_btn'))}</button></div>
    <div class="reg-card"><h3>${esc(t('all_services'))}</h3><div class="tbl-wrap"><table><thead><tr><th></th><th>${esc(t('th_service'))}</th><th></th><th>ID</th><th>${esc(t('th_min'))}</th><th></th></tr></thead><tbody>${rows}</tbody></table></div></div></div>
  </div></div>${footer()}`;
}
async function addService() {
  $('rg-err').style.display = 'none';
  const body = { name: $('rg-name').value.trim(), org: $('rg-org').value.trim(), category: $('rg-cat').value, locations: $('rg-loc').value.trim(), avg_wait_min: Number($('rg-wait').value) || 15, icon: $('rg-icon').value };
  if (!body.name || !body.org) return showErr('rg-err', t('fill_all').replace('⚠ ', ''));
  const btn = $('rg-btn'); btn.disabled = true;
  try { await api('add_service', body); toast(t('added', { n: body.name }), 's'); await loadState(); render(); }
  catch (e) { showErr('rg-err', errText(e)); btn.disabled = false; }
}
async function toggleSvc(id) { try { await api('toggle_service', { service_id: id }); await loadState(); render(true); } catch (e) { toast(errText(e), 'e'); } }

// ═══════════════════════════════════════════
// Router + boot
// ═══════════════════════════════════════════
function render(still = false) {
  const pub = ['login', 'signup'];
  if (!S.user && !pub.includes(page)) page = 'login';
  if (S.user && pub.includes(page)) page = S.user.role === 'admin' ? 'admin' : 'home';
  if (['admin', 'services'].includes(page) && S.user?.role !== 'admin') page = 'home';
  const app = $('app');
  app.classList.toggle('still', still);
  const y = window.scrollY;
  app.innerHTML = { login: pageLogin, signup: pageSignup, home: pageHome, queue: pageQueue, admin: pageAdmin, services: pageServices }[page]();
  if (still) window.scrollTo(0, y); else window.scrollTo(0, 0);
  const enter_ = (id, fn) => { const el = $(id); if (el) el.onkeydown = e => { if (e.key === 'Enter') fn(); }; };
  enter_('l-pw', doLogin); enter_('su-p', doSignup);
}

(async function boot() {
  document.documentElement.lang = lang;
  try {
    await loadState();
    if (S.user) { seedStatuses(); page = S.user.role === 'admin' ? 'admin' : 'home'; startPolling(); }
  } catch (e) {
    $('app').innerHTML = `<div style="max-width:520px;margin:15vh auto;padding:0 20px;text-align:center"><div style="font-size:48px">🎫</div><h2>FATA NUMERO</h2><p style="color:#c53030;margin-top:12px">${esc(errText(e))}</p></div>`;
    return;
  }
  render();
})();
