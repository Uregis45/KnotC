# FATA NUMERO v3 — Rwanda Queue System (XAMPP: PHP + MySQL)

Customers take a queue number from their phone and watch their place in line update live.
Staff call the next person from an admin dashboard. English by default, Kinyarwanda one click away (🌐 button).

## Run on XAMPP

1. Copy this folder to `C:\xampp\htdocs\Fata_Numero` (or your XAMPP `htdocs`).
2. Start **Apache** and **MySQL** in the XAMPP Control Panel.
3. phpMyAdmin → **Import** → choose `schema.sql`. This creates the `fata_numero` database, tables and 30 starter services.
4. Open `http://localhost/Fata_Numero/`.
5. **Register your own account first — the first account on a fresh database becomes the administrator.** Everyone after that is a normal customer.

If your MySQL login isn't the XAMPP default (`root`, empty password), create `config.local.php` next to `db.php`:

```php
<?php
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'fata_numero');
define('DB_USER', 'fata');
define('DB_PASS', 'a-strong-password');
```

Requires PHP 8.1+ with PDO MySQL (standard in current XAMPP).

## What's in v3

- **Real accounts** — passwords hashed with `password_hash`, PHP sessions, CSRF token on every change, session ID rotated at login.
- **Server-side roles** — admin actions are checked on the server on every request; editing browser storage no longer does anything.
- **Login protection** — 5 wrong passwords per email (or 30 per IP) locks sign-in for 15 minutes; sign-up is limited to 10 per IP per hour.
- **Shared, live queues** — all data lives in MySQL. Customer and admin screens refresh every 4 seconds; the customer gets a toast, vibration and a flashing tab title when it's their turn, and a heads-up when they're next.
- **Safe ticket numbers** — numbering is atomic per service per day (`BK-001`, `BK-002`, …). Tested with 25 simultaneous requests: no duplicates, no gaps.
- **Smarter waits** — estimated wait uses the service's configured minutes per person, then switches to the real average once 3 tickets have been completed that day.
- **Customer controls** — cancel a ticket; max 3 active tickets, and one per service.
- **Admin** — live stats (total, waiting, serving, done, dropped, average wait), Call next (finishes the current person automatically), Complete, No-show, add / disable services.
- **XSS-safe** — every user-supplied value is escaped before display.
- Works on phones (the top bar scrolls sideways instead of clipping).

## Files

| File | Purpose |
|---|---|
| `schema.sql` | Database + starter services (safe to re-import) |
| `db.php` | Connection, sessions, CSRF, helpers (blocked from the web by `.htaccess`) |
| `api.php` | JSON API: auth, state, tickets, admin actions |
| `index.html`, `script.js`, `style.css` | The app (original design kept) |

## Before putting this on the internet

This is built for a private XAMPP install. For a public deployment you should still add: HTTPS, a dedicated MySQL user (not `root`), email or SMS verification of accounts, SMS notifications when a turn is near, backups, and a security review. Phone numbers are collected but not verified.
