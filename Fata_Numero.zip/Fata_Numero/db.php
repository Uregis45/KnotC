<?php
declare(strict_types=1);

// Rwanda time for "today's queue". Timestamps in MySQL are stored in UTC.
date_default_timezone_set('Africa/Kigali');

// XAMPP defaults suit a private local machine only. Override in config.local.php.
$localConfig = __DIR__ . '/config.local.php';
if (is_file($localConfig)) require $localConfig;

$DB_HOST = defined('DB_HOST') ? DB_HOST : (getenv('DB_HOST') ?: '127.0.0.1');
$DB_NAME = defined('DB_NAME') ? DB_NAME : (getenv('DB_NAME') ?: 'fata_numero');
$DB_USER = defined('DB_USER') ? DB_USER : (getenv('DB_USER') ?: 'root');
$DB_PASS = defined('DB_PASS') ? DB_PASS : (getenv('DB_PASS') !== false ? getenv('DB_PASS') : '');

if (session_status() !== PHP_SESSION_ACTIVE) {
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_name('FATANUMEROSID');
    $https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    $path = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => $path === '' ? '/' : $path . '/',
        'secure' => $https,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

function db(): PDO
{
    static $pdo = null;
    global $DB_HOST, $DB_NAME, $DB_USER, $DB_PASS;
    if ($pdo instanceof PDO) return $pdo;
    $pdo = new PDO("mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4", $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    $pdo->exec("SET time_zone = '+00:00'");
    return $pdo;
}

function json_out(array $payload, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function body(): array
{
    $data = json_decode(file_get_contents('php://input') ?: '{}', true);
    return is_array($data) ? $data : [];
}

function today(): string { return date('Y-m-d'); }

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}

function require_csrf(): void
{
    $sent = (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if ($sent === '' || !hash_equals((string)($_SESSION['csrf'] ?? ''), $sent)) {
        json_out(['error' => 'csrf'], 419);
    }
}

/** The logged-in user, read fresh from the database so roles are never trusted from the client. */
function current_user(): ?array
{
    static $cache = false;
    if ($cache !== false) return $cache;
    if (empty($_SESSION['user_id'])) return $cache = null;
    $stmt = db()->prepare('SELECT id, name, email, phone, role FROM users WHERE id = ?');
    $stmt->execute([(int)$_SESSION['user_id']]);
    $u = $stmt->fetch() ?: null;
    if (!$u) { $_SESSION = []; return $cache = null; }
    $u['id'] = (int)$u['id'];
    return $cache = $u;
}
