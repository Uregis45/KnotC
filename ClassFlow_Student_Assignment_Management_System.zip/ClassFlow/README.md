# ClassFlow – Student Assignment Management System

## Requirements
- XAMPP with Apache, MySQL and PHP 8+
- Browser

## Installation
1. Extract this `ClassFlow` folder into `C:\xampp\htdocs\`.
2. Start Apache and MySQL in XAMPP Control Panel.
3. Open `http://localhost/phpmyadmin`.
4. Select **Import**, choose `ClassFlow/database.sql`, and import it.
5. Check `config/config.php`. Default XAMPP database settings are host `localhost`, database `classflow`, user `root`, empty password. `BASE_URL` defaults to `/ClassFlow/public`.
6. Open `http://localhost/ClassFlow/public`.
7. Register one account as Teacher and another as Student.

## Teacher demonstration
1. Sign in with the teacher account.
2. Click **Create assignment**.
3. Enter title, subject, instructions, deadline and maximum marks. Optionally attach a PDF, Word, PowerPoint or ZIP resource (15MB maximum).
4. Publish it.
5. Once a student submits, open **Review work**, download the student's file, enter a grade and feedback, and save.

## Student demonstration
1. Sign in with the student account.
2. Open Assignments and choose a task.
3. Read instructions and download any resource.
4. Upload work and submit it before the deadline.
5. Return to the task to view submission status, grade and teacher feedback.

## Features
- Student and teacher accounts with hashed passwords and session login.
- Teacher assignment creation and resource uploads.
- Student file submissions and comments.
- Deadline enforcement.
- Teacher grading and feedback.
- Search assignments.
- Responsive dashboard and layout.
- PDO prepared statements and CSRF tokens.

## Important
This is a school assessment/local demonstration project, not a production-ready school deployment. For a real deployment, teacher roles should be approved by an administrator, add HTTPS, email notifications, password reset, audit logs, backups, stronger file scanning, and more restrictive access controls. Uploaded files are served through an authenticated download route. Configure PHP `upload_max_filesize` and `post_max_size` to at least 16M in `php.ini` and restart Apache.
