<?php
define('BASE_URL','/ClassFlow/public'); define('DB_HOST','localhost'); define('DB_NAME','classflow'); define('DB_USER','root'); define('DB_PASS',''); define('UPLOAD_DIR',dirname(__DIR__).'/uploads'); if(session_status()===PHP_SESSION_NONE)session_start();
