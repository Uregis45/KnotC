<?php
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.use_strict_mode', '1');
    session_set_cookie_params(['lifetime'=>604800,'path'=>'/','httponly'=>true,'samesite'=>'Lax']);
    session_start();
}
function require_login(): void { if (empty($_SESSION['user_id'])) { header('Location: signin.php'); exit; } }
function require_admin(): void { require_login(); if (($_SESSION['role'] ?? 'user') !== 'admin') { http_response_code(403); exit('Access denied. Administrator account required.'); } }
function e($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
