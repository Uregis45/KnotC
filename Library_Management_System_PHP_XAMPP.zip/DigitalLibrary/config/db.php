<?php
// Database connection for XAMPP (MySQL/MariaDB).
$host = 'localhost';
$dbname = 'digital_library';
$dbuser = 'root';
$dbpass = ''; // Default XAMPP password is empty. Set yours if changed.
$charset = 'utf8mb4';
$dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";
$options = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false];
try { $pdo = new PDO($dsn, $dbuser, $dbpass, $options); }
catch (PDOException $e) { http_response_code(500); exit('Database connection failed. Check config/db.php and import database.sql in phpMyAdmin.'); }
