<?php
require_once __DIR__.'/../config/db.php'; require_once __DIR__.'/../includes/auth.php'; require_login();
header('Content-Type: application/json; charset=utf-8');
$search=trim($_GET['search']??''); $category=trim($_GET['category']??'');
$sql='SELECT id,title,author,category,description,read_url,download_url FROM books WHERE 1=1'; $args=[];
if($search!==''){ $sql.=' AND (title LIKE ? OR author LIKE ? OR description LIKE ?)'; $term='%'.$search.'%'; array_push($args,$term,$term,$term); }
if($category!=='' && strcasecmp($category,'All')!==0){ $sql.=' AND category=?'; $args[]=$category; }
$sql.=' ORDER BY category,title'; $st=$pdo->prepare($sql); $st->execute($args); echo json_encode($st->fetchAll(),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
