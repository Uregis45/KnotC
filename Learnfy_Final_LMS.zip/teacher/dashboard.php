<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_login('teacher');

$user = current_user();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM courses WHERE teacher_id = ?");
$stmt->execute([$user['id']]);
$courseCount = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM quizzes WHERE teacher_id = ?");
$stmt->execute([$user['id']]);
$quizCount = $stmt->fetchColumn();

$pageTitle = 'Teacher Dashboard';
require __DIR__ . '/../includes/header.php';
?>
<div class="section-head">
  <div>
    <span class="eyebrow" style="color:#3970c7">Instructor Workspace</span>
    <h2>Welcome back, Professor <?= e($user['full_name']) ?></h2>
    <p class="muted">Manage courses, publish quizzes, and track student learning.</p>
  </div>
  <div class="actions">
    <a href="add-course.php" class="button">+ Create New Course</a>
  </div>
</div>

<div class="grid">
  <article class="card">
    <span class="tag">Courses</span>
    <h2><?= $courseCount ?></h2>
    <p>Active Courses</p>
  </article>
  <article class="card">
    <span class="tag">Quizzes</span>
    <h2><?= $quizCount ?></h2>
    <p>Created Quizzes</p>
  </article>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
