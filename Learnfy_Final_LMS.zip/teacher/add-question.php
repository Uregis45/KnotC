<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_login('teacher');

$quizId = filter_input(INPUT_GET, 'quiz_id', FILTER_VALIDATE_INT);
if (!$quizId) redirect('quizzes.php');

$stmt = $pdo->prepare("SELECT * FROM quizzes WHERE id = ?");
$stmt->execute([$quizId]);
$quiz = $stmt->fetch();
if (!$quiz) redirect('quizzes.php');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $questionText = trim($_POST['question_text'] ?? '');
    $marks = filter_input(INPUT_POST, 'marks', FILTER_VALIDATE_INT) ?: 1;
    $options = $_POST['options'] ?? [];
    $correctIndex = isset($_POST['correct_option']) ? (int)$_POST['correct_option'] : 0;

    if ($questionText === '' || count(array_filter($options)) < 2) {
        $error = 'Please enter a question and at least two multiple-choice options.';
    } else {
        $pdo->beginTransaction();
        try {
            $qStmt = $pdo->prepare("INSERT INTO questions (quiz_id, question_text, marks) VALUES (?, ?, ?)");
            $qStmt->execute([$quizId, $questionText, $marks]);
            $questionId = $pdo->lastInsertId();

            foreach ($options as $idx => $optText) {
                $optText = trim($optText);
                if ($optText === '') continue;
                $isCorrect = ($idx === $correctIndex) ? 1 : 0;
                $oStmt = $pdo->prepare("INSERT INTO question_options (question_id, option_text, is_correct) VALUES (?, ?, ?)");
                $oStmt->execute([$questionId, $optText, $isCorrect]);
            }

            $pdo->commit();
            set_flash('success', 'Question added successfully! You can add another or return to quiz dashboard.');
            redirect("add-question.php?quiz_id={$quizId}");
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = 'Error saving question: ' . $e->getMessage();
        }
    }
}

// Fetch existing questions
$stmt = $pdo->prepare("SELECT * FROM questions WHERE quiz_id = ?");
$stmt->execute([$quizId]);
$existingQuestions = $stmt->fetchAll();

$pageTitle = 'Add Questions - ' . $quiz['title'];
require __DIR__ . '/../includes/header.php';
?>
<section class="form-card" style="max-width:800px;">
  <span class="eyebrow" style="color:#3970c7">Quiz Builder</span>
  <h1>Add Question to "<?= e($quiz['title']) ?>"</h1>

  <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>

  <form method="post">
    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
    
    <div class="field">
      <label>Question Text *</label>
      <textarea name="question_text" required placeholder="e.g. What does HTML stand for?"></textarea>
    </div>

    <div class="field">
      <label>Marks for this Question</label>
      <input type="number" name="marks" value="1" min="1" required>
    </div>

    <label style="font-weight:bold; margin-bottom:10px; display:block;">Options (Select radio for correct answer):</label>
    
    <?php for ($i = 0; $i < 4; $i++): ?>
      <div style="display:flex; align-items:center; gap:10px; margin-bottom:10px;">
        <input type="radio" name="correct_option" value="<?= $i ?>" <?= $i === 0 ? 'checked' : '' ?>>
        <input name="options[]" placeholder="Option <?= $i + 1 ?>" <?= $i < 2 ? 'required' : '' ?> style="flex:1;">
      </div>
    <?php endfor; ?>

    <div style="display:flex; gap:12px; margin-top:20px;">
      <button type="submit" class="button" style="flex:1;"><i class="fa-solid fa-plus"></i> Save Question & Add Another</button>
      <a href="quizzes.php" class="button-secondary" style="text-align:center;">Done / Finish Quiz</a>
    </div>
  </form>

  <?php if (!empty($existingQuestions)): ?>
    <hr style="margin:30px 0; border:0; border-top:1px solid #e2e8f0;">
    <h3>Questions Added So Far (<?= count($existingQuestions) ?>)</h3>
    <ol>
      <?php foreach ($existingQuestions as $eq): ?>
        <li style="margin-bottom:8px;"><strong><?= e($eq['question_text']) ?></strong> (<?= (int)$eq['marks'] ?> Mark)</li>
      <?php endforeach; ?>
    </ol>
  <?php endif; ?>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
