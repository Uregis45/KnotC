<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_login('teacher');

$user = current_user();

// Get Teacher's Courses
$stmt = $pdo->prepare("SELECT id, title FROM courses WHERE teacher_id = ?");
$stmt->execute([$user['id']]);
$courses = $stmt->fetchAll();

// If teacher has no course, fetch all courses for convenience
if (empty($courses)) {
    $courses = $pdo->query("SELECT id, title FROM courses")->fetchAll();
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $courseId = filter_input(INPUT_POST, 'course_id', FILTER_VALIDATE_INT);
    $title = trim($_POST['title'] ?? '');
    $instructions = trim($_POST['instructions'] ?? '');
    $passPercentage = filter_input(INPUT_POST, 'pass_percentage', FILTER_VALIDATE_INT) ?: 60;
    $status = $_POST['status'] ?? 'published';

    if (!$courseId || $title === '') {
        $error = 'Please enter a quiz title and select an associated course.';
    } else {
        $stmt = $pdo->prepare("INSERT INTO quizzes (course_id, teacher_id, title, instructions, pass_percentage, status) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$courseId, $user['id'], $title, $instructions, $passPercentage, $status]);
        $quizId = $pdo->lastInsertId();

        set_flash('success', "Quiz '{$title}' created successfully! Now add questions to your quiz.");
        redirect("add-question.php?quiz_id={$quizId}");
    }
}

$pageTitle = 'Create New Quiz';
require __DIR__ . '/../includes/header.php';
?>
<section class="form-card">
  <span class="eyebrow" style="color:#3970c7">Assessment Builder</span>
  <h1>Create New Quiz</h1>
  <p class="muted">Your name (<strong><?= e($user['full_name']) ?></strong>) will be listed as the creator of this quiz for all enrolled students.</p>

  <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>

  <form method="post">
    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
    
    <div class="field">
      <label>Course *</label>
      <select name="course_id" required>
        <option value="">-- Select Course --</option>
        <?php foreach ($courses as $c): ?>
          <option value="<?= $c['id'] ?>"><?= e($c['title']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="field">
      <label>Quiz Title *</label>
      <input name="title" required placeholder="e.g. HTML Foundations & Elements Test">
    </div>

    <div class="field">
      <label>Instructions for Students</label>
      <textarea name="instructions" placeholder="Read each question carefully before choosing your answer..."></textarea>
    </div>

    <div class="form-grid">
      <div class="field">
        <label>Passing Percentage (%)</label>
        <input type="number" name="pass_percentage" value="60" min="1" max="100" required>
      </div>
      <div class="field">
        <label>Publish Status</label>
        <select name="status">
          <option value="published">Published (Visible to Students)</option>
          <option value="draft">Draft (Hidden)</option>
        </select>
      </div>
    </div>

    <button type="submit" class="button" style="width:100%;"><i class="fa-solid fa-arrow-right"></i> Save & Add Questions</button>
  </form>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
