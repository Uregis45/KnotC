<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_login('teacher');

$user = current_user();

// Fetch Quizzes added by THIS teacher or all if admin
$stmt = $pdo->prepare("SELECT q.*, c.title as course_title, (SELECT COUNT(*) FROM questions WHERE quiz_id = q.id) as question_count FROM quizzes q JOIN courses c ON c.id = q.course_id WHERE q.teacher_id = ? ORDER BY q.created_at DESC");
$stmt->execute([$user['id']]);
$quizzes = $stmt->fetchAll();

$pageTitle = 'Manage Quizzes';
require __DIR__ . '/../includes/header.php';
?>
<div class="section-head">
  <div>
    <span class="eyebrow" style="color:#3970c7">Instructor Portal</span>
    <h2>Quiz Management</h2>
    <p class="muted">Create quizzes and questions for your students. Students will see your name attached to all quizzes you provide.</p>
  </div>
  <div class="actions">
    <a href="create-quiz.php" class="button"><i class="fa-solid fa-plus"></i> Create New Quiz</a>
  </div>
</div>

<div class="panel table-wrap">
  <?php if (empty($quizzes)): ?>
    <div class="empty-state">
      <i class="fa-solid fa-file-circle-plus" style="font-size:2.5rem; color:#64748b; margin-bottom:12px;"></i>
      <h3>You haven't provided any quizzes yet</h3>
      <p class="muted">Click "Create New Quiz" to add assessment questions for your students.</p>
      <a href="create-quiz.php" class="button" style="margin-top:15px;">Create Your First Quiz</a>
    </div>
  <?php else: ?>
    <table class="data-table">
      <thead>
        <tr>
          <th>Quiz Title</th>
          <th>Associated Course</th>
          <th>Questions</th>
          <th>Pass %</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($quizzes as $q): ?>
          <tr>
            <td><strong><?= e($q['title']) ?></strong></td>
            <td><?= e($q['course_title']) ?></td>
            <td><?= (int)$q['question_count'] ?> Questions</td>
            <td><?= (int)$q['pass_percentage'] ?>%</td>
            <td>
              <span class="tag" style="background:<?= $q['status'] === 'published' ? '#e6f4ea' : '#fef7e0' ?>;">
                <?= ucfirst($q['status']) ?>
              </span>
            </td>
            <td>
              <a href="add-question.php?quiz_id=<?= $q['id'] ?>" class="button-secondary small"><i class="fa-solid fa-plus"></i> Add Question</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
