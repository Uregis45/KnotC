<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle = 'Learn Web Development';

$courses = $pdo->query("SELECT c.*, u.full_name as teacher_name FROM courses c JOIN users u ON u.id = c.teacher_id WHERE c.status = 'published' ORDER BY c.created_at DESC LIMIT 6")->fetchAll();

require __DIR__ . '/includes/header.php';
?>
<section class="hero">
  <span class="eyebrow">Web Development LMS</span>
  <h1>Master Full-Stack Web Development</h1>
  <p>Interactive lessons, structured courses, and automatic assessments for HTML, CSS, JavaScript, PHP, and MySQL.</p>
  <div class="actions" style="margin-top:20px">
    <a class="button" href="<?= BASE_URL ?>auth/register.php">Start Learning Now →</a>
    <a class="button-secondary" href="<?= BASE_URL ?>auth/login.php">Teacher Portal</a>
  </div>
</section>

<div class="section-head">
  <div>
    <h2>Featured Courses</h2>
    <p class="muted">Explore web development courses taught by experienced instructors.</p>
  </div>
</div>

<div class="grid">
  <?php if (!$courses): ?>
    <div class="empty-state">
      <h3>No courses available yet</h3>
      <p class="muted">Sign in as a teacher or admin to publish courses.</p>
    </div>
  <?php else: ?>
    <?php foreach ($courses as $c): ?>
      <article class="card">
        <span class="tag"><?= e($c['level']) ?></span>
        <h3><?= e($c['title']) ?></h3>
        <p><?= e(substr($c['description'], 0, 100)) ?>...</p>
        <p class="small muted" style="margin-top:10px;"><i class="fa-solid fa-chalkboard-user"></i> Instructor: <?= e($c['teacher_name']) ?></p>
        <a class="button-secondary" style="margin-top:15px; width:100%; text-align:center;" href="<?= BASE_URL ?>auth/login.php">Enroll / View Course</a>
      </article>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
