<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';

if (current_user()) {
    $role = current_user()['role'];
    redirect(BASE_URL . "{$role}/dashboard.php");
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        if ($user['status'] === 'suspended') {
            $error = 'Your account has been suspended. Contact support.';
        } else {
            session_regenerate_id(true);
            $_SESSION['user'] = [
                'id' => (int)$user['id'],
                'full_name' => $user['full_name'],
                'email' => $user['email'],
                'role' => $user['role'],
                'profile_image' => $user['profile_image']
            ];
            set_flash('success', "Welcome back, {$user['full_name']}!");
            redirect(BASE_URL . "{$user['role']}/dashboard.php");
        }
    } else {
        $error = 'Invalid email or password.';
    }
}

$pageTitle = 'Sign In';
require __DIR__ . '/../includes/header.php';
?>
<section class="form-card">
  <span class="eyebrow" style="color:#3970c7">Authentication</span>
  <h1>Sign In to Learnfy</h1>
  <p class="muted">Access your student portal, teacher dashboard, or admin console.</p>

  <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>

  <form method="post">
    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
    <div class="field">
      <label>Email Address</label>
      <input type="email" name="email" required autocomplete="username" placeholder="user@learnfy.com">
    </div>
    <div class="field">
      <label>Password</label>
      <input type="password" name="password" required autocomplete="current-password" placeholder="••••••••">
    </div>
    <button type="submit" style="width:100%;">Sign In</button>
  </form>

  <div style="margin-top:20px; text-align:center;" class="muted">
    <p>Demo Accounts (Password: <strong>Password123</strong>):</p>
    <small>Student: <code>student@learnfy.com</code> | Teacher: <code>teacher@learnfy.com</code> | Admin: <code>admin@learnfy.com</code></small>
  </div>
  <p class="help" style="margin-top:15px; text-align:center;">Don't have an account? <a href="register.php">Register as a student</a></p>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
