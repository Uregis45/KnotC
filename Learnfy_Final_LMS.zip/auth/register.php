<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';

if (current_user()) redirect(BASE_URL . current_user()['role'] . "/dashboard.php");

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = trim($_POST['full_name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? 'student'; // Only student/teacher self-reg if allowed

    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 8) {
        $error = 'Please provide a valid name, email, and password of at least 8 characters.';
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = 'Email address is already registered.';
        } else {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("INSERT INTO users (full_name, email, password, role) VALUES (?, ?, ?, ?)");
            $stmt->execute([$name, $email, $hash, $role]);
            set_flash('success', 'Registration successful! You may now sign in.');
            redirect('login.php');
        }
    }
}

$pageTitle = 'Create Account';
require __DIR__ . '/../includes/header.php';
?>
<section class="form-card">
  <span class="eyebrow" style="color:#3970c7">Join Learnfy</span>
  <h1>Create an Account</h1>
  <p class="muted">Register to start your web development journey.</p>
  <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
  <form method="post">
    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
    <div class="field">
      <label>Full Name</label>
      <input name="full_name" required placeholder="John Doe">
    </div>
    <div class="field">
      <label>Email Address</label>
      <input name="email" type="email" required placeholder="john@example.com">
    </div>
    <div class="field">
      <label>Role</label>
      <select name="role">
        <option value="student">Student</option>
        <option value="teacher">Teacher</option>
      </select>
    </div>
    <div class="field">
      <label>Password</label>
      <input name="password" type="password" minlength="8" required placeholder="Minimum 8 characters">
    </div>
    <button type="submit" style="width:100%;">Create Account</button>
  </form>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
