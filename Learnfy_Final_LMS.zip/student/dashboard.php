<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_login('student');

$user = current_user();

// Enrolled courses count
$stmt = $pdo->prepare("SELECT COUNT(*) FROM enrollments WHERE student_id = ?");
$stmt->execute([$user['id']]);
$enrolledCount = $stmt->fetchColumn();

// Completed lessons count
$stmt = $pdo->prepare("SELECT COUNT(*) FROM lesson_progress WHERE student_id = ? AND completed = 1");
$stmt->execute([$user['id']]);
$completedLessons = $stmt->fetchColumn();

// Recent Quiz Results
$stmt = $pdo->prepare("SELECT qa.*, q.title as quiz_title FROM quiz_attempts qa JOIN quizzes q ON q.id = qa.quiz_id WHERE qa.student_id = ? ORDER BY qa.attempted_at DESC LIMIT 5");
$stmt->execute([$user['id']]);
$recentQuizzes = $stmt->fetchAll();

// Announcements
$stmt = $pdo->query("SELECT a.*, u.full_name as author FROM announcements a JOIN users u ON u.id = a.user_id WHERE a.target_audience IN ('all', 'students') ORDER BY a.created_at DESC LIMIT 3");
$announcements = $stmt->fetchAll();

$pageTitle = 'Student Dashboard';
require __DIR__ . '/../includes/header.php';
?>
<div class="section-head">
  <div>
    <span class="eyebrow" style="color:#3970c7">Student Portal</span>
    <h2>Welcome back, <?= e($user['full_name']) ?>!</h2>
    <p class="muted">Track your progress and continue learning web development.</p>
  </div>
</div>

<div class="grid">
  <article class="card">
    <span class="tag">Overview</span>
    <h2><?= $enrolledCount ?></h2>
    <p>Enrolled Courses</p>
  </article>
  <article class="card">
    <span class="tag">Progress</span>
    <h2><?= $completedLessons ?></h2>
    <p>Lessons Completed</p>
  </article>
  <article class="card">
    <span class="tag">Assessments</span>
    <h2><?= count($recentQuizzes) ?></h2>
    <p>Quiz Attempts</p>
  </article>
</div>

<div class="section-head" style="margin-top:30px;">
  <div><h2>Announcements</h2></div>
</div>
<div class="panel">
  <?php if (!$announcements): ?>
    <p class="muted">No announcements at this time.</p>
  <?php else: ?>
    <?php foreach ($announcements as $ann): ?>
      <div style="border-bottom:1px solid #e5ebf5; padding-bottom:10px; margin-bottom:10px;">
        <h4 style="margin:0; color:#163a85;"><?= e($ann['title']) ?></h4>
        <p style="margin:4px 0;"><?= e($ann['content']) ?></p>
        <span class="small muted">Posted by <?= e($ann['author']) ?> on <?= date('M j, Y', strtotime($ann['created_at'])) ?></span>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
