<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_login('student');

$user = current_user();

// Fetch all published quizzes along with the creator (teacher/admin) name and course title
$sql = "SELECT q.*, c.title as course_title, u.full_name as teacher_name 
        FROM quizzes q 
        JOIN courses c ON c.id = q.course_id 
        JOIN users u ON u.id = q.teacher_id 
        WHERE q.status = 'published' 
        ORDER BY q.created_at DESC";
$quizzes = $pdo->query($sql)->fetchAll();

// Also fetch student's previous attempts
$attemptSql = "SELECT qa.*, q.title as quiz_title, u.full_name as teacher_name 
               FROM quiz_attempts qa 
               JOIN quizzes q ON q.id = qa.quiz_id 
               JOIN users u ON u.id = q.teacher_id 
               WHERE qa.student_id = ? 
               ORDER BY qa.attempted_at DESC";
$stmt = $pdo->prepare($attemptSql);
$stmt->execute([$user['id']]);
$attempts = $stmt->fetchAll();

$pageTitle = 'Available Quizzes';
require __DIR__ . '/../includes/header.php';
?>
<div class="section-head">
  <div>
    <span class="eyebrow" style="color:#3970c7">Assessments</span>
    <h2>Available Quizzes</h2>
    <p class="muted">Take quizzes assigned by your teachers to test your knowledge.</p>
  </div>
</div>

<div class="grid">
  <?php if (empty($quizzes)): ?>
    <div class="empty-state" style="grid-column: 1 / -1;">
      <i class="fa-solid fa-clipboard-question" style="font-size: 2.5rem; color: #64748b; margin-bottom: 12px;"></i>
      <h3>No quizzes available yet</h3>
      <p class="muted">There are currently no quizzes published. Quizzes will appear here as soon as your teachers create and assign them.</p>
    </div>
  <?php else: ?>
    <?php foreach ($quizzes as $q): ?>
      <article class="card">
        <span class="tag"><i class="fa-solid fa-book"></i> <?= e($q['course_title']) ?></span>
        <h3 style="margin-top:10px;"><?= e($q['title']) ?></h3>
        <p class="muted" style="font-size:0.9rem; margin-bottom:12px;"><?= e($q['instructions'] ?: 'No special instructions.') ?></p>
        
        <div style="background:#f8fafc; padding:10px; border-radius:8px; margin-bottom:15px; font-size:0.85rem;">
          <p style="margin:2px 0;"><strong>Provided by:</strong> <i class="fa-solid fa-user-tie" style="color:#102f83;"></i> <?= e($q['teacher_name']) ?></p>
          <p style="margin:2px 0;"><strong>Passing Grade:</strong> <?= (int)$q['pass_percentage'] ?>%</p>
        </div>

        <a href="take-quiz.php?id=<?= (int)$q['id'] ?>" class="button" style="width:100%; text-align:center;">
          <i class="fa-solid fa-pen"></i> Take Quiz
        </a>
      </article>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<?php if (!empty($attempts)): ?>
<div class="section-head" style="margin-top:40px;">
  <div>
    <h2>Your Quiz History & Attempts</h2>
    <p class="muted">Review your previous scores and results.</p>
  </div>
</div>

<div class="panel table-wrap">
  <table class="data-table">
    <thead>
      <tr>
        <th>Quiz Title</th>
        <th>Instructor</th>
        <th>Score</th>
        <th>Percentage</th>
        <th>Status</th>
        <th>Date</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($attempts as $att): ?>
        <tr>
          <td><strong><?= e($att['quiz_title']) ?></strong></td>
          <td><?= e($att['teacher_name']) ?></td>
          <td><?= (int)$att['score_obtained'] ?> / <?= (int)$att['total_marks'] ?></td>
          <td><?= number_format((float)$att['percentage'], 1) ?>%</td>
          <td>
            <span class="tag" style="background:<?= $att['status'] === 'passed' ? '#e6f4ea' : '#fce8e6' ?>; color:<?= $att['status'] === 'passed' ? '#137333' : '#c5221f' ?>;">
              <?= strtoupper($att['status']) ?>
            </span>
          </td>
          <td><?= date('M j, Y - g:i A', strtotime($att['attempted_at'])) ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>

<?php require __DIR__ . '/../includes/footer.php'; ?>
