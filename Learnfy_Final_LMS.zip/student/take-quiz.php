<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_login('student');

$user = current_user();
$quizId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$quizId) redirect('quizzes.php');

// Fetch Quiz with Creator Teacher Info
$stmt = $pdo->prepare("SELECT q.*, c.title as course_title, u.full_name as teacher_name FROM quizzes q JOIN courses c ON c.id = q.course_id JOIN users u ON u.id = q.teacher_id WHERE q.id = ? AND q.status = 'published'");
$stmt->execute([$quizId]);
$quiz = $stmt->fetch();

if (!$quiz) {
    set_flash('error', 'Quiz not found or not available.');
    redirect('quizzes.php');
}

// Fetch Questions and Options
$stmt = $pdo->prepare("SELECT * FROM questions WHERE quiz_id = ?");
$stmt->execute([$quizId]);
$questions = $stmt->fetchAll();

foreach ($questions as &$q) {
    $optStmt = $pdo->prepare("SELECT id, option_text FROM question_options WHERE question_id = ?");
    $optStmt->execute([$q['id']]);
    $q['options'] = $optStmt->fetchAll();
}
unset($q);

// Process Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $answers = $_POST['answers'] ?? [];
    
    $totalQuestions = count($questions);
    $totalMarks = 0;
    $scoreObtained = 0;

    foreach ($questions as $q) {
        $totalMarks += (int)$q['marks'];
    }

    // Begin evaluation
    $pdo->beginTransaction();
    try {
        // Insert quiz attempt record first
        $attemptStmt = $pdo->prepare("INSERT INTO quiz_attempts (quiz_id, student_id, total_questions, total_marks, score_obtained, percentage, status) VALUES (?, ?, ?, ?, 0, 0.00, 'failed')");
        $attemptStmt->execute([$quizId, $user['id'], $totalQuestions, $totalMarks]);
        $attemptId = (int)$pdo->lastInsertId();

        foreach ($questions as $q) {
            $selectedOptId = isset($answers[$q['id']]) ? (int)$answers[$q['id']] : null;
            $isCorrect = 0;

            if ($selectedOptId) {
                // Check if this option is correct
                $chk = $pdo->prepare("SELECT is_correct FROM question_options WHERE id = ? AND question_id = ?");
                $chk->execute([$selectedOptId, $q['id']]);
                $opt = $chk->fetch();
                if ($opt && (int)$opt['is_correct'] === 1) {
                    $isCorrect = 1;
                    $scoreObtained += (int)$q['marks'];
                }
            }

            // Record student answer
            $ansStmt = $pdo->prepare("INSERT INTO quiz_answers (attempt_id, question_id, selected_option_id, is_correct) VALUES (?, ?, ?, ?)");
            $ansStmt->execute([$attemptId, $q['id'], $selectedOptId, $isCorrect]);
        }

        $percentage = $totalMarks > 0 ? ($scoreObtained / $totalMarks) * 100 : 0;
        $status = $percentage >= (int)$quiz['pass_percentage'] ? 'passed' : 'failed';

        // Update attempt totals
        $upd = $pdo->prepare("UPDATE quiz_attempts SET score_obtained = ?, percentage = ?, status = ? WHERE id = ?");
        $upd->execute([$scoreObtained, $percentage, $status, $attemptId]);

        $pdo->commit();
        set_flash('success', "Quiz submitted! You scored {$scoreObtained}/{$totalMarks} (" . number_format($percentage, 1) . "%). Result: " . strtoupper($status));
        redirect('quizzes.php');
    } catch (Exception $e) {
        $pdo->rollBack();
        set_flash('error', 'Error evaluating quiz: ' . $e->getMessage());
    }
}

$pageTitle = 'Taking Quiz: ' . $quiz['title'];
require __DIR__ . '/../includes/header.php';
?>
<section class="form-card" style="max-width:800px;">
  <span class="eyebrow" style="color:#3970c7"><i class="fa-solid fa-chalkboard-user"></i> Provided by <?= e($quiz['teacher_name']) ?></span>
  <h1><?= e($quiz['title']) ?></h1>
  <p class="muted">Course: <strong><?= e($quiz['course_title']) ?></strong> | Required to Pass: <strong><?= (int)$quiz['pass_percentage'] ?>%</strong></p>

  <?php if (!empty($quiz['instructions'])): ?>
    <div style="background:#f1f5f9; padding:12px 16px; border-radius:8px; margin:15px 0;">
      <strong>Instructions:</strong> <?= e($quiz['instructions']) ?>
    </div>
  <?php endif; ?>

  <form method="post" style="margin-top:20px;">
    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
    
    <?php foreach ($questions as $index => $q): ?>
      <div class="quiz-question" style="background:#fff; border:1px solid #e2e8f0; padding:20px; border-radius:12px; margin-bottom:20px;">
        <h4 style="margin-top:0; color:#1e293b;">Question <?= $index + 1 ?> (<?= (int)$q['marks'] ?> Mark<?= $q['marks'] > 1 ? 's' : '' ?>)</h4>
        <p style="font-size:1.05rem; margin-bottom:15px; color:#334155;"><?= e($q['question_text']) ?></p>
        
        <?php foreach ($q['options'] as $opt): ?>
          <label style="display:flex; align-items:center; gap:10px; margin:8px 0; cursor:pointer; background:#f8fafc; padding:10px 14px; border-radius:8px; border:1px solid #cbd5e1;">
            <input type="radio" name="answers[<?= $q['id'] ?>]" value="<?= $opt['id'] ?>" required>
            <span><?= e($opt['option_text']) ?></span>
          </label>
        <?php endforeach; ?>
      </div>
    <?php endforeach; ?>

    <button type="submit" class="button" style="width:100%; font-size:1.1rem; padding:14px;"><i class="fa-solid fa-paper-plane"></i> Submit Quiz Answers</button>
  </form>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
