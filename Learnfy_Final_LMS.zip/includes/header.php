<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/functions.php';
$user = current_user();
$pageTitle = $pageTitle ?? 'Learnfy LMS';
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($pageTitle) ?> | Learnfy LMS</title>
  <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<header class="site-header">
  <a class="brand" href="<?= BASE_URL ?>index.php"><span class="brand-mark">L</span><span>Learnfy<small>Web Dev LMS</small></span></a>
  <button class="nav-toggle" type="button" aria-label="Toggle navigation" onclick="document.querySelector('.nav-links').classList.toggle('open')">☰</button>
  <nav class="nav-links">
    <a href="<?= BASE_URL ?>index.php"><i class="fa-solid fa-house"></i> Home</a>
    <?php if ($user): ?>
      <?php if ($user['role'] === 'student'): ?>
        <a href="<?= BASE_URL ?>student/dashboard.php"><i class="fa-solid fa-gauge"></i> Dashboard</a>
        <a href="<?= BASE_URL ?>student/courses.php"><i class="fa-solid fa-book-open"></i> Courses</a>
        <a href="<?= BASE_URL ?>student/quizzes.php"><i class="fa-solid fa-pen-to-square"></i> Quizzes</a>
      <?php elseif ($user['role'] === 'teacher'): ?>
        <a href="<?= BASE_URL ?>teacher/dashboard.php"><i class="fa-solid fa-chart-line"></i> Dashboard</a>
        <a href="<?= BASE_URL ?>teacher/courses.php"><i class="fa-solid fa-chalkboard-user"></i> My Courses</a>
        <a href="<?= BASE_URL ?>teacher/quizzes.php"><i class="fa-solid fa-file-signature"></i> Manage Quizzes</a>
      <?php elseif ($user['role'] === 'admin'): ?>
        <a href="<?= BASE_URL ?>admin/dashboard.php"><i class="fa-solid fa-user-shield"></i> Admin Panel</a>
        <a href="<?= BASE_URL ?>admin/users.php"><i class="fa-solid fa-users"></i> Users</a>
        <a href="<?= BASE_URL ?>admin/courses.php"><i class="fa-solid fa-layer-group"></i> All Courses</a>
      <?php endif; ?>
      <div class="user-menu">
        <span><i class="fa-solid fa-user-circle"></i> <?= e($user['full_name']) ?> (<?= ucfirst($user['role']) ?>)</span>
        <a href="<?= BASE_URL ?>auth/logout.php" class="btn-logout"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
      </div>
    <?php else: ?>
      <a href="<?= BASE_URL ?>auth/login.php">Sign In</a>
      <a href="<?= BASE_URL ?>auth/register.php" class="button">Get Started</a>
    <?php endif; ?>
  </nav>
</header>
<main class="page-shell">
<?php if ($flash = get_flash()): ?>
  <div class="alert <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
<?php endif; ?>
