<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

function e(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function redirect(string $url): never {
    header('Location: ' . $url);
    exit;
}

function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf(): void {
    $sent = $_POST['csrf_token'] ?? '';
    if (!is_string($sent) || !hash_equals(csrf_token(), $sent)) {
        http_response_code(419);
        exit('CSRF validation failed. Please refresh the page and try again.');
    }
}

function current_user(): ?array {
    return $_SESSION['user'] ?? null;
}

function require_login(?string $role = null): void {
    $user = current_user();
    if (!$user) {
        redirect(BASE_URL . 'auth/login.php');
    }
    if ($role && $user['role'] !== $role && $user['role'] !== 'admin') {
        http_response_code(403);
        exit('Access denied. Insufficient permissions.');
    }
}

function set_flash(string $type, string $message): void {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function get_flash(): ?array {
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $flash;
}

function safe_video_embed(string $url): ?string {
    $parts = parse_url(trim($url));
    if (!$parts || !in_array(strtolower($parts['scheme'] ?? ''), ['http', 'https'], true)) {
        return null;
    }
    $host = strtolower($parts['host'] ?? '');
    $path = $parts['path'] ?? '';
    $query = [];
    parse_str($parts['query'] ?? '', $query);

    if (in_array($host, ['youtube.com', 'www.youtube.com', 'm.youtube.com'], true)) {
        $id = $query['v'] ?? '';
        if (!$id && preg_match('~^/embed/([A-Za-z0-9_-]{6,})~', $path, $m)) $id = $m[1];
        if (!$id && preg_match('~^/shorts/([A-Za-z0-9_-]{6,})~', $path, $m)) $id = $m[1];
        return preg_match('/^[A-Za-z0-9_-]{6,}$/', $id) ? 'https://www.youtube-nocookie.com/embed/' . $id : null;
    }
    if ($host === 'youtu.be') {
        $id = trim($path, '/');
        return preg_match('/^[A-Za-z0-9_-]{6,}$/', $id) ? 'https://www.youtube-nocookie.com/embed/' . $id : null;
    }
    if (in_array($host, ['vimeo.com', 'www.vimeo.com'], true)) {
        $id = trim($path, '/');
        return preg_match('/^[0-9]+$/', $id) ? 'https://player.vimeo.com/video/' . $id : null;
    }
    return null;
}
