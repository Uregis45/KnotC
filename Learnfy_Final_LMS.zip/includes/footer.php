</main>
<footer class="site-footer">
  <div><strong>Learnfy LMS</strong><p>Master HTML, CSS, JavaScript, PHP & MySQL</p></div>
  <p>© <?= date('Y') ?> Learnfy LMS. Academic Learning Management System.</p>
</footer>
</body>
</html>
