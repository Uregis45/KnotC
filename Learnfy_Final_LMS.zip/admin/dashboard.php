<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_login('admin');

$userCount = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$courseCount = $pdo->query("SELECT COUNT(*) FROM courses")->fetchColumn();
$quizCount = $pdo->query("SELECT COUNT(*) FROM quizzes")->fetchColumn();

$pageTitle = 'Admin Dashboard';
require __DIR__ . '/../includes/header.php';
?>
<div class="section-head">
  <div>
    <span class="eyebrow" style="color:#3970c7">System Administration</span>
    <h2>Platform Control Center</h2>
    <p class="muted">Monitor statistics, manage users, and oversee Learnfy LMS.</p>
  </div>
</div>

<div class="grid">
  <article class="card">
    <span class="tag">System Users</span>
    <h2><?= $userCount ?></h2>
    <p>Registered Accounts</p>
  </article>
  <article class="card">
    <span class="tag">Catalog</span>
    <h2><?= $courseCount ?></h2>
    <p>Total Courses</p>
  </article>
  <article class="card">
    <span class="tag">Quizzes</span>
    <h2><?= $quizCount ?></h2>
    <p>Assessments Created</p>
  </article>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
