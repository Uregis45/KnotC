<?php
define('SITE_NAME', 'Learnfy LMS');
define('BASE_URL', 'http://localhost/Learnfy/');
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('MAX_FILE_SIZE', 50 * 1024 * 1024); // 50MB
