<?php
/**
 * Public API used by the website pages. No account needed.
 *
 *   GET  public.php?action=menu
 *   GET  public.php?action=slots&date=YYYY-MM-DD   seats left per time slot
 *   GET  public.php?action=stories                 story-knots guests chose to share
 *   GET  public.php?action=pulse                   real "Kitchen Pulse" from today's bookings
 *   POST public.php?action=reserve                 make a reservation
 *   POST public.php?action=lookup                  {code, email} find a reservation
 *   POST public.php?action=cancel                  {code, email} cancel it
 *   POST public.php?action=contact                 send a message to the restaurant
 */
declare(strict_types=1);
require __DIR__ . '/bootstrap.php';

$action = (string) ($_GET['action'] ?? '');
$method = $_SERVER['REQUEST_METHOD'] ?? '';

const KC_CODE_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';   // no 0/O/1/I/L

function need_get(): void
{
    if ($GLOBALS['method'] !== 'GET') {
        fail('method', 'GET required.', 405);
    }
}

// ── Helpers ──────────────────────────────────────────────────
/** Parses YYYY-MM-DD strictly. Returns null when it isn't a real calendar date. */
function parse_date($raw): ?DateTimeImmutable
{
    $raw = (string) $raw;
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $raw)) {
        return null;
    }
    $d = DateTimeImmutable::createFromFormat('!Y-m-d', $raw);
    $e = DateTimeImmutable::getLastErrors();
    if (!$d || ($e && ($e['warning_count'] || $e['error_count'])) || $d->format('Y-m-d') !== $raw) {
        return null;
    }
    return $d;
}

function slot_is_past(string $date, string $time): bool
{
    // a slot can't be booked less than 30 minutes before it starts
    return strtotime($date . ' ' . $time) < time() + 30 * 60;
}

function seats_taken(PDO $pdo, string $date, string $time, bool $lock = false): int
{
    $sql = "SELECT COALESCE(SUM(guests), 0) FROM reservations
             WHERE res_date = ? AND res_time = ? AND status <> 'cancelled'" . ($lock ? ' FOR UPDATE' : '');
    $st = $pdo->prepare($sql);
    $st->execute([$date, $time]);
    return (int) $st->fetchColumn();
}

function slot_label(string $time): string
{
    foreach (cfg('slots') as $label => $t) {
        if ($t === $time) {
            return $label;
        }
    }
    return substr($time, 0, 5);
}

function new_code(PDO $pdo): string
{
    for ($i = 0; $i < 8; $i++) {
        $c = 'KC-';
        for ($j = 0; $j < 6; $j++) {
            $c .= KC_CODE_ALPHABET[random_int(0, strlen(KC_CODE_ALPHABET) - 1)];
        }
        $st = $pdo->prepare('SELECT 1 FROM reservations WHERE code = ?');
        $st->execute([$c]);
        if (!$st->fetchColumn()) {
            return $c;
        }
    }
    throw new RuntimeException('Could not generate a reservation code');
}

function reservation_public(array $r): array
{
    return [
        'code'       => $r['code'],
        'name'       => $r['name'],
        'date'       => $r['res_date'],
        'time'       => slot_label($r['res_time']),
        'guests'     => (int) $r['guests'],
        'guests_plus'=> (bool) $r['guests_plus'],
        'status'     => $r['status'],
    ];
}

/** Finds a reservation by code + email (both must match). */
function find_reservation(string $code, string $email): ?array
{
    $code  = strtoupper(trim($code));
    $email = strtolower(trim($email));
    if (!preg_match('/^KC-[A-Z0-9]{6}$/', $code) || !valid_email($email)) {
        return null;
    }
    $st = db()->prepare('SELECT * FROM reservations WHERE code = ? AND email = ?');
    $st->execute([$code, $email]);
    return $st->fetch() ?: null;
}

// ═════════════════════════════════════════════════════════════
switch ($action) {

    case 'menu':
        need_get();
        $rows = db()->query('SELECT * FROM menu_items WHERE available = 1 ORDER BY sort_order, id')->fetchAll();
        $byCat = [];
        foreach ($rows as $r) {
            $byCat[$r['category']][] = [
                'id'          => (int) $r['id'],
                'name'        => $r['name'],
                'description' => $r['description'],
                'price_rwf'   => (int) $r['price_rwf'],
                'tags'        => $r['tags'] === '' ? [] : array_map('trim', explode(',', $r['tags'])),
            ];
        }
        $out = [];
        foreach (KC_CATEGORIES as $key => $title) {
            if (!empty($byCat[$key])) {
                $out[] = ['key' => $key, 'title' => $title, 'items' => $byCat[$key]];
            }
        }
        json_out(['ok' => true, 'categories' => $out]);

    case 'slots':
        need_get();
        $d = parse_date($_GET['date'] ?? '');
        if (!$d) {
            fail('bad_date', 'Choose a valid date.', 422);
        }
        $date = $d->format('Y-m-d');
        $cap  = (int) cfg('slot_capacity');
        $pdo  = db();
        $slots = [];
        foreach (cfg('slots') as $label => $time) {
            $left = max(0, $cap - seats_taken($pdo, $date, $time));
            $slots[] = [
                'label'     => $label,
                'remaining' => $left,
                'full'      => $left === 0,
                'past'      => slot_is_past($date, $time),
            ];
        }
        json_out(['ok' => true, 'date' => $date, 'slots' => $slots]);

    case 'stories':
        need_get();
        $rows = db()->query(
            "SELECT name, story, created_at FROM reservations
              WHERE share_story = 1 AND story_hidden = 0 AND status <> 'cancelled'
                AND story IS NOT NULL AND story <> ''
              ORDER BY id DESC LIMIT 10"
        )->fetchAll();
        $stories = array_map(static function (array $r): array {
            $first = explode(' ', trim($r['name']))[0];
            return ['story' => $r['story'], 'first_name' => $first];
        }, $rows);
        json_out(['ok' => true, 'stories' => $stories]);

    case 'pulse':
        need_get();
        $cap  = max(1, (int) cfg('slot_capacity'));
        $from = date('H:i:s', time() - 3600);
        $to   = date('H:i:s', time() + 7200);
        $st   = db()->prepare(
            "SELECT COALESCE(SUM(guests), 0) FROM reservations
              WHERE res_date = ? AND res_time BETWEEN ? AND ? AND status <> 'cancelled'"
        );
        $st->execute([date('Y-m-d'), $from, $to]);
        $pct   = (int) min(100, round(100 * (int) $st->fetchColumn() / $cap));
        $label = $pct > 70 ? 'Busy weave' : ($pct > 30 ? 'Steady rhythm' : 'Calm knot');
        json_out(['ok' => true, 'percent' => $pct, 'label' => $label]);

    // ── Make a reservation ───────────────────────────────────
    case 'reserve':
        require_post();
        $b = body();
        if (clean_text($b['website'] ?? '', 200) !== '') {          // hidden "honeypot" field: only bots fill it
            json_out(['ok' => true, 'reservation' => ['code' => 'KC-000000', 'status' => 'pending']], 201);
        }

        $name  = clean_text($b['name'] ?? '', 80);
        $email = strtolower(clean_text($b['email'] ?? '', 190));
        $phone = clean_text($b['phone'] ?? '', 30);
        $slot  = clean_text($b['time'] ?? '', 20);
        $story = clean_text($b['story'] ?? '', 500, true);
        $share = !empty($b['share_story']) && $story !== '';
        $rawG  = trim((string) ($b['guests'] ?? ''));

        $errors = [];
        if (!valid_person_name($name)) {
            $errors['name'] = 'Enter your full name (letters only).';
        }
        if (!valid_email($email)) {
            $errors['email'] = 'Enter a valid email address.';
        }
        if ($phone !== '' && !valid_phone($phone)) {
            $errors['phone'] = 'Enter a valid phone number, or leave it empty.';
        }

        $date = parse_date($b['date'] ?? '');
        $slots = cfg('slots');
        if (!$date) {
            $errors['date'] = 'Choose a valid date.';
        } else {
            $today = new DateTimeImmutable('today');
            if ($date < $today) {
                $errors['date'] = 'That date has already passed.';
            } elseif ($date > $today->modify('+' . (int) cfg('max_days_ahead') . ' days')) {
                $errors['date'] = 'We take bookings up to ' . (int) cfg('max_days_ahead') . ' days ahead.';
            }
        }
        if (!isset($slots[$slot])) {
            $errors['time'] = 'Choose one of the available times.';
        } elseif ($date && !isset($errors['date']) && slot_is_past($date->format('Y-m-d'), $slots[$slot])) {
            $errors['time'] = 'That time is too soon or already gone — please pick a later slot.';
        }

        $plus = false;
        if ($rawG === '5+') {
            $guests = 5;
            $plus   = true;
        } elseif (ctype_digit($rawG) && (int) $rawG >= 1 && (int) $rawG <= (int) cfg('max_party')) {
            $guests = (int) $rawG;
        } else {
            $guests = 0;
            $errors['guests'] = 'Choose the number of guests.';
        }

        $needs = [];
        foreach ((array) ($b['needs'] ?? []) as $n) {
            if (is_string($n) && in_array($n, KC_NEEDS, true) && !in_array($n, $needs, true)) {
                $needs[] = $n;
            }
        }

        if ($errors) {
            fail('validation', 'Please fix the highlighted fields.', 422, ['fields' => $errors]);
        }

        $ip = client_ip();
        rate_guard('reserve:ip:' . $ip, 8, 3600);
        rate_guard('reserve:email:' . sha1($email), 5, 86400);

        $pdo     = db();
        $dateStr = $date->format('Y-m-d');
        $time    = $slots[$slot];
        $cap     = (int) cfg('slot_capacity');

        $pdo->beginTransaction();
        try {
            // same guest, same slot → they most likely clicked twice
            $st = $pdo->prepare("SELECT code FROM reservations WHERE email = ? AND res_date = ? AND res_time = ? AND status <> 'cancelled' FOR UPDATE");
            $st->execute([$email, $dateStr, $time]);
            if ($dup = $st->fetchColumn()) {
                $pdo->rollBack();
                fail('duplicate', 'You already have a reservation for that time (code ' . $dup . ').', 409, ['code' => $dup]);
            }
            // seat limit (rows are locked, so two guests can't both take the last seats)
            $left = $cap - seats_taken($pdo, $dateStr, $time, true);
            if ($guests > $left) {
                $pdo->rollBack();
                fail('slot_full', $left > 0
                    ? "Only $left seat" . ($left === 1 ? '' : 's') . ' left at that time. Please choose another time or fewer guests.'
                    : 'That time is fully booked. Please choose another time.', 409, ['remaining' => max(0, $left)]);
            }
            $code = new_code($pdo);
            $pdo->prepare(
                'INSERT INTO reservations (code, name, email, phone, res_date, res_time, guests, guests_plus, needs, story, share_story)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
            )->execute([$code, $name, $email, $phone === '' ? null : $phone, $dateStr, $time, $guests, $plus ? 1 : 0,
                        implode(',', $needs), $story === '' ? null : $story, $share ? 1 : 0]);
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
        rate_hit('reserve:ip:' . $ip);
        rate_hit('reserve:email:' . sha1($email));

        json_out(['ok' => true, 'reservation' => [
            'code' => $code, 'name' => $name, 'date' => $dateStr, 'time' => $slot,
            'guests' => $guests, 'guests_plus' => $plus, 'status' => 'pending',
        ]], 201);

    // ── Look up / cancel with code + email ───────────────────
    case 'lookup':
    case 'cancel':
        require_post();
        $b      = body();
        $ip     = client_ip();
        $bucket = 'lookup:ip:' . $ip;
        rate_guard($bucket, 15, 900);

        $r = find_reservation((string) ($b['code'] ?? ''), (string) ($b['email'] ?? ''));
        if (!$r) {
            rate_hit($bucket);
            fail('not_found', 'We couldn\'t find a reservation with that code and email.', 404);
        }
        if ($action === 'lookup') {
            json_out(['ok' => true, 'reservation' => reservation_public($r)]);
        }
        if ($r['status'] === 'cancelled') {
            json_out(['ok' => true, 'reservation' => reservation_public($r)]);   // already cancelled: idempotent
        }
        if (strtotime($r['res_date'] . ' ' . $r['res_time']) < time()) {
            fail('past', 'That reservation is in the past.', 409);
        }
        db()->prepare("UPDATE reservations SET status = 'cancelled', cancelled_by = 'guest' WHERE id = ?")->execute([$r['id']]);
        $r['status'] = 'cancelled';
        json_out(['ok' => true, 'reservation' => reservation_public($r)]);

    // ── Contact form ─────────────────────────────────────────
    case 'contact':
        require_post();
        $b = body();
        if (clean_text($b['website'] ?? '', 200) !== '') {            // honeypot
            json_out(['ok' => true], 201);
        }
        $name    = clean_text($b['name'] ?? '', 80);
        $email   = strtolower(clean_text($b['email'] ?? '', 190));
        $subject = clean_text($b['subject'] ?? '', 120);
        $message = clean_text($b['message'] ?? '', 3000, true);

        $errors = [];
        if (!valid_person_name($name)) {
            $errors['name'] = 'Enter your name.';
        }
        if (!valid_email($email)) {
            $errors['email'] = 'Enter a valid email address.';
        }
        if (mb_strlen($message, 'UTF-8') < 5) {
            $errors['message'] = 'Write a short message (at least 5 characters).';
        }
        if ($errors) {
            fail('validation', 'Please fix the highlighted fields.', 422, ['fields' => $errors]);
        }

        $bucket = 'contact:ip:' . client_ip();
        rate_guard($bucket, 5, 3600);
        db()->prepare('INSERT INTO contact_messages (name, email, subject, message) VALUES (?, ?, ?, ?)')
            ->execute([$name, $email, $subject === '' ? null : $subject, $message]);
        rate_hit($bucket);
        json_out(['ok' => true], 201);

    default:
        fail('unknown_action', 'Unknown action.', 404);
}
