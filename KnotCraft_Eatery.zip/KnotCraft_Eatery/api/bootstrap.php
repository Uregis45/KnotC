<?php
/**
 * Shared helpers for every API endpoint:
 * JSON output, database, sessions, CSRF protection, rate limiting.
 */
declare(strict_types=1);

$GLOBALS['kc_config'] = require __DIR__ . '/config.php';
date_default_timezone_set((string) $GLOBALS['kc_config']['timezone']);

ini_set('display_errors', '0');          // never leak PHP warnings into JSON responses
error_reporting(E_ALL);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

const KC_CATEGORIES = [
    'signature' => '⭐ Signature Knots',
    'starters'  => '🥗 Starters',
    'mains'     => '🍽️ Mains',
    'desserts'  => '🍰 Desserts',
    'drinks'    => '🥤 Drinks',
];
const KC_NEEDS = ['hearing', 'anxiety', 'mobility', 'allergy'];

function cfg(string $key)
{
    return $GLOBALS['kc_config'][$key] ?? null;
}

// ── Output ───────────────────────────────────────────────────
function json_out(array $data, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function fail(string $code, string $message, int $status = 400, array $extra = []): void
{
    json_out(array_merge(['ok' => false, 'error' => $code, 'message' => $message], $extra), $status);
}

set_exception_handler(function (Throwable $e): void {
    error_log('[KnotCraft] ' . $e);
    fail('server_error', cfg('debug') ? $e->getMessage() : 'Something went wrong on the server.', 500);
});

function now_ms(): int
{
    return (int) round(microtime(true) * 1000);
}

// ── Database ─────────────────────────────────────────────────
function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
            cfg('db_host'), (int) cfg('db_port'), cfg('db_name'));
        try {
            $pdo = new PDO($dsn, (string) cfg('db_user'), (string) cfg('db_pass'), [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            error_log('[KnotCraft] DB connection failed: ' . $e->getMessage());
            fail('db_unavailable',
                'The booking system is offline right now. (Staff: start MySQL in XAMPP and import sql/schema.sql.)', 503);
        }
    }
    return $pdo;
}

// ── Sessions (staff only) ────────────────────────────────────
function start_session(bool $readOnly = false): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    $secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '/api/x.php');
    $base   = rtrim(dirname(dirname($script)), '/') . '/';

    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.gc_maxlifetime', '28800');   // staff stay signed in up to 8 h of inactivity
    session_name((string) cfg('session_name'));
    session_set_cookie_params([
        'lifetime' => 0, 'path' => $base, 'secure' => $secure, 'httponly' => true, 'samesite' => 'Lax',
    ]);
    session_start($readOnly ? ['read_and_close' => true] : []);
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

/** Rejects non-POST and cross-site requests. Every state-changing call uses this. */
function require_post(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        fail('method', 'POST required.', 405);
    }
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    if ($origin !== '') {
        $host = (string) parse_url($origin, PHP_URL_HOST);
        $port = parse_url($origin, PHP_URL_PORT);
        $got  = $host . ($port ? ':' . $port : '');
        if (strcasecmp($got, (string) ($_SERVER['HTTP_HOST'] ?? '')) !== 0) {
            fail('csrf', 'Cross-site request blocked.', 403);
        }
    }
}

function require_csrf(): void
{
    $good = (string) ($_SESSION['csrf'] ?? '');
    $sent = (string) ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if ($good === '' || !hash_equals($good, $sent)) {
        fail('csrf', 'Your session expired. Please reload the page.', 403);
    }
}

function body(): array
{
    static $parsed = null;
    if ($parsed === null) {
        $raw    = file_get_contents('php://input');
        $parsed = $raw === '' || $raw === false ? [] : json_decode($raw, true);
        if (!is_array($parsed)) {
            fail('bad_request', 'Invalid JSON body.', 400);
        }
    }
    return $parsed;
}

function client_ip(): string
{
    return (string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
}

// ── Staff ────────────────────────────────────────────────────
function staff_public(array $s): array
{
    return ['id' => (int) $s['id'], 'full_name' => $s['full_name'], 'email' => $s['email']];
}

function current_staff(): ?array
{
    $id = (int) ($_SESSION['staff_id'] ?? 0);
    if ($id <= 0) {
        return null;
    }
    $st = db()->prepare('SELECT id, full_name, email FROM staff WHERE id = ?');
    $st->execute([$id]);
    return $st->fetch() ?: null;
}

/** POST + CSRF + signed-in staff member, or a JSON error. */
function api_staff_post(): array
{
    start_session(false);
    require_post();
    require_csrf();
    $s = current_staff();
    if (!$s) {
        fail('auth', 'Please sign in.', 401);
    }
    return $s;
}

// ── Rate limiting ────────────────────────────────────────────
function rate_guard(string $bucket, int $max, int $windowSec): void
{
    $st = db()->prepare('SELECT COUNT(*) FROM rate_events WHERE bucket = ? AND created_ms > ?');
    $st->execute([$bucket, now_ms() - $windowSec * 1000]);
    if ((int) $st->fetchColumn() >= $max) {
        fail('rate_limited', 'Too many attempts. Please wait a little and try again.', 429);
    }
}

function rate_hit(string $bucket): void
{
    $pdo = db();
    $pdo->prepare('INSERT INTO rate_events (bucket, created_ms) VALUES (?, ?)')->execute([$bucket, now_ms()]);
    if (random_int(1, 50) === 1) {
        $pdo->prepare('DELETE FROM rate_events WHERE created_ms < ?')->execute([now_ms() - 86400000]);
    }
}

function rate_clear(string $bucket): void
{
    db()->prepare('DELETE FROM rate_events WHERE bucket = ?')->execute([$bucket]);
}

// ── Validation helpers ───────────────────────────────────────
function clean_text($v, int $max, bool $multiline = false): string
{
    $v = (string) $v;
    if (!mb_check_encoding($v, 'UTF-8')) {
        return '';
    }
    $v = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $v) ?? '';
    $v = $multiline ? preg_replace("/\r\n?/", "\n", $v) : preg_replace('/\s+/u', ' ', $v);
    return mb_substr(trim((string) $v), 0, $max, 'UTF-8');
}

function valid_person_name(string $n): bool
{
    $len = mb_strlen($n, 'UTF-8');
    return $len >= 2 && $len <= 80 && preg_match('/^[\p{L}\p{M}][\p{L}\p{M} .\'’\-]*$/u', $n) === 1;
}

function valid_email(string $e): bool
{
    return strlen($e) <= 190 && filter_var($e, FILTER_VALIDATE_EMAIL) !== false;
}

function valid_phone(string $p): bool
{
    return preg_match('/^\+?[0-9 ()\-]{7,20}$/', $p) === 1;
}
