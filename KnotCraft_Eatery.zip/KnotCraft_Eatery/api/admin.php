<?php
/**
 * Staff dashboard API. Every call is a signed-in staff POST with the X-CSRF-Token header.
 *
 *   summary
 *   reservations   {view: today|upcoming|past|all, status?, q?}
 *   reservation_status {id, status: pending|confirmed|cancelled}
 *   story_hide     {id, hidden}
 *   messages       {unread_only?}
 *   message_read   {id, read}
 *   message_delete {id}
 *   menu_list
 *   menu_save      {id?, category, name, description, price_rwf, tags, sort_order, available}
 *   menu_delete    {id}
 */
declare(strict_types=1);
require __DIR__ . '/bootstrap.php';

$action = (string) ($_GET['action'] ?? '');
$staff  = api_staff_post();
session_write_close();                     // releases the session lock; the rest only needs the database
$b   = body();
$pdo = db();

function slot_label_of(string $time): string
{
    foreach (cfg('slots') as $label => $t) {
        if ($t === $time) {
            return $label;
        }
    }
    return substr($time, 0, 5);
}

function reservation_row(array $r): array
{
    return [
        'id'           => (int) $r['id'],
        'code'         => $r['code'],
        'name'         => $r['name'],
        'email'        => $r['email'],
        'phone'        => $r['phone'],
        'date'         => $r['res_date'],
        'time'         => slot_label_of($r['res_time']),
        'guests'       => (int) $r['guests'],
        'guests_plus'  => (bool) $r['guests_plus'],
        'needs'        => $r['needs'] === '' ? [] : explode(',', $r['needs']),
        'story'        => $r['story'],
        'share_story'  => (bool) $r['share_story'],
        'story_hidden' => (bool) $r['story_hidden'],
        'status'       => $r['status'],
        'cancelled_by' => $r['cancelled_by'],
        'created_at'   => $r['created_at'],
    ];
}

function menu_row(array $r): array
{
    return [
        'id' => (int) $r['id'], 'category' => $r['category'], 'name' => $r['name'], 'description' => $r['description'],
        'price_rwf' => (int) $r['price_rwf'], 'tags' => $r['tags'], 'sort_order' => (int) $r['sort_order'],
        'available' => (bool) $r['available'],
    ];
}

switch ($action) {

    case 'summary':
        $today = date('Y-m-d');
        $one = static function (string $sql, array $args = []) use ($pdo): int {
            $st = $pdo->prepare($sql);
            $st->execute($args);
            return (int) $st->fetchColumn();
        };
        json_out(['ok' => true, 'summary' => [
            'today_reservations' => $one("SELECT COUNT(*) FROM reservations WHERE res_date = ? AND status <> 'cancelled'", [$today]),
            'today_guests'       => $one("SELECT COALESCE(SUM(guests),0) FROM reservations WHERE res_date = ? AND status <> 'cancelled'", [$today]),
            'pending'            => $one("SELECT COUNT(*) FROM reservations WHERE status = 'pending' AND res_date >= ?", [$today]),
            'unread_messages'    => $one('SELECT COUNT(*) FROM contact_messages WHERE is_read = 0'),
        ]]);

    case 'reservations':
        $view   = (string) ($b['view'] ?? 'upcoming');
        $status = (string) ($b['status'] ?? '');
        $q      = clean_text($b['q'] ?? '', 80);
        $today  = date('Y-m-d');
        $where  = [];
        $args   = [];
        $order  = 'res_date ASC, res_time ASC, id ASC';
        if ($view === 'today') {
            $where[] = 'res_date = ?';
            $args[]  = $today;
        } elseif ($view === 'upcoming') {
            $where[] = 'res_date >= ?';
            $args[]  = $today;
        } elseif ($view === 'past') {
            $where[] = 'res_date < ?';
            $args[]  = $today;
            $order   = 'res_date DESC, res_time DESC, id DESC';
        } elseif ($view === 'all') {
            $order = 'res_date DESC, res_time DESC, id DESC';
        } else {
            fail('bad_request', 'Unknown view.', 422);
        }
        if (in_array($status, ['pending', 'confirmed', 'cancelled'], true)) {
            $where[] = 'status = ?';
            $args[]  = $status;
        }
        if ($q !== '') {
            $like    = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $q) . '%';
            $where[] = '(name LIKE ? OR email LIKE ? OR code LIKE ? OR phone LIKE ?)';
            array_push($args, $like, $like, $like, $like);
        }
        $sql = 'SELECT * FROM reservations' . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . " ORDER BY $order LIMIT 300";
        $st  = $pdo->prepare($sql);
        $st->execute($args);
        json_out(['ok' => true, 'reservations' => array_map('reservation_row', $st->fetchAll())]);

    case 'reservation_status':
        $id     = (int) ($b['id'] ?? 0);
        $status = (string) ($b['status'] ?? '');
        if (!in_array($status, ['pending', 'confirmed', 'cancelled'], true)) {
            fail('bad_request', 'Unknown status.', 422);
        }
        $pdo->beginTransaction();
        try {
            $st = $pdo->prepare('SELECT * FROM reservations WHERE id = ? FOR UPDATE');
            $st->execute([$id]);
            $r = $st->fetch();
            if (!$r) {
                $pdo->rollBack();
                fail('not_found', 'Reservation not found.', 404);
            }
            // bringing a cancelled booking back must still respect the seat limit
            if ($r['status'] === 'cancelled' && $status !== 'cancelled') {
                $st = $pdo->prepare("SELECT COALESCE(SUM(guests),0) FROM reservations
                                      WHERE res_date = ? AND res_time = ? AND status <> 'cancelled' FOR UPDATE");
                $st->execute([$r['res_date'], $r['res_time']]);
                $left = (int) cfg('slot_capacity') - (int) $st->fetchColumn();
                if ((int) $r['guests'] > $left) {
                    $pdo->rollBack();
                    fail('slot_full', 'That time slot is full now, so this booking can\'t be reopened.', 409);
                }
            }
            $pdo->prepare('UPDATE reservations SET status = ?, cancelled_by = ? WHERE id = ?')
                ->execute([$status, $status === 'cancelled' ? 'staff' : null, $id]);
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
        $st = $pdo->prepare('SELECT * FROM reservations WHERE id = ?');
        $st->execute([$id]);
        json_out(['ok' => true, 'reservation' => reservation_row($st->fetch())]);

    case 'story_hide':
        $pdo->prepare('UPDATE reservations SET story_hidden = ? WHERE id = ?')
            ->execute([!empty($b['hidden']) ? 1 : 0, (int) ($b['id'] ?? 0)]);
        json_out(['ok' => true]);

    case 'messages':
        $sql = 'SELECT * FROM contact_messages' . (!empty($b['unread_only']) ? ' WHERE is_read = 0' : '') . ' ORDER BY id DESC LIMIT 200';
        $rows = array_map(static fn(array $m): array => [
            'id' => (int) $m['id'], 'name' => $m['name'], 'email' => $m['email'], 'subject' => $m['subject'],
            'message' => $m['message'], 'is_read' => (bool) $m['is_read'], 'created_at' => $m['created_at'],
        ], $pdo->query($sql)->fetchAll());
        json_out(['ok' => true, 'messages' => $rows]);

    case 'message_read':
        $pdo->prepare('UPDATE contact_messages SET is_read = ? WHERE id = ?')
            ->execute([!empty($b['read']) ? 1 : 0, (int) ($b['id'] ?? 0)]);
        json_out(['ok' => true]);

    case 'message_delete':
        $pdo->prepare('DELETE FROM contact_messages WHERE id = ?')->execute([(int) ($b['id'] ?? 0)]);
        json_out(['ok' => true]);

    case 'menu_list':
        $rows = $pdo->query('SELECT * FROM menu_items ORDER BY category, sort_order, id')->fetchAll();
        json_out(['ok' => true, 'items' => array_map('menu_row', $rows),
                  'categories' => array_map(static fn($k, $v) => ['key' => $k, 'title' => $v], array_keys(KC_CATEGORIES), KC_CATEGORIES)]);

    case 'menu_save':
        $id    = (int) ($b['id'] ?? 0);
        $cat   = (string) ($b['category'] ?? '');
        $name  = clean_text($b['name'] ?? '', 80);
        $desc  = clean_text($b['description'] ?? '', 300);
        $price = $b['price_rwf'] ?? null;
        $tags  = array_filter(array_map('trim', explode(',', clean_text($b['tags'] ?? '', 120))), static fn($t) => $t !== '');
        $errors = [];
        if (!isset(KC_CATEGORIES[$cat])) {
            $errors['category'] = 'Choose a category.';
        }
        if ($name === '') {
            $errors['name'] = 'Enter the dish name.';
        }
        if (!(is_int($price) || (is_string($price) && ctype_digit($price))) || (int) $price < 0 || (int) $price > 10000000) {
            $errors['price_rwf'] = 'Enter the price in RWF (numbers only).';
        }
        if ($errors) {
            fail('validation', 'Please fix the highlighted fields.', 422, ['fields' => $errors]);
        }
        $args = [$cat, $name, $desc, (int) $price, implode(',', $tags), (int) ($b['sort_order'] ?? 0), !empty($b['available']) ? 1 : 0];
        if ($id > 0) {
            $st = $pdo->prepare('UPDATE menu_items SET category=?, name=?, description=?, price_rwf=?, tags=?, sort_order=?, available=? WHERE id=?');
            $st->execute(array_merge($args, [$id]));
            if ($st->rowCount() === 0) {
                $chk = $pdo->prepare('SELECT 1 FROM menu_items WHERE id = ?');
                $chk->execute([$id]);
                if (!$chk->fetchColumn()) {
                    fail('not_found', 'That dish no longer exists.', 404);
                }
            }
        } else {
            $pdo->prepare('INSERT INTO menu_items (category, name, description, price_rwf, tags, sort_order, available) VALUES (?,?,?,?,?,?,?)')
                ->execute($args);
            $id = (int) $pdo->lastInsertId();
        }
        $st = $pdo->prepare('SELECT * FROM menu_items WHERE id = ?');
        $st->execute([$id]);
        json_out(['ok' => true, 'item' => menu_row($st->fetch())]);

    case 'menu_delete':
        $pdo->prepare('DELETE FROM menu_items WHERE id = ?')->execute([(int) ($b['id'] ?? 0)]);
        json_out(['ok' => true]);

    default:
        fail('unknown_action', 'Unknown action.', 404);
}
