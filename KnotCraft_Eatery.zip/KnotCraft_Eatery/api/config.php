<?php
/**
 * Settings. The database defaults match a fresh XAMPP install (user "root", empty password).
 * If you set a MySQL password in XAMPP, put it in 'db_pass' below.
 * Environment variables KC_DB_* override these values (handy for testing).
 */
$kcEnv = static function (string $name, $default) {
    $v = getenv($name);
    return ($v === false || $v === '') ? $default : $v;
};

return [
    'db_host'      => $kcEnv('KC_DB_HOST', '127.0.0.1'),
    'db_port'      => (int) $kcEnv('KC_DB_PORT', 3306),
    'db_name'      => $kcEnv('KC_DB_NAME', 'knotcraft_eatery'),
    'db_user'      => $kcEnv('KC_DB_USER', 'root'),
    'db_pass'      => $kcEnv('KC_DB_PASS', ''),
    'session_name' => 'knotcraft_sid',
    'timezone'     => 'Africa/Kigali',
    'debug'        => false,   // true shows error details in API responses

    // Optional: if you put a secret word here, creating the FIRST staff account on admin.html will ask for it.
    // Recommended when the site is on the public internet (it stops strangers claiming the dashboard).
    'setup_key'    => '',

    // ── Restaurant settings ──────────────────────────────────
    // Time slots guests can book (must match the options on reservations.html).
    'slots' => [
        '11:00 AM' => '11:00:00',
        '12:00 PM' => '12:00:00',
        '2:00 PM'  => '14:00:00',
        '6:00 PM'  => '18:00:00',
        '8:00 PM'  => '20:00:00',
    ],
    'slot_capacity'  => 30,   // total guests the restaurant can seat per time slot
    'max_days_ahead' => 90,   // how far ahead guests may book
    'max_party'      => 12,   // "5+" counts as 5 seats; staff confirm bigger groups by phone
];
