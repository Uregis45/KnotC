<?php
/**
 * Staff login for the dashboard.
 *   GET  auth.php?action=me       → {staff, csrf, setup_needed}
 *   POST auth.php?action=setup    → {setup_key?, full_name, email, password}   (only works while there are NO staff accounts)
 *   POST auth.php?action=login    → {email, password}
 *   POST auth.php?action=logout
 */
declare(strict_types=1);
require __DIR__ . '/bootstrap.php';

$action = (string) ($_GET['action'] ?? '');

function staff_count(): int
{
    return (int) db()->query('SELECT COUNT(*) FROM staff')->fetchColumn();
}

function begin_staff_session(array $s): void
{
    session_regenerate_id(true);
    $_SESSION['staff_id'] = (int) $s['id'];
    $_SESSION['csrf']     = bin2hex(random_bytes(32));
    session_write_close();            // save now so the very next request is already signed in
}

if ($action === 'me') {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
        fail('method', 'GET required.', 405);
    }
    start_session(false);
    $s = current_staff();
    json_out(['ok' => true, 'staff' => $s ? staff_public($s) : null, 'csrf' => csrf_token(), 'setup_needed' => staff_count() === 0]);
}

start_session(false);
require_post();
require_csrf();
$ip = client_ip();

switch ($action) {

    case 'setup':
        if (staff_count() > 0) {
            fail('setup_done', 'Setup is already finished. Please sign in.', 409);
        }
        $b        = body();
        $name     = clean_text($b['full_name'] ?? '', 80);
        $email    = strtolower(clean_text($b['email'] ?? '', 190));
        $password = (string) ($b['password'] ?? '');
        $errors   = [];
        if (!valid_person_name($name)) {
            $errors['full_name'] = 'Enter your name.';
        }
        if (!valid_email($email)) {
            $errors['email'] = 'Enter a valid email address.';
        }
        if (strlen($password) < 10 || strlen($password) > 72) {
            $errors['password'] = 'Use 10–72 characters.';
        }
        $key = (string) cfg('setup_key');
        if ($key !== '' && !hash_equals($key, (string) ($b['setup_key'] ?? ''))) {
            $errors['setup_key'] = 'That setup key is wrong (see api/config.php).';
        }
        if ($errors) {
            fail('validation', 'Please fix the highlighted fields.', 422, ['fields' => $errors]);
        }
        rate_guard('setup:' . $ip, 10, 3600);
        rate_hit('setup:' . $ip);

        $pdo = db();
        // one atomic statement: only inserts while the table is still empty
        $st = $pdo->prepare('INSERT INTO staff (full_name, email, password_hash)
                             SELECT ?, ?, ? FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM staff)');
        $st->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT)]);
        if ($st->rowCount() !== 1) {
            fail('setup_done', 'Setup is already finished. Please sign in.', 409);
        }
        $s = ['id' => (int) $pdo->lastInsertId(), 'full_name' => $name, 'email' => $email];
        begin_staff_session($s);
        json_out(['ok' => true, 'staff' => staff_public($s), 'csrf' => $_SESSION['csrf']], 201);

    case 'login':
        $b        = body();
        $email    = strtolower(clean_text($b['email'] ?? '', 190));
        $password = (string) ($b['password'] ?? '');
        if ($email === '' || $password === '' || strlen($password) > 1024) {
            fail('validation', 'Enter your email and password.', 422);
        }
        $idBucket = 'login:id:' . sha1($email);
        $ipBucket = 'login:ip:' . $ip;
        rate_guard($ipBucket, 30, 900);
        rate_guard($idBucket, 8, 900);

        $st = db()->prepare('SELECT * FROM staff WHERE email = ?');
        $st->execute([$email]);
        $row = $st->fetch();

        // always run one bcrypt check so "no such account" and "wrong password" take the same time
        $dummy = '$2y$10$ujiZ.uFONG0wCz9ErkizL.MSlpTMMjpuOZNVhFMwJYZrOpGSyeD0O';
        $ok    = password_verify($password, $row ? $row['password_hash'] : $dummy) && $row;
        if (!$ok) {
            rate_hit($idBucket);
            rate_hit($ipBucket);
            fail('bad_credentials', 'Wrong email or password.', 401);
        }
        rate_clear($idBucket);
        if (password_needs_rehash($row['password_hash'], PASSWORD_DEFAULT)) {
            db()->prepare('UPDATE staff SET password_hash = ? WHERE id = ?')
                ->execute([password_hash($password, PASSWORD_DEFAULT), $row['id']]);
        }
        db()->prepare('UPDATE staff SET last_login_at = CURRENT_TIMESTAMP WHERE id = ?')->execute([$row['id']]);
        begin_staff_session($row);
        json_out(['ok' => true, 'staff' => staff_public($row), 'csrf' => $_SESSION['csrf']]);

    case 'logout':
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', [
                'expires' => time() - 3600, 'path' => $p['path'], 'secure' => $p['secure'],
                'httponly' => true, 'samesite' => 'Lax',
            ]);
        }
        session_destroy();
        json_out(['ok' => true]);

    default:
        fail('unknown_action', 'Unknown action.', 404);
}
