// =========================
// KNOTCRAFT — site script
// Talks to the PHP/MySQL backend in /api (XAMPP). Runs on every page;
// each section only activates when its elements exist on the page.
// =========================
(function () {
  "use strict";

  const API = "api/public.php";
  const $ = (id) => document.getElementById(id);

  // ---------- Small helpers ----------
  function el(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  }

  function store(key, value) {
    try {
      if (value === undefined) return localStorage.getItem(key);
      localStorage.setItem(key, value);
    } catch (e) { /* private mode: preferences just won't be remembered */ }
    return null;
  }

  /** GET/POST to the public API. Always resolves to {ok, status, ...}; never throws. */
  async function api(action, body, query) {
    const url = API + "?action=" + action + (query ? "&" + query : "");
    const opts = { credentials: "same-origin" };
    if (body !== undefined) {
      opts.method = "POST";
      opts.headers = { "Content-Type": "application/json" };
      opts.body = JSON.stringify(body);
    }
    try {
      const res = await fetch(url, opts);
      const data = await res.json();
      return Object.assign({ status: res.status }, data);
    } catch (e) {
      return {
        ok: false,
        status: 0,
        error: "network",
        message: "We couldn't reach the server. If you're running this locally, make sure Apache and MySQL are started in XAMPP and open the site through http://localhost/.",
      };
    }
  }

  // ---------- Accessibility ----------
  function announce(msg) {
    let live = $("liveRegion");
    if (!live) {
      live = el("div");
      live.id = "liveRegion";
      live.setAttribute("aria-live", "polite");
      live.setAttribute("role", "status");
      live.style.position = "absolute";
      live.style.left = "-9999px";
      document.body.appendChild(live);
    }
    live.textContent = "";
    setTimeout(() => { live.textContent = msg; }, 30);   // re-announce even when the text repeats
  }

  function setPref(cls, on, key) {
    document.body.classList.toggle(cls, on);
    store(key, on ? "1" : "0");
  }

  if (store("kc_contrast") === "1") document.body.classList.add("high-contrast");
  if (store("kc_dyslexia") === "1") document.body.classList.add("dyslexia");

  $("highContrastToggle")?.addEventListener("click", () => {
    const on = !document.body.classList.contains("high-contrast");
    setPref("high-contrast", on, "kc_contrast");
    announce(on ? "High contrast on" : "High contrast off");
  });

  $("dyslexiaToggle")?.addEventListener("click", () => {
    const on = !document.body.classList.contains("dyslexia");
    setPref("dyslexia", on, "kc_dyslexia");
    announce(on ? "Dyslexia-friendly font on" : "Dyslexia-friendly font off");
  });

  $("announceMode")?.addEventListener("click", () => {
    announce("Accessibility mode active. Use the contrast and dyslexia buttons to change how this page looks.");
  });

  // ---------- Navigation ----------
  const currentPage = window.location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".nav-link").forEach((link) => {
    if (link.getAttribute("href") === currentPage) link.classList.add("active");
  });

  const menuToggle = $("menuToggle");
  const navLinks = $("navLinks");
  if (menuToggle && navLinks) {
    menuToggle.setAttribute("role", "button");
    menuToggle.setAttribute("tabindex", "0");
    menuToggle.setAttribute("aria-label", "Toggle menu");
    const toggleNav = () => {
      const open = navLinks.classList.toggle("active");
      menuToggle.setAttribute("aria-expanded", String(open));
      const icon = menuToggle.querySelector("i");
      if (icon) {
        icon.classList.toggle("fa-times", open);
        icon.classList.toggle("fa-bars", !open);
      }
    };
    menuToggle.addEventListener("click", toggleNav);
    menuToggle.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); toggleNav(); }
    });
  }

  // ---------- Kitchen Pulse (real: based on today's bookings) ----------
  const fill = document.querySelector(".tension-fill");
  const pulseText = $("tensionText");

  async function pulse() {
    if (!fill || !pulseText) return;
    const r = await api("pulse");
    if (!r.ok) return;                       // keep whatever is showing
    fill.style.width = Math.max(4, r.percent) + "%";
    pulseText.textContent = r.label;
  }

  if (fill && pulseText) {
    pulse();
    setInterval(pulse, 30000);
  }

  // ---------- Menu page ----------
  const menuRoot = $("menuRoot");

  async function loadMenu() {
    if (!menuRoot) return;
    const r = await api("menu");
    if (!r.ok) return;                       // the static menu already in the page stays as a fallback
    const frag = document.createDocumentFragment();
    r.categories.forEach((cat) => {
      const section = el("section", "menu-category");
      section.appendChild(el("h2", "category-title", cat.title));
      const grid = el("div", "menu-grid");
      cat.items.forEach((it) => {
        const art = el("article", "menu-item");
        const head = el("div", "item-header");
        head.appendChild(el("h4", "", it.name));
        head.appendChild(el("span", "price", it.price_rwf.toLocaleString("en-US") + " RWF"));
        art.appendChild(head);
        if (it.description) art.appendChild(el("p", "item-description", it.description));
        if (it.tags.length) {
          const tags = el("div", "item-tags");
          it.tags.forEach((t) => tags.appendChild(el("span", "tag", t)));
          art.appendChild(tags);
        }
        grid.appendChild(art);
      });
      section.appendChild(grid);
      frag.appendChild(section);
    });
    if (!r.categories.length) frag.appendChild(el("p", "empty-note", "Our menu is being updated — please check back soon."));
    menuRoot.replaceChildren(frag);
  }

  loadMenu();

  // ---------- Reservations page ----------
  const form = $("moodReservationForm");

  function ymd(d) {
    const p = (n) => String(n).padStart(2, "0");
    return d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate());
  }

  function clearErrors(root) {
    root.querySelectorAll(".field-error").forEach((e) => (e.textContent = ""));
    root.querySelectorAll("[aria-invalid]").forEach((e) => e.removeAttribute("aria-invalid"));
  }

  const FIELD_IDS = {
    name: "resName", email: "resEmail", phone: "resPhone", date: "resDate", time: "resTime", guests: "resGuests",
  };

  function showErrors(root, fields) {
    let first = null;
    Object.keys(fields || {}).forEach((k) => {
      const span = root.querySelector('.field-error[data-for="' + k + '"]');
      if (span) span.textContent = fields[k];
      const input = $(FIELD_IDS[k] || "");
      if (input) {
        input.setAttribute("aria-invalid", "true");
        if (!first) first = input;
      }
    });
    if (first) first.focus();
  }

  function feedback(box, text, kind) {
    if (!box) return;
    box.textContent = text || "";
    box.className = "form-feedback" + (kind ? " " + kind : "");
  }

  async function loadSlots() {
    const date = $("resDate").value;
    const select = $("resTime");
    const hint = $("slotHint");
    Array.from(select.options).forEach((o) => {
      if (!o.value) return;
      o.disabled = false;
      o.textContent = o.value;
    });
    if (hint) hint.textContent = "";
    if (!date) return;
    const r = await api("slots", undefined, "date=" + encodeURIComponent(date));
    if (!r.ok || r.date !== $("resDate").value) return;
    r.slots.forEach((s) => {
      const opt = Array.from(select.options).find((o) => o.value === s.label);
      if (!opt) return;
      if (s.past) { opt.disabled = true; opt.textContent = s.label + " — not available"; }
      else if (s.full) { opt.disabled = true; opt.textContent = s.label + " — fully booked"; }
      else if (s.remaining <= 8) { opt.textContent = s.label + " — only " + s.remaining + " seats left"; }
    });
    if (select.selectedOptions[0] && select.selectedOptions[0].disabled) select.value = "";
  }

  async function loadStories() {
    const box = $("storyKnotsList");
    if (!box) return;
    const r = await api("stories");
    if (!r.ok) {
      box.replaceChildren(el("p", "empty-note", "Guest stories will appear here once the booking system is online."));
      return;
    }
    if (!r.stories.length) {
      box.replaceChildren(el("p", "empty-note", "No story-knots yet — be the first to leave one."));
      return;
    }
    box.replaceChildren(...r.stories.map((s) => {
      const card = el("div", "knot-card");
      card.appendChild(el("p", "", "“" + s.story + "”"));   // textContent: guest text can never inject HTML
      card.appendChild(el("small", "", s.first_name));
      return card;
    }));
  }

  function showReservation(res) {
    const box = $("reservationResult");
    if (!box) return;
    box.replaceChildren();
    box.appendChild(el("h3", "", "✅ Your table is requested"));
    box.appendChild(el("p", "", "Your confirmation code is:"));
    box.appendChild(el("div", "result-code", res.code));
    const when = new Date(res.date + "T12:00:00").toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
    box.appendChild(el("p", "", when + " · " + res.time + " · " + res.guests + (res.guests_plus ? "+" : "") + (res.guests === 1 ? " guest" : " guests")));
    box.appendChild(el("p", "result-note", "Status: pending — our team will confirm it. Keep this code: with your email it lets you check or cancel the booking below. Parties of 5 or more are confirmed by phone."));
    box.hidden = false;
    box.scrollIntoView({ behavior: "smooth", block: "center" });
    announce("Reservation received. Your confirmation code is " + res.code.split("").join(" "));
  }

  if (form) {
    const dateInput = $("resDate");
    const today = new Date();
    const last = new Date();
    last.setDate(last.getDate() + 90);
    dateInput.min = ymd(today);
    dateInput.max = ymd(last);
    dateInput.addEventListener("change", loadSlots);

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      clearErrors(form);
      const fb = $("reservationFeedback");
      feedback(fb, "");
      const btn = form.querySelector("button[type=submit]");

      const share = $("resShare").checked;
      const body = {
        name: $("resName").value.trim(),
        email: $("resEmail").value.trim(),
        phone: $("resPhone").value.trim(),
        date: $("resDate").value,
        time: $("resTime").value,
        guests: $("resGuests").value,
        needs: Array.from(form.querySelectorAll('input[name="thread"]:checked')).map((c) => c.value),
        story: $("storyKnot").value.trim(),
        share_story: share,
        website: $("resWebsite").value,
      };
      if (!body.name || !body.email || !body.date || !body.time || !body.guests) {
        feedback(fb, "Please fill in all the required fields (*).", "err");
        return;
      }

      btn.disabled = true;
      const r = await api("reserve", body);
      btn.disabled = false;

      if (r.ok) {
        form.reset();
        loadSlots();
        showReservation(r.reservation);
        loadStories();
        feedback(fb, "");
      } else {
        showErrors(form, r.fields);
        feedback(fb, r.fields ? "Please fix the highlighted fields." : r.message, "err");
        if (r.error === "slot_full") loadSlots();
      }
    });

    // ---- find / cancel a reservation ----
    const lookupForm = $("lookupForm");
    const lookupBox = $("lookupResult");
    let found = null;

    function showFound(res) {
      found = res;
      lookupBox.replaceChildren();
      const when = new Date(res.date + "T12:00:00").toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short" });
      lookupBox.appendChild(el("p", "", res.name + " · " + when + " · " + res.time + " · " + res.guests + (res.guests_plus ? "+" : "") + " guests"));
      lookupBox.appendChild(el("p", "status-pill status-" + res.status, res.status));
      if (res.status !== "cancelled") {
        const cancel = el("button", "link-danger", "Cancel this reservation");
        cancel.type = "button";
        cancel.addEventListener("click", cancelFound);
        lookupBox.appendChild(cancel);
      }
      lookupBox.hidden = false;
    }

    async function cancelFound() {
      if (!found || !confirm("Cancel your reservation " + found.code + "?")) return;
      const r = await api("cancel", { code: $("lookupCode").value.trim(), email: $("lookupEmail").value.trim() });
      if (r.ok) {
        showFound(r.reservation);
        announce("Reservation cancelled");
        loadSlots();
      } else {
        feedback($("lookupFeedback"), r.message, "err");
      }
    }

    lookupForm?.addEventListener("submit", async (e) => {
      e.preventDefault();
      feedback($("lookupFeedback"), "");
      lookupBox.hidden = true;
      const r = await api("lookup", { code: $("lookupCode").value.trim(), email: $("lookupEmail").value.trim() });
      if (r.ok) showFound(r.reservation);
      else feedback($("lookupFeedback"), r.message, "err");
    });

    loadStories();
  }

  // ---------- Contact page ----------
  const contact = $("contactMessageForm");

  contact?.addEventListener("submit", async (e) => {
    e.preventDefault();
    clearErrors(contact);
    const fb = $("contactFormFeedback");
    feedback(fb, "");
    const btn = contact.querySelector("button[type=submit]");
    const body = {
      name: $("contactName").value.trim(),
      email: $("contactEmail").value.trim(),
      subject: $("contactSubject").value.trim(),
      message: $("contactMessage").value.trim(),
      website: $("contactWebsite").value,
    };
    btn.disabled = true;
    const r = await api("contact", body);
    btn.disabled = false;
    if (r.ok) {
      contact.reset();
      feedback(fb, "✔ Message sent — we'll reply within 24 hours.", "ok");
      announce("Message sent");
    } else {
      const map = { name: "contactName", email: "contactEmail", message: "contactMessage" };
      Object.keys(r.fields || {}).forEach((k) => {
        const span = contact.querySelector('.field-error[data-for="' + k + '"]');
        if (span) span.textContent = r.fields[k];
        const input = $(map[k]);
        if (input) input.setAttribute("aria-invalid", "true");
      });
      feedback(fb, r.fields ? "Please fix the highlighted fields." : r.message, "err");
    }
  });
})();
