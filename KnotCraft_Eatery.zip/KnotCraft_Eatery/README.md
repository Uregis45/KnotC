# KnotCraft Eatery — XAMPP edition

The original static site, now with a PHP + MySQL backend: reservations and contact messages go into a
database, staff have a login and dashboard, and the menu is editable.

## Set up on XAMPP (5 minutes)

1. Install XAMPP and, in the XAMPP Control Panel, **start Apache and MySQL**.
2. Copy this whole folder to `C:\xampp\htdocs\KnotCraft_Eatery` (macOS/Linux: `htdocs` inside your XAMPP folder).
3. Open **http://localhost/phpmyadmin** → **Import** → choose `sql/schema.sql` → **Go**.
   This creates the database `knotcraft_eatery`, its tables, and the four dishes from the old menu.
4. Open the site: **http://localhost/KnotCraft_Eatery/**
5. Open **http://localhost/KnotCraft_Eatery/admin.html** (also linked as "Staff login" in every footer).
   The first time, it asks you to create the owner account. After that, nobody can create another one from the page.

> Open the site through `http://localhost/…`, not by double-clicking the HTML files — the forms need Apache.

If you gave MySQL a password in XAMPP, put it in `api/config.php` (`db_pass`).

## What changed

| Before | Now |
|---|---|
| Reservations saved in each visitor's own browser (nobody at the restaurant ever saw them) | Saved in MySQL with a confirmation code (`KC-XXXXXX`), status (pending / confirmed / cancelled) |
| Any number of guests could book any time | 30 seats per time slot; full slots are greyed out; no past dates; max 90 days ahead; double-click safe |
| Contact form dropped the subject and kept messages in the browser | Messages (with subject) land in the staff inbox; hidden spam trap + rate limit |
| No staff side | Staff login, today's numbers, confirm/cancel/reopen, search, guest details, inbox, menu editor |
| Menu was fixed HTML | Menu comes from the database; edit prices, add dishes, hide sold-out ones. If the server is offline the old static menu still shows |
| "Kitchen Pulse" was `Math.random()` | Real: how full the next few hours are, from today's bookings |
| Guests could look nothing up | Guests can check or cancel a booking with their code + email |
| Story wall showed stories as raw HTML | Stories are plain text; sharing on the wall is opt-in (checkbox), first name only; staff can hide any story |
| `script.js` crashed on load (`menuToggle` declared twice), so no JavaScript worked on any page | Rewritten; mobile menu, nav highlighting and accessibility buttons work, and your contrast / dyslexia choice is remembered |
| Reserve page header hidden under the navbar, logo icon `fa-knot` doesn't exist | Fixed (🪢 logo mark) |

## Settings (`api/config.php`)

- `slot_capacity` — seats per time slot (default 30).
- `slots` — the bookable times. If you change them, change the `<option>`s in `reservations.html` to match.
- `max_days_ahead`, `max_party` — booking window and largest party a guest can pick.
- `setup_key` — optional secret word required to create the first staff account. **Set this if the site is on the internet**, so a stranger can't claim the dashboard before you do.

## Good to know

- **No emails are sent.** XAMPP can't send mail out of the box. Guests see their confirmation code on screen; staff reply from the Messages tab ("Reply" opens your email app) and confirm big parties (5+) by phone.
- Passwords are stored hashed (bcrypt). Guests' accessibility needs and phone numbers are visible only in the staff dashboard.
- **Before going live:** use HTTPS, set `setup_key`, give MySQL a real password (and a dedicated user instead of `root`), and don't expose phpMyAdmin.
