-- ============================================================
--  KnotCraft Eatery — database schema (MySQL / MariaDB, XAMPP)
--  Import once: phpMyAdmin → Import → choose this file → Go
-- ============================================================

CREATE DATABASE IF NOT EXISTS knotcraft_eatery
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE knotcraft_eatery;

-- ── Staff accounts (dashboard login) ─────────────────────────
CREATE TABLE IF NOT EXISTS staff (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  full_name     VARCHAR(80)  NOT NULL,
  email         VARCHAR(190) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_login_at TIMESTAMP    NULL DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_staff_email (email)
) ENGINE=InnoDB;

-- ── Reservations ─────────────────────────────────────────────
-- needs  : comma list from hearing, anxiety, mobility, allergy (shown to staff only)
-- story  : the guest's optional "story-knot"; shown on the public wall only when
--          share_story = 1 (guest opted in) and story_hidden = 0 (staff did not hide it)
CREATE TABLE IF NOT EXISTS reservations (
  id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  code         CHAR(9)      NOT NULL,
  name         VARCHAR(80)  NOT NULL,
  email        VARCHAR(190) NOT NULL,
  phone        VARCHAR(30)  NULL DEFAULT NULL,
  res_date     DATE         NOT NULL,
  res_time     TIME         NOT NULL,
  guests       TINYINT UNSIGNED NOT NULL,
  guests_plus  TINYINT(1)   NOT NULL DEFAULT 0,
  needs        VARCHAR(80)  NOT NULL DEFAULT '',
  story        VARCHAR(500) NULL DEFAULT NULL,
  share_story  TINYINT(1)   NOT NULL DEFAULT 0,
  story_hidden TINYINT(1)   NOT NULL DEFAULT 0,
  status       ENUM('pending','confirmed','cancelled') NOT NULL DEFAULT 'pending',
  cancelled_by ENUM('guest','staff') NULL DEFAULT NULL,
  created_at   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_res_code (code),
  KEY idx_res_slot (res_date, res_time, status),
  KEY idx_res_story (share_story, story_hidden, created_at)
) ENGINE=InnoDB;

-- ── Contact messages ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS contact_messages (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name       VARCHAR(80)  NOT NULL,
  email      VARCHAR(190) NOT NULL,
  subject    VARCHAR(120) NULL DEFAULT NULL,
  message    TEXT         NOT NULL,
  is_read    TINYINT(1)   NOT NULL DEFAULT 0,
  created_at TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_msg_read (is_read, created_at)
) ENGINE=InnoDB;

-- ── Menu (edited from the staff dashboard) ───────────────────
CREATE TABLE IF NOT EXISTS menu_items (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  category    VARCHAR(20)  NOT NULL,
  name        VARCHAR(80)  NOT NULL,
  description VARCHAR(300) NOT NULL DEFAULT '',
  price_rwf   INT UNSIGNED NOT NULL,
  tags        VARCHAR(120) NOT NULL DEFAULT '',
  sort_order  INT          NOT NULL DEFAULT 0,
  available   TINYINT(1)   NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  KEY idx_menu_cat (category, sort_order)
) ENGINE=InnoDB;

-- ── Simple rate limiting ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS rate_events (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  bucket     VARCHAR(190) NOT NULL,
  created_ms BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (id),
  KEY idx_rate_bucket (bucket, created_ms)
) ENGINE=InnoDB;

-- ── Starting menu: the dishes that were on the old static page ──
INSERT INTO menu_items (category, name, description, price_rwf, tags, sort_order)
SELECT * FROM (
  SELECT 'signature' AS category, 'Truffle Risotto Knot' AS name,
         'Creamy arborio rice, black truffle, parmesan, basil thread finish.' AS description,
         3200 AS price_rwf, 'Vegetarian,Popular' AS tags, 1 AS sort_order
  UNION ALL SELECT 'signature', 'KnotCraft Grilled Chicken',
         'Herb-marinated chicken grilled over charcoal with honey glaze.', 4500, 'Chef Choice', 2
  UNION ALL SELECT 'starters', 'Garden Knot Salad',
         'Fresh greens, citrus dressing, crunchy seeds blend.', 2000, 'Light,Healthy', 1
  UNION ALL SELECT 'desserts', 'Chocolate Knot Lava Cake',
         'Warm chocolate cake with molten center and vanilla ice cream.', 2800, 'Sweet,Best Seller', 1
) seed
WHERE NOT EXISTS (SELECT 1 FROM menu_items);
