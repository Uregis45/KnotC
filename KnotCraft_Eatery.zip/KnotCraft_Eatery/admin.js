// ============================================================
//  KnotCraft — staff dashboard (admin.js)
//  Everything shown here is built with textContent, never innerHTML,
//  so nothing a guest types can run as code in the staff's browser.
// ============================================================
(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  let csrf = "";
  let staff = null;
  let toastT = null;
  let menuCategories = [];
  let menuItems = [];

  function h(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined && text !== null) e.textContent = text;
    return e;
  }

  function toast(msg, isErr) {
    const t = $("toast");
    t.textContent = msg;
    t.className = "admin-toast show" + (isErr ? " err" : "");
    clearTimeout(toastT);
    toastT = setTimeout(() => (t.className = "admin-toast"), 2800);
  }

  // ── API ────────────────────────────────────────────────────
  async function call(file, action, body) {
    const opts = { credentials: "same-origin", headers: {} };
    if (body !== undefined) {
      opts.method = "POST";
      opts.headers["Content-Type"] = "application/json";
      opts.headers["X-CSRF-Token"] = csrf;
      opts.body = JSON.stringify(body);
    }
    try {
      const res = await fetch("api/" + file + ".php?action=" + action, opts);
      const data = await res.json();
      const out = Object.assign({ status: res.status }, data);
      if (res.status === 401 && file === "admin") showAuth(false);   // session ended
      return out;
    } catch (e) {
      return { ok: false, status: 0, message: "Can't reach the server. Are Apache and MySQL running in XAMPP?" };
    }
  }

  const adm = (action, body) => call("admin", action, body || {});

  // ── Formatting ─────────────────────────────────────────────
  function niceDate(ymd) {
    const d = new Date(ymd + "T12:00:00");
    return d.toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short" });
  }

  function niceStamp(ts) {
    const d = new Date(String(ts).replace(" ", "T"));
    return isNaN(d) ? ts : d.toLocaleString("en-GB", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
  }

  const NEED_LABELS = { hearing: "Hearing support", anxiety: "Sensory comfort", mobility: "Mobility access", allergy: "Allergy care" };

  function clearErrors(root) {
    root.querySelectorAll(".field-error").forEach((e) => (e.textContent = ""));
  }

  function showFieldErrors(root, fields) {
    Object.keys(fields || {}).forEach((k) => {
      const s = root.querySelector('.field-error[data-for="' + k + '"]');
      if (s) s.textContent = fields[k];
    });
  }

  // ── Sign in / setup ────────────────────────────────────────
  function showAuth(setupNeeded, setupKeyNeeded) {
    staff = null;
    $("dash").hidden = true;
    $("adminUser").hidden = true;
    $("authPanel").hidden = false;
    $("loginForm").hidden = !!setupNeeded;
    $("setupForm").hidden = !setupNeeded;
    ($(setupNeeded ? "setupName" : "loginEmail")).focus();
  }

  function enterDash(s) {
    staff = s;
    $("authPanel").hidden = true;
    $("dash").hidden = false;
    $("adminUser").hidden = false;
    $("adminName").textContent = s.full_name;
    $("authMsg").textContent = "";
    refreshSummary();
    loadReservations();
    loadMessages();
  }

  async function onLogin(e) {
    e.preventDefault();
    $("authMsg").textContent = "";
    const btn = e.submitter;
    if (btn) btn.disabled = true;
    const r = await call("auth", "login", { email: $("loginEmail").value.trim(), password: $("loginPassword").value });
    if (btn) btn.disabled = false;
    if (r.ok) {
      csrf = r.csrf;
      $("loginPassword").value = "";
      enterDash(r.staff);
    } else {
      $("authMsg").textContent = r.message || "Could not sign in.";
      $("authMsg").className = "form-feedback err";
    }
  }

  async function onSetup(e) {
    e.preventDefault();
    clearErrors($("setupForm"));
    $("authMsg").textContent = "";
    const btn = e.submitter;
    if (btn) btn.disabled = true;
    const r = await call("auth", "setup", {
      full_name: $("setupName").value.trim(),
      email: $("setupEmail").value.trim(),
      password: $("setupPassword").value,
      setup_key: $("setupKey").value,
    });
    if (btn) btn.disabled = false;
    if (r.ok) {
      csrf = r.csrf;
      $("setupPassword").value = "";
      enterDash(r.staff);
    } else {
      showFieldErrors($("setupForm"), r.fields);
      if (r.fields && r.fields.setup_key) $("setupKeyRow").hidden = false;
      $("authMsg").textContent = r.fields ? "Please fix the highlighted fields." : r.message;
      $("authMsg").className = "form-feedback err";
      if (r.error === "setup_done") showAuth(false);
    }
  }

  async function onLogout() {
    await call("auth", "logout", {});
    const me = await call("auth", "me");
    csrf = me.csrf || "";
    showAuth(false);
  }

  // ── Summary ────────────────────────────────────────────────
  async function refreshSummary() {
    const r = await adm("summary");
    if (!r.ok) return;
    $("statToday").textContent = r.summary.today_reservations;
    $("statGuests").textContent = r.summary.today_guests;
    $("statPending").textContent = r.summary.pending;
    $("statUnread").textContent = r.summary.unread_messages;
    const b = $("badgeMsg");
    b.hidden = r.summary.unread_messages === 0;
    b.textContent = r.summary.unread_messages;
  }

  // ── Tabs ───────────────────────────────────────────────────
  function selectTab(name) {
    const map = { res: ["tabRes", "panelRes"], msg: ["tabMsg", "panelMsg"], menu: ["tabMenu", "panelMenu"] };
    Object.keys(map).forEach((k) => {
      const on = k === name;
      $(map[k][0]).classList.toggle("active", on);
      $(map[k][0]).setAttribute("aria-selected", String(on));
      $(map[k][1]).hidden = !on;
    });
    if (name === "menu") loadMenu();
    if (name === "msg") loadMessages();
    if (name === "res") loadReservations();
  }

  // ── Reservations ───────────────────────────────────────────
  async function loadReservations() {
    const r = await adm("reservations", { view: $("fltView").value, status: $("fltStatus").value, q: $("fltQuery").value.trim() });
    const box = $("resList");
    if (!r.ok) { box.replaceChildren(h("div", "empty", r.message || "Could not load reservations.")); return; }
    if (!r.reservations.length) { box.replaceChildren(h("div", "empty", "No reservations match.")); return; }
    box.replaceChildren(...r.reservations.map(reservationCard));
  }

  function reservationCard(r) {
    const card = h("article", "item st-" + r.status);
    const row = h("div", "item-row");

    const when = h("div", "item-when", niceDate(r.date));
    when.appendChild(h("small", "", r.time));
    row.appendChild(when);

    const main = h("div", "item-main");
    main.appendChild(h("strong", "", r.name));
    main.appendChild(h("small", "", r.code + " · " + r.guests + (r.guests_plus ? "+" : "") + (r.guests === 1 ? " guest" : " guests")));
    const chips = h("div", "chips");
    chips.appendChild(h("span", "status-pill status-" + r.status, r.status));
    r.needs.forEach((n) => chips.appendChild(h("span", "chip need", NEED_LABELS[n] || n)));
    if (r.guests_plus) chips.appendChild(h("span", "chip", "Big party — call to confirm"));
    main.appendChild(chips);
    row.appendChild(main);

    const actions = h("div", "item-actions");
    const act = (label, cls, status) => {
      const b = h("button", "btn-small " + cls, label);
      b.type = "button";
      b.addEventListener("click", async () => {
        if (status === "cancelled" && !confirm("Cancel " + r.name + "'s reservation?")) return;
        b.disabled = true;
        const res = await adm("reservation_status", { id: r.id, status });
        if (res.ok) { toast("Reservation " + status); loadReservations(); refreshSummary(); }
        else { toast(res.message || "Could not update", true); b.disabled = false; }
      });
      actions.appendChild(b);
    };
    if (r.status === "pending") { act("Confirm", "good", "confirmed"); act("Cancel", "danger", "cancelled"); }
    if (r.status === "confirmed") { act("Cancel", "danger", "cancelled"); }
    if (r.status === "cancelled") { act("Reopen", "", "pending"); }
    const more = h("button", "btn-small", "Details");
    more.type = "button";
    actions.appendChild(more);
    row.appendChild(actions);
    card.appendChild(row);

    const details = h("div", "item-details");
    details.hidden = true;
    const line = (label, value) => {
      const p = h("div");
      p.appendChild(h("strong", "", label + ": "));
      if (value instanceof Node) p.appendChild(value); else p.appendChild(document.createTextNode(value));
      details.appendChild(p);
    };
    const mail = h("a", "", r.email);
    mail.href = "mailto:" + r.email;
    line("Email", mail);
    if (r.phone) {
      const tel = h("a", "", r.phone);
      tel.href = "tel:" + r.phone.replace(/[^0-9+]/g, "");
      line("Phone", tel);
    }
    line("Booked", niceStamp(r.created_at));
    if (r.cancelled_by) line("Cancelled by", r.cancelled_by);
    if (r.story) {
      line("Story-knot", r.share_story ? (r.story_hidden ? "guest agreed to share — hidden by staff" : "shown on the guest wall") : "private (not shared)");
      details.appendChild(h("div", "quote", r.story));
      if (r.share_story) {
        const hide = h("button", "btn-small", r.story_hidden ? "Show on wall again" : "Hide from guest wall");
        hide.type = "button";
        hide.addEventListener("click", async () => {
          const res = await adm("story_hide", { id: r.id, hidden: !r.story_hidden });
          if (res.ok) { toast(r.story_hidden ? "Story is public again" : "Story hidden from the wall"); loadReservations(); }
        });
        details.appendChild(hide);
      }
    }
    card.appendChild(details);
    more.addEventListener("click", () => {
      details.hidden = !details.hidden;
      more.textContent = details.hidden ? "Details" : "Hide";
    });
    return card;
  }

  // ── Messages ───────────────────────────────────────────────
  async function loadMessages() {
    const r = await adm("messages", { unread_only: $("fltUnread").checked });
    const box = $("msgList");
    if (!r.ok) { box.replaceChildren(h("div", "empty", r.message || "Could not load messages.")); return; }
    if (!r.messages.length) { box.replaceChildren(h("div", "empty", "No messages.")); return; }
    box.replaceChildren(...r.messages.map(messageCard));
  }

  function messageCard(m) {
    const card = h("article", "item" + (m.is_read ? "" : " unread"));
    const row = h("div", "item-row");
    const when = h("div", "item-when", niceStamp(m.created_at));
    row.appendChild(when);
    const main = h("div", "item-main");
    main.appendChild(h("strong", "", m.subject || "(no subject)"));
    main.appendChild(h("small", "", m.name + " · " + m.email));
    row.appendChild(main);

    const actions = h("div", "item-actions");
    const reply = h("a", "btn-small", "Reply");
    reply.href = "mailto:" + m.email + "?subject=" + encodeURIComponent("Re: " + (m.subject || "your message to KnotCraft"));
    actions.appendChild(reply);
    const toggle = h("button", "btn-small", m.is_read ? "Mark unread" : "Mark read");
    toggle.type = "button";
    toggle.addEventListener("click", async () => {
      const res = await adm("message_read", { id: m.id, read: !m.is_read });
      if (res.ok) { loadMessages(); refreshSummary(); }
    });
    actions.appendChild(toggle);
    const del = h("button", "btn-small danger", "Delete");
    del.type = "button";
    del.addEventListener("click", async () => {
      if (!confirm("Delete this message for good?")) return;
      const res = await adm("message_delete", { id: m.id });
      if (res.ok) { toast("Message deleted"); loadMessages(); refreshSummary(); }
    });
    actions.appendChild(del);
    row.appendChild(actions);
    card.appendChild(row);
    card.appendChild(h("div", "msg-body", m.message));
    return card;
  }

  // ── Menu editor ────────────────────────────────────────────
  async function loadMenu() {
    const r = await adm("menu_list");
    if (!r.ok) { $("menuList").replaceChildren(h("div", "empty", r.message || "Could not load the menu.")); return; }
    menuCategories = r.categories;
    menuItems = r.items;
    const sel = $("mCategory");
    if (!sel.options.length) {
      menuCategories.forEach((c) => { const o = h("option", "", c.title); o.value = c.key; sel.appendChild(o); });
    }
    renderMenu();
  }

  function renderMenu() {
    const box = $("menuList");
    const nodes = [];
    menuCategories.forEach((c) => {
      const items = menuItems.filter((i) => i.category === c.key);
      if (!items.length) return;
      nodes.push(h("h3", "cat-title", c.title));
      items.forEach((i) => nodes.push(menuCard(i)));
    });
    box.replaceChildren(...(nodes.length ? nodes : [h("div", "empty", "No dishes yet — add your first one.")]));
  }

  function menuCard(i) {
    const card = h("article", "item" + (i.available ? "" : " off"));
    const row = h("div", "item-row");
    const main = h("div", "item-main");
    main.appendChild(h("strong", "", i.name));
    if (i.description) main.appendChild(h("small", "", i.description));
    if (i.tags) {
      const chips = h("div", "chips");
      i.tags.split(",").forEach((t) => chips.appendChild(h("span", "chip", t)));
      main.appendChild(chips);
    }
    row.appendChild(main);
    row.appendChild(h("div", "item-when", i.price_rwf.toLocaleString("en-US") + " RWF"));
    const actions = h("div", "item-actions");
    const edit = h("button", "btn-small", "Edit");
    edit.type = "button";
    edit.addEventListener("click", () => editDish(i));
    const toggle = h("button", "btn-small", i.available ? "Hide" : "Show");
    toggle.type = "button";
    toggle.addEventListener("click", async () => {
      const res = await adm("menu_save", Object.assign({}, i, { available: !i.available }));
      if (res.ok) { toast(i.available ? "Hidden from the menu" : "Back on the menu"); loadMenu(); }
      else toast(res.message || "Could not save", true);
    });
    const del = h("button", "btn-small danger", "Delete");
    del.type = "button";
    del.addEventListener("click", async () => {
      if (!confirm("Delete “" + i.name + "” from the menu?")) return;
      const res = await adm("menu_delete", { id: i.id });
      if (res.ok) { toast("Dish deleted"); resetDishForm(); loadMenu(); }
    });
    actions.append(edit, toggle, del);
    row.appendChild(actions);
    card.appendChild(row);
    return card;
  }

  function resetDishForm() {
    $("menuForm").reset();
    $("mId").value = "";
    $("mAvail").checked = true;
    $("mOrder").value = "0";
    $("menuFormTitle").textContent = "Add a dish";
    $("mSave").textContent = "Save dish";
    $("mCancel").hidden = true;
    clearErrors($("menuForm"));
  }

  function editDish(i) {
    $("mId").value = i.id;
    $("mCategory").value = i.category;
    $("mName").value = i.name;
    $("mDesc").value = i.description;
    $("mPrice").value = i.price_rwf;
    $("mOrder").value = i.sort_order;
    $("mTags").value = i.tags;
    $("mAvail").checked = i.available;
    $("menuFormTitle").textContent = "Edit dish";
    $("mSave").textContent = "Save changes";
    $("mCancel").hidden = false;
    clearErrors($("menuForm"));
    $("mName").focus();
    $("menuForm").scrollIntoView({ behavior: "smooth", block: "nearest" });
  }

  async function saveDish(e) {
    e.preventDefault();
    clearErrors($("menuForm"));
    const body = {
      id: Number($("mId").value) || 0,
      category: $("mCategory").value,
      name: $("mName").value.trim(),
      description: $("mDesc").value.trim(),
      price_rwf: $("mPrice").value.trim(),
      tags: $("mTags").value.trim(),
      sort_order: Number($("mOrder").value) || 0,
      available: $("mAvail").checked,
    };
    $("mSave").disabled = true;
    const r = await adm("menu_save", body);
    $("mSave").disabled = false;
    if (r.ok) {
      toast(body.id ? "Changes saved" : "Dish added");
      resetDishForm();
      loadMenu();
    } else {
      showFieldErrors($("menuForm"), r.fields);
      if (!r.fields) toast(r.message || "Could not save", true);
    }
  }

  // ── Init ───────────────────────────────────────────────────
  async function init() {
    $("loginForm").addEventListener("submit", onLogin);
    $("setupForm").addEventListener("submit", onSetup);
    $("logoutBtn").addEventListener("click", onLogout);
    $("tabRes").addEventListener("click", () => selectTab("res"));
    $("tabMsg").addEventListener("click", () => selectTab("msg"));
    $("tabMenu").addEventListener("click", () => selectTab("menu"));
    ["fltView", "fltStatus"].forEach((id) => $(id).addEventListener("change", loadReservations));
    let t = null;
    $("fltQuery").addEventListener("input", () => { clearTimeout(t); t = setTimeout(loadReservations, 300); });
    $("fltUnread").addEventListener("change", loadMessages);
    $("menuForm").addEventListener("submit", saveDish);
    $("mCancel").addEventListener("click", resetDishForm);

    const me = await call("auth", "me");
    if (!me.ok) {
      $("authPanel").hidden = false;
      $("authMsg").textContent = me.message || "Can't reach the server.";
      $("authMsg").className = "form-feedback err";
      return;
    }
    csrf = me.csrf;
    if (me.staff) enterDash(me.staff);
    else showAuth(me.setup_needed);

    // keep the numbers fresh while the dashboard is open
    setInterval(() => { if (staff && !document.hidden) { refreshSummary(); } }, 30000);
  }

  init();
})();
